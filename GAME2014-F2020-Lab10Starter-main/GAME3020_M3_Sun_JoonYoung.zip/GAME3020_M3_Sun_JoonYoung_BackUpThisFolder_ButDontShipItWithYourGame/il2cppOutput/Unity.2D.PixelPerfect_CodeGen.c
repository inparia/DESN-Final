﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Int32 UnityEngine.U2D.PixelPerfectCamera::get_assetsPPU()
extern void PixelPerfectCamera_get_assetsPPU_mF294CEA88ED86AF12C3B288A32454145E655081D ();
// 0x00000002 System.Void UnityEngine.U2D.PixelPerfectCamera::set_assetsPPU(System.Int32)
extern void PixelPerfectCamera_set_assetsPPU_mAF321B9D68BFEEB5F460E85C99EDF3D7165DF270 ();
// 0x00000003 System.Int32 UnityEngine.U2D.PixelPerfectCamera::get_refResolutionX()
extern void PixelPerfectCamera_get_refResolutionX_mD8E1DCEE1434AAC6761DEE8B73D4D163B858FE58 ();
// 0x00000004 System.Void UnityEngine.U2D.PixelPerfectCamera::set_refResolutionX(System.Int32)
extern void PixelPerfectCamera_set_refResolutionX_mDA8E4201FF94E6B565DA3BFACC5A8B80F26C20C1 ();
// 0x00000005 System.Int32 UnityEngine.U2D.PixelPerfectCamera::get_refResolutionY()
extern void PixelPerfectCamera_get_refResolutionY_m8C37A3DBC9014F034A78F9E921A11BAA113CB24F ();
// 0x00000006 System.Void UnityEngine.U2D.PixelPerfectCamera::set_refResolutionY(System.Int32)
extern void PixelPerfectCamera_set_refResolutionY_mD0998785CF628E2E1841B232EDB53AAFDD60D86D ();
// 0x00000007 System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_upscaleRT()
extern void PixelPerfectCamera_get_upscaleRT_m36326F6B11D8D2CC33971B805344F2C6458E54C0 ();
// 0x00000008 System.Void UnityEngine.U2D.PixelPerfectCamera::set_upscaleRT(System.Boolean)
extern void PixelPerfectCamera_set_upscaleRT_m870AC116618CC6358EB9403A59D7E54F0D56F0A9 ();
// 0x00000009 System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_pixelSnapping()
extern void PixelPerfectCamera_get_pixelSnapping_mF550795A64EA5FF77DECD748CA5FB21C00D9A121 ();
// 0x0000000A System.Void UnityEngine.U2D.PixelPerfectCamera::set_pixelSnapping(System.Boolean)
extern void PixelPerfectCamera_set_pixelSnapping_m9B77AA59CDF18E388D4E033FB5BDC8F950F36226 ();
// 0x0000000B System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_cropFrameX()
extern void PixelPerfectCamera_get_cropFrameX_mB81332B181CC77B077B48EC5B7B96CBA73912FA6 ();
// 0x0000000C System.Void UnityEngine.U2D.PixelPerfectCamera::set_cropFrameX(System.Boolean)
extern void PixelPerfectCamera_set_cropFrameX_m2E647446C63C83F20E38413E85698C49988E699C ();
// 0x0000000D System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_cropFrameY()
extern void PixelPerfectCamera_get_cropFrameY_m4DBB6A286AC29B2213E61B6397754C38E799A5D1 ();
// 0x0000000E System.Void UnityEngine.U2D.PixelPerfectCamera::set_cropFrameY(System.Boolean)
extern void PixelPerfectCamera_set_cropFrameY_m3EAE38E3B33718D14E290E711F73406B0DC5FC59 ();
// 0x0000000F System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_stretchFill()
extern void PixelPerfectCamera_get_stretchFill_m959164B6C59CB30C7EDDFFE93808C2CEEDFC3847 ();
// 0x00000010 System.Void UnityEngine.U2D.PixelPerfectCamera::set_stretchFill(System.Boolean)
extern void PixelPerfectCamera_set_stretchFill_m82F148F1225AB1B5E5C86043632CF6C3B07FA269 ();
// 0x00000011 System.Int32 UnityEngine.U2D.PixelPerfectCamera::get_pixelRatio()
extern void PixelPerfectCamera_get_pixelRatio_m8E1DC329C0C7551837F4AE0E1B70B9730042C96F ();
// 0x00000012 UnityEngine.Vector3 UnityEngine.U2D.PixelPerfectCamera::RoundToPixel(UnityEngine.Vector3)
extern void PixelPerfectCamera_RoundToPixel_m53B7AE007CD7E21B1B7DFD76A1F330364369C2D8 ();
// 0x00000013 System.Single UnityEngine.U2D.PixelPerfectCamera::CorrectCinemachineOrthoSize(System.Single)
extern void PixelPerfectCamera_CorrectCinemachineOrthoSize_m7187509929924F1A1DFEEAD8178161D7036A5CA3 ();
// 0x00000014 System.Void UnityEngine.U2D.PixelPerfectCamera::PixelSnap()
extern void PixelPerfectCamera_PixelSnap_m91DD09A7F8EC7047E95D2853591589120C632549 ();
// 0x00000015 System.Void UnityEngine.U2D.PixelPerfectCamera::Awake()
extern void PixelPerfectCamera_Awake_m0EEA0D8C24DDBF0417409FC1ED92D46771038AF6 ();
// 0x00000016 System.Void UnityEngine.U2D.PixelPerfectCamera::LateUpdate()
extern void PixelPerfectCamera_LateUpdate_m38D630FA419C6D0D2208872ED381B96ECAEC69D8 ();
// 0x00000017 System.Void UnityEngine.U2D.PixelPerfectCamera::OnPreCull()
extern void PixelPerfectCamera_OnPreCull_m6E8A8435E206B526BFF26828025289409A981AB6 ();
// 0x00000018 System.Void UnityEngine.U2D.PixelPerfectCamera::OnPreRender()
extern void PixelPerfectCamera_OnPreRender_mF532865494E97AE563AEBE9B4496C9C1B55E87F4 ();
// 0x00000019 System.Void UnityEngine.U2D.PixelPerfectCamera::OnPostRender()
extern void PixelPerfectCamera_OnPostRender_m38D6AE9701187DACFC115503F17C6275AA176D43 ();
// 0x0000001A System.Void UnityEngine.U2D.PixelPerfectCamera::OnEnable()
extern void PixelPerfectCamera_OnEnable_m901D29B12074BAB16C429BAF4B768DE837B6D5F0 ();
// 0x0000001B System.Void UnityEngine.U2D.PixelPerfectCamera::OnDisable()
extern void PixelPerfectCamera_OnDisable_m1ED518FBFC9C85DDC263ADD3BE56571EF7726D96 ();
// 0x0000001C System.Void UnityEngine.U2D.PixelPerfectCamera::.ctor()
extern void PixelPerfectCamera__ctor_mFBF09FC28EF3435A09273EF69AE9D085698F36DF ();
// 0x0000001D System.Int32 UnityEngine.U2D.IPixelPerfectCamera::get_assetsPPU()
// 0x0000001E System.Int32 UnityEngine.U2D.IPixelPerfectCamera::get_refResolutionX()
// 0x0000001F System.Int32 UnityEngine.U2D.IPixelPerfectCamera::get_refResolutionY()
// 0x00000020 System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_upscaleRT()
// 0x00000021 System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_pixelSnapping()
// 0x00000022 System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_cropFrameX()
// 0x00000023 System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_cropFrameY()
// 0x00000024 System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_stretchFill()
// 0x00000025 System.Void UnityEngine.U2D.PixelPerfectCameraInternal::.ctor(UnityEngine.U2D.IPixelPerfectCamera)
extern void PixelPerfectCameraInternal__ctor_m8BED9192421CD4B18053B0FEAEF480CE303ABA5C ();
// 0x00000026 System.Void UnityEngine.U2D.PixelPerfectCameraInternal::OnBeforeSerialize()
extern void PixelPerfectCameraInternal_OnBeforeSerialize_m103DED2AF898C493C950A670BF7148F465D5AE23 ();
// 0x00000027 System.Void UnityEngine.U2D.PixelPerfectCameraInternal::OnAfterDeserialize()
extern void PixelPerfectCameraInternal_OnAfterDeserialize_m8FC18117BF7136FDB3D949F29554D45121F90187 ();
// 0x00000028 System.Void UnityEngine.U2D.PixelPerfectCameraInternal::CalculateCameraProperties(System.Int32,System.Int32)
extern void PixelPerfectCameraInternal_CalculateCameraProperties_mD30D52BC7D19045E2AD048A85CED88C50F3C97A9 ();
// 0x00000029 UnityEngine.Rect UnityEngine.U2D.PixelPerfectCameraInternal::CalculatePostRenderPixelRect(System.Single,System.Int32,System.Int32)
extern void PixelPerfectCameraInternal_CalculatePostRenderPixelRect_mB3065A3B8D92AA9C1C21D38B0B4301C7E814C45E ();
// 0x0000002A System.Single UnityEngine.U2D.PixelPerfectCameraInternal::CorrectCinemachineOrthoSize(System.Single)
extern void PixelPerfectCameraInternal_CorrectCinemachineOrthoSize_mCE913421BC4294451DC3869F2EB052D3B3802ED1 ();
static Il2CppMethodPointer s_methodPointers[42] = 
{
	PixelPerfectCamera_get_assetsPPU_mF294CEA88ED86AF12C3B288A32454145E655081D,
	PixelPerfectCamera_set_assetsPPU_mAF321B9D68BFEEB5F460E85C99EDF3D7165DF270,
	PixelPerfectCamera_get_refResolutionX_mD8E1DCEE1434AAC6761DEE8B73D4D163B858FE58,
	PixelPerfectCamera_set_refResolutionX_mDA8E4201FF94E6B565DA3BFACC5A8B80F26C20C1,
	PixelPerfectCamera_get_refResolutionY_m8C37A3DBC9014F034A78F9E921A11BAA113CB24F,
	PixelPerfectCamera_set_refResolutionY_mD0998785CF628E2E1841B232EDB53AAFDD60D86D,
	PixelPerfectCamera_get_upscaleRT_m36326F6B11D8D2CC33971B805344F2C6458E54C0,
	PixelPerfectCamera_set_upscaleRT_m870AC116618CC6358EB9403A59D7E54F0D56F0A9,
	PixelPerfectCamera_get_pixelSnapping_mF550795A64EA5FF77DECD748CA5FB21C00D9A121,
	PixelPerfectCamera_set_pixelSnapping_m9B77AA59CDF18E388D4E033FB5BDC8F950F36226,
	PixelPerfectCamera_get_cropFrameX_mB81332B181CC77B077B48EC5B7B96CBA73912FA6,
	PixelPerfectCamera_set_cropFrameX_m2E647446C63C83F20E38413E85698C49988E699C,
	PixelPerfectCamera_get_cropFrameY_m4DBB6A286AC29B2213E61B6397754C38E799A5D1,
	PixelPerfectCamera_set_cropFrameY_m3EAE38E3B33718D14E290E711F73406B0DC5FC59,
	PixelPerfectCamera_get_stretchFill_m959164B6C59CB30C7EDDFFE93808C2CEEDFC3847,
	PixelPerfectCamera_set_stretchFill_m82F148F1225AB1B5E5C86043632CF6C3B07FA269,
	PixelPerfectCamera_get_pixelRatio_m8E1DC329C0C7551837F4AE0E1B70B9730042C96F,
	PixelPerfectCamera_RoundToPixel_m53B7AE007CD7E21B1B7DFD76A1F330364369C2D8,
	PixelPerfectCamera_CorrectCinemachineOrthoSize_m7187509929924F1A1DFEEAD8178161D7036A5CA3,
	PixelPerfectCamera_PixelSnap_m91DD09A7F8EC7047E95D2853591589120C632549,
	PixelPerfectCamera_Awake_m0EEA0D8C24DDBF0417409FC1ED92D46771038AF6,
	PixelPerfectCamera_LateUpdate_m38D630FA419C6D0D2208872ED381B96ECAEC69D8,
	PixelPerfectCamera_OnPreCull_m6E8A8435E206B526BFF26828025289409A981AB6,
	PixelPerfectCamera_OnPreRender_mF532865494E97AE563AEBE9B4496C9C1B55E87F4,
	PixelPerfectCamera_OnPostRender_m38D6AE9701187DACFC115503F17C6275AA176D43,
	PixelPerfectCamera_OnEnable_m901D29B12074BAB16C429BAF4B768DE837B6D5F0,
	PixelPerfectCamera_OnDisable_m1ED518FBFC9C85DDC263ADD3BE56571EF7726D96,
	PixelPerfectCamera__ctor_mFBF09FC28EF3435A09273EF69AE9D085698F36DF,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PixelPerfectCameraInternal__ctor_m8BED9192421CD4B18053B0FEAEF480CE303ABA5C,
	PixelPerfectCameraInternal_OnBeforeSerialize_m103DED2AF898C493C950A670BF7148F465D5AE23,
	PixelPerfectCameraInternal_OnAfterDeserialize_m8FC18117BF7136FDB3D949F29554D45121F90187,
	PixelPerfectCameraInternal_CalculateCameraProperties_mD30D52BC7D19045E2AD048A85CED88C50F3C97A9,
	PixelPerfectCameraInternal_CalculatePostRenderPixelRect_mB3065A3B8D92AA9C1C21D38B0B4301C7E814C45E,
	PixelPerfectCameraInternal_CorrectCinemachineOrthoSize_mCE913421BC4294451DC3869F2EB052D3B3802ED1,
};
static const int32_t s_InvokerIndices[42] = 
{
	10,
	32,
	10,
	32,
	10,
	32,
	114,
	31,
	114,
	31,
	114,
	31,
	114,
	31,
	114,
	31,
	10,
	1103,
	1093,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	10,
	10,
	10,
	114,
	114,
	114,
	114,
	114,
	26,
	23,
	23,
	169,
	1586,
	1093,
};
extern const Il2CppCodeGenModule g_Unity_2D_PixelPerfectCodeGenModule;
const Il2CppCodeGenModule g_Unity_2D_PixelPerfectCodeGenModule = 
{
	"Unity.2D.PixelPerfect.dll",
	42,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
