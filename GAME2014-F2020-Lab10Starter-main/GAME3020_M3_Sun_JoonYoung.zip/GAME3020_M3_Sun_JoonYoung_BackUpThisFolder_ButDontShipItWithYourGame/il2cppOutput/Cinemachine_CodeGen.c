﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void CinemachineCameraOffset::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineCameraOffset_PostPipelineStageCallback_m214222457A0BD96712F898260D4D5F9757C1D736 ();
// 0x00000002 System.Void CinemachineCameraOffset::.ctor()
extern void CinemachineCameraOffset__ctor_mBA995110079C215F7AB8FF6DF54C37231C3B5728 ();
// 0x00000003 System.Void CinemachineRecomposer::Reset()
extern void CinemachineRecomposer_Reset_m88525BE6F6B1DF4ABC2E58CCD4E5C95C3ED79A27 ();
// 0x00000004 System.Void CinemachineRecomposer::OnValidate()
extern void CinemachineRecomposer_OnValidate_m9BD3BC5317D1374AEC17027D208741B5A8F62678 ();
// 0x00000005 System.Void CinemachineRecomposer::PrePipelineMutateCameraStateCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CameraState&,System.Single)
extern void CinemachineRecomposer_PrePipelineMutateCameraStateCallback_mDE48BF5922B0CB07EEC0EDA9E1E77D86FF57C203 ();
// 0x00000006 System.Void CinemachineRecomposer::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineRecomposer_PostPipelineStageCallback_mE0BE4A9CF309A03D03861E086ED513AEDC9C3078 ();
// 0x00000007 System.Void CinemachineRecomposer::.ctor()
extern void CinemachineRecomposer__ctor_mA94BEB1150CFE4D50C588D2F5C166B268D7B1362 ();
// 0x00000008 System.Void CinemachineTouchInputMapper::Start()
extern void CinemachineTouchInputMapper_Start_m3AC349B75F081ACCDA532FBFD15F6C4DC5FA7BCC ();
// 0x00000009 System.Single CinemachineTouchInputMapper::GetInputAxis(System.String)
extern void CinemachineTouchInputMapper_GetInputAxis_mC7DB7FBF8CA101DD4F25DC42253932CAFA2F1413 ();
// 0x0000000A System.Void CinemachineTouchInputMapper::.ctor()
extern void CinemachineTouchInputMapper__ctor_mCE60215EA756B6CC9CDE11A6A29355961C35FCFE ();
// 0x0000000B System.Void CinemachineMixer::OnPlayableDestroy(UnityEngine.Playables.Playable)
extern void CinemachineMixer_OnPlayableDestroy_m15D0D97BC182EEA1A886B55A440F3F37FA1B427B ();
// 0x0000000C System.Void CinemachineMixer::PrepareFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
extern void CinemachineMixer_PrepareFrame_mEDA03F2B9CB7AB571903D7BE4CAFA9340020B617 ();
// 0x0000000D System.Void CinemachineMixer::ProcessFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData,System.Object)
extern void CinemachineMixer_ProcessFrame_m34F7C76AC1EB8C4027CD23D54C8A0DF74788076C ();
// 0x0000000E System.Single CinemachineMixer::GetDeltaTime(System.Single)
extern void CinemachineMixer_GetDeltaTime_mAFED8F9148B137A18BB77BBA34B10DC79E4EDBAC ();
// 0x0000000F System.Void CinemachineMixer::.ctor()
extern void CinemachineMixer__ctor_m65687FEE5BF1A97442CCA217DC7E688AF110508A ();
// 0x00000010 UnityEngine.Playables.Playable CinemachineShot::CreatePlayable(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject)
extern void CinemachineShot_CreatePlayable_mEEA36A48B4C1B0AE73DD4E6DB5BB67EDD5CC9FBF ();
// 0x00000011 System.Void CinemachineShot::GatherProperties(UnityEngine.Playables.PlayableDirector,UnityEngine.Timeline.IPropertyCollector)
extern void CinemachineShot_GatherProperties_mD35DE60059D05AA13705B3AA45C1A2D3FD82E2A2 ();
// 0x00000012 System.Void CinemachineShot::.ctor()
extern void CinemachineShot__ctor_m4E0ED8E81339A16B4BBE6833D2891A59F1868F04 ();
// 0x00000013 System.Boolean CinemachineShotPlayable::get_IsValid()
extern void CinemachineShotPlayable_get_IsValid_m783EFC14C1B6E0C331E8BE1FB97BF73E5C0FB085 ();
// 0x00000014 System.Void CinemachineShotPlayable::.ctor()
extern void CinemachineShotPlayable__ctor_m5831073991E80621F1FD0DAE1862F4B47D4FEC58 ();
// 0x00000015 UnityEngine.Playables.Playable CinemachineTrack::CreateTrackMixer(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject,System.Int32)
extern void CinemachineTrack_CreateTrackMixer_mC9AD3E7B72FDAF3BF9ECBFE57BDD75880F7A4346 ();
// 0x00000016 System.Void CinemachineTrack::.ctor()
extern void CinemachineTrack__ctor_m346DCFF5C3E9A01315B9C4F59625F3FFAC3DDBDA ();
// 0x00000017 System.Void Cinemachine.Cinemachine3rdPersonAim::OnValidate()
extern void Cinemachine3rdPersonAim_OnValidate_m1DB2920E91BF684D7E934BC0136839D7ABF49C09 ();
// 0x00000018 System.Void Cinemachine.Cinemachine3rdPersonAim::Reset()
extern void Cinemachine3rdPersonAim_Reset_m76AF226247A9F0C4CCDDF0200876BC01859A17DA ();
// 0x00000019 System.Boolean Cinemachine.Cinemachine3rdPersonAim::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void Cinemachine3rdPersonAim_OnTransitionFromCamera_mB60FDBDAEC3D755C4BC8FF8EB9DB5A8226FE5144 ();
// 0x0000001A System.Void Cinemachine.Cinemachine3rdPersonAim::DrawReticle(Cinemachine.CinemachineBrain)
extern void Cinemachine3rdPersonAim_DrawReticle_m4B256A71AFE3F96910662DEE45FC49FD1BAACD50 ();
// 0x0000001B UnityEngine.Vector3 Cinemachine.Cinemachine3rdPersonAim::GetLookAtPoint(Cinemachine.CameraState&)
extern void Cinemachine3rdPersonAim_GetLookAtPoint_m6EFCD1C8BBBA93A85D2C873ABB33F85025D2E859 ();
// 0x0000001C System.Void Cinemachine.Cinemachine3rdPersonAim::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void Cinemachine3rdPersonAim_PostPipelineStageCallback_m431D6A5A151FC73D58E2BB5C843C4A9D785AED82 ();
// 0x0000001D System.Void Cinemachine.Cinemachine3rdPersonAim::.ctor()
extern void Cinemachine3rdPersonAim__ctor_m3FD0201C504BF089A48A2A2054B8CD3F85DB46EF ();
// 0x0000001E System.String Cinemachine.CinemachineBlendListCamera::get_Description()
extern void CinemachineBlendListCamera_get_Description_m5C6D715F0F62C76E72B28C22E29B85A99F44FB8A ();
// 0x0000001F System.Void Cinemachine.CinemachineBlendListCamera::set_LiveChild(Cinemachine.ICinemachineCamera)
extern void CinemachineBlendListCamera_set_LiveChild_m06CBC3CB11F541FA72E4F5189DA3CDAD2F93A12D ();
// 0x00000020 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBlendListCamera::get_LiveChild()
extern void CinemachineBlendListCamera_get_LiveChild_mC110B712B11C6D0D8BEE7CF35511A88932FB374B ();
// 0x00000021 System.Boolean Cinemachine.CinemachineBlendListCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineBlendListCamera_IsLiveChild_m01E481F15D50EDA15D50F7698A8D4270E9A6DF2D ();
// 0x00000022 Cinemachine.CameraState Cinemachine.CinemachineBlendListCamera::get_State()
extern void CinemachineBlendListCamera_get_State_m0F2CC117E1188ED5E61F263A3F96C99152603997 ();
// 0x00000023 UnityEngine.Transform Cinemachine.CinemachineBlendListCamera::get_LookAt()
extern void CinemachineBlendListCamera_get_LookAt_m4987B243A6841944D9CC1DCEEB208D75DD472D8F ();
// 0x00000024 System.Void Cinemachine.CinemachineBlendListCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineBlendListCamera_set_LookAt_m89A121D81D3A5A9AB901C2490C8582E19D56720B ();
// 0x00000025 UnityEngine.Transform Cinemachine.CinemachineBlendListCamera::get_Follow()
extern void CinemachineBlendListCamera_get_Follow_m4C77B0D9285FF0E0BDE6672AA97CBFEA8F779EAE ();
// 0x00000026 System.Void Cinemachine.CinemachineBlendListCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineBlendListCamera_set_Follow_m11AC198E828F34AA47C3DEDEE0255BB52155E4F3 ();
// 0x00000027 System.Void Cinemachine.CinemachineBlendListCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineBlendListCamera_OnTargetObjectWarped_m064D8A1708A9EC3A8C3781CDDEAE0DD19F26C226 ();
// 0x00000028 System.Void Cinemachine.CinemachineBlendListCamera::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineBlendListCamera_ForceCameraPosition_m8353DC410D5F9C28E6BD4A6E795E8B02C2AD102F ();
// 0x00000029 System.Void Cinemachine.CinemachineBlendListCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineBlendListCamera_OnTransitionFromCamera_m0A4B32A2C54128881A91D1AC80C83EA626FF6403 ();
// 0x0000002A Cinemachine.ICinemachineCamera Cinemachine.CinemachineBlendListCamera::get_TransitioningFrom()
extern void CinemachineBlendListCamera_get_TransitioningFrom_mD6696F8110804BEA7C73ECE7815C01349DA80ADD ();
// 0x0000002B System.Void Cinemachine.CinemachineBlendListCamera::set_TransitioningFrom(Cinemachine.ICinemachineCamera)
extern void CinemachineBlendListCamera_set_TransitioningFrom_mAD76B896D15BE8EC438A9527249DC62FD696EE0D ();
// 0x0000002C System.Void Cinemachine.CinemachineBlendListCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineBlendListCamera_InternalUpdateCameraState_m58770001B7B5AC14E824882B59611938B64B289D ();
// 0x0000002D System.Void Cinemachine.CinemachineBlendListCamera::OnEnable()
extern void CinemachineBlendListCamera_OnEnable_m64064AC70DFF2427499FE68274AC45E753D556CA ();
// 0x0000002E System.Void Cinemachine.CinemachineBlendListCamera::OnDisable()
extern void CinemachineBlendListCamera_OnDisable_m46FCC8C90F9233ED5528545F728D23B8AEC439FA ();
// 0x0000002F System.Void Cinemachine.CinemachineBlendListCamera::OnTransformChildrenChanged()
extern void CinemachineBlendListCamera_OnTransformChildrenChanged_m08CB2CA52EDFE41199C966A34F478C3D85425EC2 ();
// 0x00000030 System.Void Cinemachine.CinemachineBlendListCamera::OnGuiHandler()
extern void CinemachineBlendListCamera_OnGuiHandler_m58B69E2CCF7FA61E5DD1934735E6873DCF379FD0 ();
// 0x00000031 Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineBlendListCamera::get_ChildCameras()
extern void CinemachineBlendListCamera_get_ChildCameras_m85978F41F7E12760B36BE29F70107684A229295D ();
// 0x00000032 System.Boolean Cinemachine.CinemachineBlendListCamera::get_IsBlending()
extern void CinemachineBlendListCamera_get_IsBlending_m0BAA4ACB2EBA83796F4E210F8E870329676F4708 ();
// 0x00000033 System.Void Cinemachine.CinemachineBlendListCamera::InvalidateListOfChildren()
extern void CinemachineBlendListCamera_InvalidateListOfChildren_m1A851A8A2A3D12271AEBCB7CB52D014AEB6920ED ();
// 0x00000034 System.Void Cinemachine.CinemachineBlendListCamera::UpdateListOfChildren()
extern void CinemachineBlendListCamera_UpdateListOfChildren_m78195EDC229BA08AB69C876F0574217BFAFCEBB5 ();
// 0x00000035 System.Void Cinemachine.CinemachineBlendListCamera::ValidateInstructions()
extern void CinemachineBlendListCamera_ValidateInstructions_m39EE271A6D34B62732B978205EBF6681B6657ECC ();
// 0x00000036 System.Void Cinemachine.CinemachineBlendListCamera::AdvanceCurrentInstruction(System.Single)
extern void CinemachineBlendListCamera_AdvanceCurrentInstruction_m6AE0D5A3A44F65265B9C461AAA1C577D80527DDF ();
// 0x00000037 System.Void Cinemachine.CinemachineBlendListCamera::.ctor()
extern void CinemachineBlendListCamera__ctor_m415640A76DED96AA7D39819787BACBC3220728C5 ();
// 0x00000038 UnityEngine.Camera Cinemachine.CinemachineBrain::get_OutputCamera()
extern void CinemachineBrain_get_OutputCamera_m53C6A01A6715756C5A1B80FB403453B3CB28DF84 ();
// 0x00000039 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBrain::get_SoloCamera()
extern void CinemachineBrain_get_SoloCamera_mEAD650442E6D40F860F2668FD0BFEA14495B1F48 ();
// 0x0000003A System.Void Cinemachine.CinemachineBrain::set_SoloCamera(Cinemachine.ICinemachineCamera)
extern void CinemachineBrain_set_SoloCamera_mCDFED6D67E47D86163AAB3B63A60BB335586FC58 ();
// 0x0000003B UnityEngine.Color Cinemachine.CinemachineBrain::GetSoloGUIColor()
extern void CinemachineBrain_GetSoloGUIColor_m1EDE8585C43B473EDAA59D61D558D83F356E45F8 ();
// 0x0000003C UnityEngine.Vector3 Cinemachine.CinemachineBrain::get_DefaultWorldUp()
extern void CinemachineBrain_get_DefaultWorldUp_mA052F23DFC679E1E0E15B2466ECB3799B656CBA4 ();
// 0x0000003D System.Void Cinemachine.CinemachineBrain::OnEnable()
extern void CinemachineBrain_OnEnable_m444560E00F8FE814A13A5C18076C4ECFE09A9C12 ();
// 0x0000003E System.Void Cinemachine.CinemachineBrain::OnDisable()
extern void CinemachineBrain_OnDisable_mD0002ADB05DE5396E8782571436DC874A098FC1E ();
// 0x0000003F System.Void Cinemachine.CinemachineBrain::OnSceneLoaded(UnityEngine.SceneManagement.Scene,UnityEngine.SceneManagement.LoadSceneMode)
extern void CinemachineBrain_OnSceneLoaded_mA0F14A6DD8BC5E68243E6879425E49935DBF7900 ();
// 0x00000040 System.Void Cinemachine.CinemachineBrain::OnSceneUnloaded(UnityEngine.SceneManagement.Scene)
extern void CinemachineBrain_OnSceneUnloaded_m623A93AF5BB2A7967B0DB47A564EBE856CFC8204 ();
// 0x00000041 System.Void Cinemachine.CinemachineBrain::Start()
extern void CinemachineBrain_Start_m851FA02E684EC0C99687B63CAA12F595C5625BF8 ();
// 0x00000042 System.Void Cinemachine.CinemachineBrain::OnGuiHandler()
extern void CinemachineBrain_OnGuiHandler_m8EBDE5B960F8BD057B3ACEBAB75AC10492B798D8 ();
// 0x00000043 System.Collections.IEnumerator Cinemachine.CinemachineBrain::AfterPhysics()
extern void CinemachineBrain_AfterPhysics_mAD691C1010D2426873FE5A5463646DDB307B4410 ();
// 0x00000044 System.Void Cinemachine.CinemachineBrain::LateUpdate()
extern void CinemachineBrain_LateUpdate_mE2D66C0664D1B0552A07D508C9D08C6167A0F1CD ();
// 0x00000045 System.Void Cinemachine.CinemachineBrain::ManualUpdate()
extern void CinemachineBrain_ManualUpdate_m8D7A7301585B6A15E708BEA2E148B1C7F2F7A487 ();
// 0x00000046 System.Single Cinemachine.CinemachineBrain::GetEffectiveDeltaTime(System.Boolean)
extern void CinemachineBrain_GetEffectiveDeltaTime_m27D6E0AC28FA42C74DD804AB942F0D496D55379B ();
// 0x00000047 System.Void Cinemachine.CinemachineBrain::UpdateVirtualCameras(Cinemachine.CinemachineCore_UpdateFilter,System.Single)
extern void CinemachineBrain_UpdateVirtualCameras_mCA6172FE9872138FF4D2B3867EE7AB5BE6D47F89 ();
// 0x00000048 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBrain::get_ActiveVirtualCamera()
extern void CinemachineBrain_get_ActiveVirtualCamera_m9111F4A789B4CCE529CDDE345F8B690EFEC2C63B ();
// 0x00000049 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBrain::DeepCamBFromBlend(Cinemachine.CinemachineBlend)
extern void CinemachineBrain_DeepCamBFromBlend_m982D9725A5164F9EBF00366A2D49745179A60A46 ();
// 0x0000004A System.Boolean Cinemachine.CinemachineBrain::get_IsBlending()
extern void CinemachineBrain_get_IsBlending_mA7662615642DEFD6893E2D6872A78CEA253474B2 ();
// 0x0000004B Cinemachine.CinemachineBlend Cinemachine.CinemachineBrain::get_ActiveBlend()
extern void CinemachineBrain_get_ActiveBlend_m03CD7DFA8C5D537BEB972918C6F4D2BB2FDB7F15 ();
// 0x0000004C System.Int32 Cinemachine.CinemachineBrain::GetBrainFrame(System.Int32)
extern void CinemachineBrain_GetBrainFrame_m993AEAFCA2ACA814C76097EFF86FE895258861A5 ();
// 0x0000004D System.Int32 Cinemachine.CinemachineBrain::SetCameraOverride(System.Int32,Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,System.Single,System.Single)
extern void CinemachineBrain_SetCameraOverride_m9B06A2796330BE39B59E4DD8E1A40EDCDA969967 ();
// 0x0000004E System.Void Cinemachine.CinemachineBrain::ReleaseCameraOverride(System.Int32)
extern void CinemachineBrain_ReleaseCameraOverride_m83F54FD0A6837603DDCE2090AC3FDD0A0BAE30DF ();
// 0x0000004F System.Void Cinemachine.CinemachineBrain::ProcessActiveCamera(System.Single)
extern void CinemachineBrain_ProcessActiveCamera_m094A1972B629F11EB580679FEFD78076769180FF ();
// 0x00000050 System.Void Cinemachine.CinemachineBrain::UpdateFrame0(System.Single)
extern void CinemachineBrain_UpdateFrame0_m8FD42266AA4C2CCE09B842A5BA7362126585858B ();
// 0x00000051 System.Void Cinemachine.CinemachineBrain::ComputeCurrentBlend(Cinemachine.CinemachineBlend&,System.Int32)
extern void CinemachineBrain_ComputeCurrentBlend_m296BA72649974D928612AFC717D7446C028F3858 ();
// 0x00000052 System.Boolean Cinemachine.CinemachineBrain::IsLive(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineBrain_IsLive_mF74210376333DD9865A075E561E6E3DDED510FB2 ();
// 0x00000053 Cinemachine.CameraState Cinemachine.CinemachineBrain::get_CurrentCameraState()
extern void CinemachineBrain_get_CurrentCameraState_mBC8B24EFB25ADD71E4E007CDD351ED790FA76243 ();
// 0x00000054 System.Void Cinemachine.CinemachineBrain::set_CurrentCameraState(Cinemachine.CameraState)
extern void CinemachineBrain_set_CurrentCameraState_m2624A063E4A16EDCC8E1F8FFB93E96F74E98882B ();
// 0x00000055 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBrain::TopCameraFromPriorityQueue()
extern void CinemachineBrain_TopCameraFromPriorityQueue_m81361016B63A4BF68BA4D85452BAE8647B90E9EF ();
// 0x00000056 Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineBrain::LookupBlend(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera)
extern void CinemachineBrain_LookupBlend_mEBAE63022CC081EAF26489C7BBEC2492F32B7FDD ();
// 0x00000057 System.Void Cinemachine.CinemachineBrain::PushStateToUnityCamera(Cinemachine.CameraState)
extern void CinemachineBrain_PushStateToUnityCamera_mBD15F314BC5F547CEED4C36EEDE279E11DCADB6B ();
// 0x00000058 System.Void Cinemachine.CinemachineBrain::.ctor()
extern void CinemachineBrain__ctor_m86D8371115D9B5138648C75C3135396823DD43EE ();
// 0x00000059 System.Void Cinemachine.CinemachineBrain::.cctor()
extern void CinemachineBrain__cctor_mECCA7F7ABF8660A2BAB11A39B29D9923D2361DD8 ();
// 0x0000005A System.String Cinemachine.CinemachineClearShot::get_Description()
extern void CinemachineClearShot_get_Description_m7AF5F30369B2273697549B4E458FD3D7FE7AE694 ();
// 0x0000005B System.Void Cinemachine.CinemachineClearShot::set_LiveChild(Cinemachine.ICinemachineCamera)
extern void CinemachineClearShot_set_LiveChild_m51685341391760EC4E1053AC1555A39A06185B1E ();
// 0x0000005C Cinemachine.ICinemachineCamera Cinemachine.CinemachineClearShot::get_LiveChild()
extern void CinemachineClearShot_get_LiveChild_m0E247D53C258CE36DBF28944CD0AD8A47344C4A2 ();
// 0x0000005D Cinemachine.CameraState Cinemachine.CinemachineClearShot::get_State()
extern void CinemachineClearShot_get_State_m5596F81F599D82C8FE6A5383E95D3DF4F803EF7A ();
// 0x0000005E System.Boolean Cinemachine.CinemachineClearShot::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineClearShot_IsLiveChild_m27778431D3DC199BD4A07283966ABC71F323942E ();
// 0x0000005F UnityEngine.Transform Cinemachine.CinemachineClearShot::get_LookAt()
extern void CinemachineClearShot_get_LookAt_mACAC39B62BB18C014CB0EE0829D37854DEEF1547 ();
// 0x00000060 System.Void Cinemachine.CinemachineClearShot::set_LookAt(UnityEngine.Transform)
extern void CinemachineClearShot_set_LookAt_mE444F2137C96A179F9A0DCCACC9D5BEC30C075D4 ();
// 0x00000061 UnityEngine.Transform Cinemachine.CinemachineClearShot::get_Follow()
extern void CinemachineClearShot_get_Follow_mCBA54E3955A8DEBD46828F16EAE00AA2B8678C56 ();
// 0x00000062 System.Void Cinemachine.CinemachineClearShot::set_Follow(UnityEngine.Transform)
extern void CinemachineClearShot_set_Follow_mA1A33A5BF458CB7FE8CE965EA59F8F5335128BDE ();
// 0x00000063 System.Void Cinemachine.CinemachineClearShot::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineClearShot_OnTargetObjectWarped_mFA9A79ADB2FA4A94D6FD73CBF32B38DBA4E34F7D ();
// 0x00000064 System.Void Cinemachine.CinemachineClearShot::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineClearShot_ForceCameraPosition_m64A96229F7CD5AFC4C163184CABDE5ACED9A027B ();
// 0x00000065 System.Void Cinemachine.CinemachineClearShot::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineClearShot_InternalUpdateCameraState_m0E642E1D33C0F0BB0628E439A78574B381F08B29 ();
// 0x00000066 System.Void Cinemachine.CinemachineClearShot::OnEnable()
extern void CinemachineClearShot_OnEnable_m6FD19FC685EFF8D2432861E8B6FBDDA02A954220 ();
// 0x00000067 System.Void Cinemachine.CinemachineClearShot::OnDisable()
extern void CinemachineClearShot_OnDisable_mC02AEC329D9BDB5D6ADFF762B38DD7260C6780F5 ();
// 0x00000068 System.Void Cinemachine.CinemachineClearShot::OnTransformChildrenChanged()
extern void CinemachineClearShot_OnTransformChildrenChanged_mF8891487D72C8C87FDE3AF59FC308492AFD719EA ();
// 0x00000069 System.Void Cinemachine.CinemachineClearShot::OnGuiHandler()
extern void CinemachineClearShot_OnGuiHandler_m62267DB468A7AB10E6834C1EAC49A795349E59FA ();
// 0x0000006A System.Boolean Cinemachine.CinemachineClearShot::get_IsBlending()
extern void CinemachineClearShot_get_IsBlending_mA2F2B1313AB3374D1D1287D67992D756C42587DA ();
// 0x0000006B Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineClearShot::get_ChildCameras()
extern void CinemachineClearShot_get_ChildCameras_m1F32604733AC3601B4843C072342F408CE19C5B6 ();
// 0x0000006C System.Void Cinemachine.CinemachineClearShot::InvalidateListOfChildren()
extern void CinemachineClearShot_InvalidateListOfChildren_mB0CD028BA2D3286D654F260940BBC2234A7038EB ();
// 0x0000006D System.Void Cinemachine.CinemachineClearShot::ResetRandomization()
extern void CinemachineClearShot_ResetRandomization_m1876DCD195CD2865599F23957CBCCF07F9557109 ();
// 0x0000006E System.Void Cinemachine.CinemachineClearShot::UpdateListOfChildren()
extern void CinemachineClearShot_UpdateListOfChildren_m37DF613332B66C99EF46A5D338356B90A1D0894E ();
// 0x0000006F Cinemachine.ICinemachineCamera Cinemachine.CinemachineClearShot::ChooseCurrentCamera(UnityEngine.Vector3)
extern void CinemachineClearShot_ChooseCurrentCamera_m678A067854D8A908119247136EA38448E98C7F22 ();
// 0x00000070 Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineClearShot::Randomize(Cinemachine.CinemachineVirtualCameraBase[])
extern void CinemachineClearShot_Randomize_m8B9933410E1461B3C79A0CE6C332868954306FC7 ();
// 0x00000071 Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineClearShot::LookupBlend(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera)
extern void CinemachineClearShot_LookupBlend_mEC42F1C07A25A4D873D61AB6F6CB6C26491E4D83 ();
// 0x00000072 System.Void Cinemachine.CinemachineClearShot::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineClearShot_OnTransitionFromCamera_mEA5216EB1E80B4DC87F35CEE0646FAF2216BFA9B ();
// 0x00000073 Cinemachine.ICinemachineCamera Cinemachine.CinemachineClearShot::get_TransitioningFrom()
extern void CinemachineClearShot_get_TransitioningFrom_m9C6A21D455B4DF835AB81F4FC5B929AF8E6228C8 ();
// 0x00000074 System.Void Cinemachine.CinemachineClearShot::set_TransitioningFrom(Cinemachine.ICinemachineCamera)
extern void CinemachineClearShot_set_TransitioningFrom_mBB426F06C8C9E05C7DDBCD76C6001071AB80CA3B ();
// 0x00000075 System.Void Cinemachine.CinemachineClearShot::.ctor()
extern void CinemachineClearShot__ctor_m5E1633DD8F3F1811A0F4CB5335B4098A691C16BA ();
// 0x00000076 System.Boolean Cinemachine.CinemachineCollider::IsTargetObscured(Cinemachine.ICinemachineCamera)
extern void CinemachineCollider_IsTargetObscured_m728B54117D657C72C3A45B15D097376B916AD081 ();
// 0x00000077 System.Boolean Cinemachine.CinemachineCollider::CameraWasDisplaced(Cinemachine.ICinemachineCamera)
extern void CinemachineCollider_CameraWasDisplaced_mE3C7D73AC6F29D59A945EB4B6E1DFF1A407D7069 ();
// 0x00000078 System.Single Cinemachine.CinemachineCollider::GetCameraDisplacementDistance(Cinemachine.ICinemachineCamera)
extern void CinemachineCollider_GetCameraDisplacementDistance_m97DED641EC9ECB65AFAE1E0687AF9DF5A7A073BC ();
// 0x00000079 System.Void Cinemachine.CinemachineCollider::OnValidate()
extern void CinemachineCollider_OnValidate_mDFCD2F62D4D4C8487A1041106507A47134048FF0 ();
// 0x0000007A System.Void Cinemachine.CinemachineCollider::OnDestroy()
extern void CinemachineCollider_OnDestroy_m5CCC19D44E691B93F05BA2CFAF07B48D2EFA9091 ();
// 0x0000007B System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector3>> Cinemachine.CinemachineCollider::get_DebugPaths()
extern void CinemachineCollider_get_DebugPaths_m10FD1111E853455483AAF675CDBB7ACCF6E967EC ();
// 0x0000007C System.Single Cinemachine.CinemachineCollider::GetMaxDampTime()
extern void CinemachineCollider_GetMaxDampTime_m7D8E44771355BC2FD8C428861A42C21A7B90695A ();
// 0x0000007D System.Void Cinemachine.CinemachineCollider::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineCollider_PostPipelineStageCallback_m91F23EE95689CCBCF63C89951CE9A4EE726F59CC ();
// 0x0000007E UnityEngine.Vector3 Cinemachine.CinemachineCollider::PreserveLignOfSight(Cinemachine.CameraState&,Cinemachine.CinemachineCollider_VcamExtraState&)
extern void CinemachineCollider_PreserveLignOfSight_m91DEF8619148FAD00657A1D5A460495589CDB56C ();
// 0x0000007F UnityEngine.Vector3 Cinemachine.CinemachineCollider::PullCameraInFrontOfNearestObstacle(UnityEngine.Vector3,UnityEngine.Vector3,System.Int32,UnityEngine.RaycastHit&)
extern void CinemachineCollider_PullCameraInFrontOfNearestObstacle_m831839A6F16DC4AEE8B11341B5752D0E1402BCDE ();
// 0x00000080 UnityEngine.Vector3 Cinemachine.CinemachineCollider::PushCameraBack(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.RaycastHit,UnityEngine.Vector3,UnityEngine.Plane,System.Single,System.Int32,Cinemachine.CinemachineCollider_VcamExtraState&)
extern void CinemachineCollider_PushCameraBack_mEA413F0258A0E497FF47208E7C38D607A3E95772 ();
// 0x00000081 System.Boolean Cinemachine.CinemachineCollider::GetWalkingDirection(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.RaycastHit,UnityEngine.Vector3&)
extern void CinemachineCollider_GetWalkingDirection_mD0BA4C78DA9671058C3E0DF9AC27661882685D1B ();
// 0x00000082 System.Single Cinemachine.CinemachineCollider::GetPushBackDistance(UnityEngine.Ray,UnityEngine.Plane,System.Single,UnityEngine.Vector3)
extern void CinemachineCollider_GetPushBackDistance_m8467D939C839D655437168AE18EBA9469EFE71B8 ();
// 0x00000083 System.Single Cinemachine.CinemachineCollider::ClampRayToBounds(UnityEngine.Ray,System.Single,UnityEngine.Bounds)
extern void CinemachineCollider_ClampRayToBounds_mDE4466A0D48B3C73C69C92A9BB69ECE3E703FA0E ();
// 0x00000084 System.Void Cinemachine.CinemachineCollider::DestroyCollider()
extern void CinemachineCollider_DestroyCollider_m9E697592872A9B4F2C5D5096CBFAA54882CEC800 ();
// 0x00000085 UnityEngine.Vector3 Cinemachine.CinemachineCollider::RespectCameraRadius(UnityEngine.Vector3,Cinemachine.CameraState&)
extern void CinemachineCollider_RespectCameraRadius_m06B1B729256E1787E9FAE46241267FA08E299D4A ();
// 0x00000086 System.Boolean Cinemachine.CinemachineCollider::CheckForTargetObstructions(Cinemachine.CameraState)
extern void CinemachineCollider_CheckForTargetObstructions_m525473EF0F2669CD7B83EAA3CE790B11B632D63B ();
// 0x00000087 System.Boolean Cinemachine.CinemachineCollider::IsTargetOffscreen(Cinemachine.CameraState)
extern void CinemachineCollider_IsTargetOffscreen_mEBE97ED4E2F75864D24A6E055BE9133E71732E2C ();
// 0x00000088 System.Void Cinemachine.CinemachineCollider::.ctor()
extern void CinemachineCollider__ctor_m3543A3A2E03D8A030138D79AAEC58065C03D2994 ();
// 0x00000089 System.Boolean Cinemachine.CinemachineConfiner::CameraWasDisplaced(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineConfiner_CameraWasDisplaced_m83D1EF33F9ED6B52144AB0D3218D2126512B408F ();
// 0x0000008A System.Single Cinemachine.CinemachineConfiner::GetCameraDisplacementDistance(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineConfiner_GetCameraDisplacementDistance_mAE964ADE185900F3A1963C8F6008C10F6E9E6975 ();
// 0x0000008B System.Void Cinemachine.CinemachineConfiner::OnValidate()
extern void CinemachineConfiner_OnValidate_mD463ED5B94F6B858300D99F45438D5F0FBD949DE ();
// 0x0000008C System.Void Cinemachine.CinemachineConfiner::ConnectToVcam(System.Boolean)
extern void CinemachineConfiner_ConnectToVcam_m3DF3703EBA5E402116E0B99FA7F7B7FFDB58497C ();
// 0x0000008D System.Boolean Cinemachine.CinemachineConfiner::get_IsValid()
extern void CinemachineConfiner_get_IsValid_m87C7AC9111017572EEACBF7B38926E5A10F81EF5 ();
// 0x0000008E System.Single Cinemachine.CinemachineConfiner::GetMaxDampTime()
extern void CinemachineConfiner_GetMaxDampTime_m445F5B5483E8A1058DB72F4376C34FA5B66275A7 ();
// 0x0000008F System.Void Cinemachine.CinemachineConfiner::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineConfiner_PostPipelineStageCallback_m042478453BC335A0410635B429516D39992E2BDE ();
// 0x00000090 System.Void Cinemachine.CinemachineConfiner::InvalidatePathCache()
extern void CinemachineConfiner_InvalidatePathCache_m1C66E34112C65B4CDACC628AD8D7F8C90F45706B ();
// 0x00000091 System.Boolean Cinemachine.CinemachineConfiner::ValidatePathCache()
extern void CinemachineConfiner_ValidatePathCache_m249EEFABC4DDAD7D8CBAC54CE0C7F5CF2BF90CBE ();
// 0x00000092 UnityEngine.Vector3 Cinemachine.CinemachineConfiner::ConfinePoint(UnityEngine.Vector3)
extern void CinemachineConfiner_ConfinePoint_m7AE2FFDCD682C31954A51D4F0401FCC00642660A ();
// 0x00000093 UnityEngine.Vector3 Cinemachine.CinemachineConfiner::ConfineScreenEdges(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CameraState&)
extern void CinemachineConfiner_ConfineScreenEdges_m3EF25363525ACDADF5D9A7AFFBD5805A4B9908FA ();
// 0x00000094 System.Void Cinemachine.CinemachineConfiner::.ctor()
extern void CinemachineConfiner__ctor_m51000A5BAF0EEDF46F862CB2C77BCBDF41035C68 ();
// 0x00000095 System.Void Cinemachine.CinemachineDollyCart::FixedUpdate()
extern void CinemachineDollyCart_FixedUpdate_m4D0344645368A13DE5E1902FD2409FD75EF64622 ();
// 0x00000096 System.Void Cinemachine.CinemachineDollyCart::Update()
extern void CinemachineDollyCart_Update_m7245871A1EF878D2225D3278616830FFDEA94632 ();
// 0x00000097 System.Void Cinemachine.CinemachineDollyCart::LateUpdate()
extern void CinemachineDollyCart_LateUpdate_m31652825AA7DF3A37F1FF45F7987A41FF15EB629 ();
// 0x00000098 System.Void Cinemachine.CinemachineDollyCart::SetCartPosition(System.Single)
extern void CinemachineDollyCart_SetCartPosition_mF463212396484570037D81562ED14A21ECFD746F ();
// 0x00000099 System.Void Cinemachine.CinemachineDollyCart::.ctor()
extern void CinemachineDollyCart__ctor_m10FE44DB9AC13A98B146DF4DAAE74E0B642E5068 ();
// 0x0000009A Cinemachine.CameraState Cinemachine.CinemachineExternalCamera::get_State()
extern void CinemachineExternalCamera_get_State_mC19729B5B332F8A68ACFF3A3AA3594610B52D7FE ();
// 0x0000009B UnityEngine.Transform Cinemachine.CinemachineExternalCamera::get_LookAt()
extern void CinemachineExternalCamera_get_LookAt_m4BBF19283ED8933F78E0A0947D31E21952029ED4 ();
// 0x0000009C System.Void Cinemachine.CinemachineExternalCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineExternalCamera_set_LookAt_m6B06EE0A2DF54EBCACFB4AF2FDFA7CE1FBA6956D ();
// 0x0000009D UnityEngine.Transform Cinemachine.CinemachineExternalCamera::get_Follow()
extern void CinemachineExternalCamera_get_Follow_m8FD9C12520C69C131111698EA1C532595B2F795A ();
// 0x0000009E System.Void Cinemachine.CinemachineExternalCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineExternalCamera_set_Follow_mE72DB58A3B9A095A004E9A11F5A13E07DB40DB8E ();
// 0x0000009F System.Void Cinemachine.CinemachineExternalCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineExternalCamera_InternalUpdateCameraState_m51FFCDE49F3209EF2A25426838FE54BEA17736C9 ();
// 0x000000A0 System.Void Cinemachine.CinemachineExternalCamera::.ctor()
extern void CinemachineExternalCamera__ctor_m3F3ABDD19589BAA8C55855E465E86F94B7C21DA8 ();
// 0x000000A1 System.Void Cinemachine.CinemachineFollowZoom::OnValidate()
extern void CinemachineFollowZoom_OnValidate_mC3D5E5866F335052F48BD2B6AA47859E9AE291DB ();
// 0x000000A2 System.Single Cinemachine.CinemachineFollowZoom::GetMaxDampTime()
extern void CinemachineFollowZoom_GetMaxDampTime_m7FCFDC2095BEE662F4AC60386D268C2224984F66 ();
// 0x000000A3 System.Void Cinemachine.CinemachineFollowZoom::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineFollowZoom_PostPipelineStageCallback_m584E4DE4F681FE16D996E5D6FBE4A17F2FF5B4B3 ();
// 0x000000A4 System.Void Cinemachine.CinemachineFollowZoom::.ctor()
extern void CinemachineFollowZoom__ctor_mB268F9C261AF80E1B1B8CBD60F439C7CBA594E43 ();
// 0x000000A5 System.Void Cinemachine.CinemachineFreeLook::OnValidate()
extern void CinemachineFreeLook_OnValidate_mE135CB8F257CA150B766E7490EDB6617686C1FC8 ();
// 0x000000A6 Cinemachine.CinemachineVirtualCamera Cinemachine.CinemachineFreeLook::GetRig(System.Int32)
extern void CinemachineFreeLook_GetRig_mD0E1903ADCEA69937E23407FC0837F5EED5F7D2B ();
// 0x000000A7 System.String[] Cinemachine.CinemachineFreeLook::get_RigNames()
extern void CinemachineFreeLook_get_RigNames_m28ACE9396AC7E90228CF3E5AFB579391AEC91B26 ();
// 0x000000A8 System.Void Cinemachine.CinemachineFreeLook::OnEnable()
extern void CinemachineFreeLook_OnEnable_mF37DBE66B28EFDB12E5EB7E2FECDE8D387E4EA64 ();
// 0x000000A9 System.Void Cinemachine.CinemachineFreeLook::UpdateInputAxisProvider()
extern void CinemachineFreeLook_UpdateInputAxisProvider_mD39FCA17EFAEAF3B386FAB2D171614DBE6878BE4 ();
// 0x000000AA System.Void Cinemachine.CinemachineFreeLook::OnDestroy()
extern void CinemachineFreeLook_OnDestroy_mE5A0B7181DD0B540EA62AA950FFB709B6FE37881 ();
// 0x000000AB System.Void Cinemachine.CinemachineFreeLook::OnTransformChildrenChanged()
extern void CinemachineFreeLook_OnTransformChildrenChanged_m736136F5AEFE8FCEE9AE92AC05BC9F99FBD77021 ();
// 0x000000AC System.Void Cinemachine.CinemachineFreeLook::Reset()
extern void CinemachineFreeLook_Reset_mD2D2A20865B0566F643B934832120872678945C4 ();
// 0x000000AD System.Boolean Cinemachine.CinemachineFreeLook::get_PreviousStateIsValid()
extern void CinemachineFreeLook_get_PreviousStateIsValid_m5401DE3AB054991B6A5FE6234347ECE270585DE1 ();
// 0x000000AE System.Void Cinemachine.CinemachineFreeLook::set_PreviousStateIsValid(System.Boolean)
extern void CinemachineFreeLook_set_PreviousStateIsValid_m55D8DBBB19BE26486ED23321D4F636209A4EADD3 ();
// 0x000000AF Cinemachine.CameraState Cinemachine.CinemachineFreeLook::get_State()
extern void CinemachineFreeLook_get_State_mC1F5503F677EFDBE8F7C13AB4861A85289B11851 ();
// 0x000000B0 UnityEngine.Transform Cinemachine.CinemachineFreeLook::get_LookAt()
extern void CinemachineFreeLook_get_LookAt_mDC4E1C325D8ABCE90EA23927B556A1CEDCE2E466 ();
// 0x000000B1 System.Void Cinemachine.CinemachineFreeLook::set_LookAt(UnityEngine.Transform)
extern void CinemachineFreeLook_set_LookAt_m6469D5D82E61E12547F31B056318A02901320ED9 ();
// 0x000000B2 UnityEngine.Transform Cinemachine.CinemachineFreeLook::get_Follow()
extern void CinemachineFreeLook_get_Follow_mAE291B3D732A26FB2F8303A21E5B02C7B0F71AD5 ();
// 0x000000B3 System.Void Cinemachine.CinemachineFreeLook::set_Follow(UnityEngine.Transform)
extern void CinemachineFreeLook_set_Follow_m60B250844E32FA860F71485B30FC96E6DFC39C12 ();
// 0x000000B4 System.Boolean Cinemachine.CinemachineFreeLook::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineFreeLook_IsLiveChild_mE77CF2865D9484DBC51179C160279DE1A2AB75A0 ();
// 0x000000B5 System.Void Cinemachine.CinemachineFreeLook::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineFreeLook_OnTargetObjectWarped_m9538B8833BA2618E0DFFB92D2D5E21EBE2F6F378 ();
// 0x000000B6 System.Void Cinemachine.CinemachineFreeLook::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineFreeLook_ForceCameraPosition_m61E084EAFA63BD5901D9471DBECA196063CD2BCF ();
// 0x000000B7 System.Void Cinemachine.CinemachineFreeLook::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineFreeLook_InternalUpdateCameraState_m4BEF8106D7C7379527BED810D348A1AEE7B456E4 ();
// 0x000000B8 System.Void Cinemachine.CinemachineFreeLook::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineFreeLook_OnTransitionFromCamera_m7A5C9529C4641C09776A3F5B87B9A8D698C3DE6D ();
// 0x000000B9 System.Single Cinemachine.CinemachineFreeLook::GetYAxisClosestValue(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineFreeLook_GetYAxisClosestValue_m0305399E0E68EE0A9FA2F56EFAE695517C79F584 ();
// 0x000000BA System.Void Cinemachine.CinemachineFreeLook::InvalidateRigCache()
extern void CinemachineFreeLook_InvalidateRigCache_m55DF47CBD6057175CBC0513574054639D51D6C7E ();
// 0x000000BB System.Void Cinemachine.CinemachineFreeLook::DestroyRigs()
extern void CinemachineFreeLook_DestroyRigs_m46892877143B854CDA899600B23F789F092FFA79 ();
// 0x000000BC Cinemachine.CinemachineVirtualCamera[] Cinemachine.CinemachineFreeLook::CreateRigs(Cinemachine.CinemachineVirtualCamera[])
extern void CinemachineFreeLook_CreateRigs_m1B4A9DC51DCE61E3B384B49E75E94FEA50B865E6 ();
// 0x000000BD System.Void Cinemachine.CinemachineFreeLook::UpdateRigCache()
extern void CinemachineFreeLook_UpdateRigCache_m1D9A5655874FB2B2BFF82C8B4CAE75B804A9D458 ();
// 0x000000BE System.Int32 Cinemachine.CinemachineFreeLook::LocateExistingRigs(System.String[],System.Boolean)
extern void CinemachineFreeLook_LocateExistingRigs_mFA72C01A434055FF70E58504CBE649C3A19A935E ();
// 0x000000BF System.Single Cinemachine.CinemachineFreeLook::get_CachedXAxisHeading()
extern void CinemachineFreeLook_get_CachedXAxisHeading_m7B1719BF031EED297D56A9DB32C2F63C018CB636 ();
// 0x000000C0 System.Void Cinemachine.CinemachineFreeLook::set_CachedXAxisHeading(System.Single)
extern void CinemachineFreeLook_set_CachedXAxisHeading_m11AEDBEB4865CFECA9235C8D3320B45DE0EC56C1 ();
// 0x000000C1 System.Single Cinemachine.CinemachineFreeLook::UpdateXAxisHeading(Cinemachine.CinemachineOrbitalTransposer,System.Single,UnityEngine.Vector3)
extern void CinemachineFreeLook_UpdateXAxisHeading_mC7FB1633258C9ADCBE6D379B3865D1DFCB696088 ();
// 0x000000C2 System.Void Cinemachine.CinemachineFreeLook::PushSettingsToRigs()
extern void CinemachineFreeLook_PushSettingsToRigs_mEEA5AE1B6B7E64CD3E52DAD1F020AF52C2D5C030 ();
// 0x000000C3 System.Single Cinemachine.CinemachineFreeLook::GetYAxisValue()
extern void CinemachineFreeLook_GetYAxisValue_m82E8DA8F7257DEA0BFBFCC41FDB2E214907A9C88 ();
// 0x000000C4 Cinemachine.CameraState Cinemachine.CinemachineFreeLook::CalculateNewState(UnityEngine.Vector3,System.Single)
extern void CinemachineFreeLook_CalculateNewState_mDEC0D03EDD0F2C9521E25A5E6FCFBE66049E3869 ();
// 0x000000C5 UnityEngine.Vector3 Cinemachine.CinemachineFreeLook::GetLocalPositionForCameraFromInput(System.Single)
extern void CinemachineFreeLook_GetLocalPositionForCameraFromInput_m30BECF828556595138D0AE9908D6009E5BB0E7EE ();
// 0x000000C6 System.Void Cinemachine.CinemachineFreeLook::UpdateCachedSpline()
extern void CinemachineFreeLook_UpdateCachedSpline_m1275143847991676F4E0F292FC8CFCD0CE89E382 ();
// 0x000000C7 System.Void Cinemachine.CinemachineFreeLook::.ctor()
extern void CinemachineFreeLook__ctor_m04F403D8675C975D63009E36A843B28BBD0DDE3E ();
// 0x000000C8 System.Single Cinemachine.CinemachineMixingCamera::GetWeight(System.Int32)
extern void CinemachineMixingCamera_GetWeight_mC56767C284E7B6C5441789F5D7022B9EC93342E6 ();
// 0x000000C9 System.Void Cinemachine.CinemachineMixingCamera::SetWeight(System.Int32,System.Single)
extern void CinemachineMixingCamera_SetWeight_mD8CB5271CD81FB934D08D156797DF143BD58DA7A ();
// 0x000000CA System.Single Cinemachine.CinemachineMixingCamera::GetWeight(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineMixingCamera_GetWeight_mD30103E9B0B8B54EEAB6A07179BE0688B8A18C6B ();
// 0x000000CB System.Void Cinemachine.CinemachineMixingCamera::SetWeight(Cinemachine.CinemachineVirtualCameraBase,System.Single)
extern void CinemachineMixingCamera_SetWeight_mB1C14E27249BB10421D396CCFEF41D8E18A7CDB3 ();
// 0x000000CC System.Void Cinemachine.CinemachineMixingCamera::set_LiveChild(Cinemachine.ICinemachineCamera)
extern void CinemachineMixingCamera_set_LiveChild_m2CAA747551619F08D9AF611F73E8740655A64296 ();
// 0x000000CD Cinemachine.ICinemachineCamera Cinemachine.CinemachineMixingCamera::get_LiveChild()
extern void CinemachineMixingCamera_get_LiveChild_m3D4BAA0AB4486CFA6DEF9EAC84CAAD32FA78EA95 ();
// 0x000000CE Cinemachine.CameraState Cinemachine.CinemachineMixingCamera::get_State()
extern void CinemachineMixingCamera_get_State_m58D60DAFE877B686344651AF345BA29EB84CA8CC ();
// 0x000000CF UnityEngine.Transform Cinemachine.CinemachineMixingCamera::get_LookAt()
extern void CinemachineMixingCamera_get_LookAt_m455A20326F89344D9D2B005BEDED109EB439088B ();
// 0x000000D0 System.Void Cinemachine.CinemachineMixingCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineMixingCamera_set_LookAt_m93815AF154ABAC9FF37C7EE237BDFDABFC1CAFB3 ();
// 0x000000D1 UnityEngine.Transform Cinemachine.CinemachineMixingCamera::get_Follow()
extern void CinemachineMixingCamera_get_Follow_m8CCF58027181B96B84CB8EFD681D072E585FBA8E ();
// 0x000000D2 System.Void Cinemachine.CinemachineMixingCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineMixingCamera_set_Follow_m1ECE7574D20C273C49204FE5B775EC85B2605210 ();
// 0x000000D3 System.Void Cinemachine.CinemachineMixingCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineMixingCamera_OnTargetObjectWarped_mADD9E1BD4142606182E1E3BC9F9D204A981ED905 ();
// 0x000000D4 System.Void Cinemachine.CinemachineMixingCamera::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineMixingCamera_ForceCameraPosition_mF1729BA8B700A249B80DE3EF66451DD422AEFD98 ();
// 0x000000D5 System.Void Cinemachine.CinemachineMixingCamera::OnEnable()
extern void CinemachineMixingCamera_OnEnable_mB327FAC23649E787522822C97B2BAAA8B0B01011 ();
// 0x000000D6 System.Void Cinemachine.CinemachineMixingCamera::OnTransformChildrenChanged()
extern void CinemachineMixingCamera_OnTransformChildrenChanged_m78AE7E56D39CB09C2A55DB891DCE4C0D405B3A3B ();
// 0x000000D7 System.Void Cinemachine.CinemachineMixingCamera::OnValidate()
extern void CinemachineMixingCamera_OnValidate_m66D4D52438E5171467EDA22E164B64BA590AA6E5 ();
// 0x000000D8 System.Boolean Cinemachine.CinemachineMixingCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineMixingCamera_IsLiveChild_m4E66C3C7A8A5F20C26E4E8519D3590E86F328613 ();
// 0x000000D9 Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineMixingCamera::get_ChildCameras()
extern void CinemachineMixingCamera_get_ChildCameras_m17AAB894A5692CADB6B886AE1823D0007895FB53 ();
// 0x000000DA System.Void Cinemachine.CinemachineMixingCamera::InvalidateListOfChildren()
extern void CinemachineMixingCamera_InvalidateListOfChildren_m18EC553FC321BD26E1FDEE748A9D6398EC7F6B3D ();
// 0x000000DB System.Void Cinemachine.CinemachineMixingCamera::ValidateListOfChildren()
extern void CinemachineMixingCamera_ValidateListOfChildren_m0592C962C4CF7089FE842F109D0CD3476410B5CB ();
// 0x000000DC System.Void Cinemachine.CinemachineMixingCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineMixingCamera_OnTransitionFromCamera_mA2504937FEC4E030494B431DB73A8FB2801E40CC ();
// 0x000000DD System.Void Cinemachine.CinemachineMixingCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineMixingCamera_InternalUpdateCameraState_m95CC38FD924BF718EF4DC7E94B6259E348129112 ();
// 0x000000DE System.Void Cinemachine.CinemachineMixingCamera::.ctor()
extern void CinemachineMixingCamera__ctor_m5EDF2B338827BF9600E05C360499BB6C8C06E04F ();
// 0x000000DF System.Single Cinemachine.CinemachinePath::get_MinPos()
extern void CinemachinePath_get_MinPos_m44196276E27917CFAA83FCB6805385F0F49B68E6 ();
// 0x000000E0 System.Single Cinemachine.CinemachinePath::get_MaxPos()
extern void CinemachinePath_get_MaxPos_m19CBE9ADEA5F1C8153554117E936EE73430A1B7A ();
// 0x000000E1 System.Boolean Cinemachine.CinemachinePath::get_Looped()
extern void CinemachinePath_get_Looped_mDC5688C64BEAD83BB772379AF6A94B3D69724F5E ();
// 0x000000E2 System.Void Cinemachine.CinemachinePath::Reset()
extern void CinemachinePath_Reset_mDBB3432FB87DC834F93DC9FFE56204F059186030 ();
// 0x000000E3 System.Int32 Cinemachine.CinemachinePath::get_DistanceCacheSampleStepsPerSegment()
extern void CinemachinePath_get_DistanceCacheSampleStepsPerSegment_m040784C32B8D4D2D119AB9C189B7761FEAE717AD ();
// 0x000000E4 System.Single Cinemachine.CinemachinePath::GetBoundingIndices(System.Single,System.Int32&,System.Int32&)
extern void CinemachinePath_GetBoundingIndices_m907FB06C7E158858C9828D4228AC5317A500B107 ();
// 0x000000E5 UnityEngine.Vector3 Cinemachine.CinemachinePath::EvaluatePosition(System.Single)
extern void CinemachinePath_EvaluatePosition_m748123187AAE027319421C5A040783252BA333EB ();
// 0x000000E6 UnityEngine.Vector3 Cinemachine.CinemachinePath::EvaluateTangent(System.Single)
extern void CinemachinePath_EvaluateTangent_m58EFD2AF91AACB4716EF1142DA729FE99A3C4680 ();
// 0x000000E7 UnityEngine.Quaternion Cinemachine.CinemachinePath::EvaluateOrientation(System.Single)
extern void CinemachinePath_EvaluateOrientation_mC2FC02F92747630BBBC1CAF8E388A50D9701C610 ();
// 0x000000E8 System.Void Cinemachine.CinemachinePath::OnValidate()
extern void CinemachinePath_OnValidate_mA799B5C87BE67DD6CD5A94ED498AB1313E7247A5 ();
// 0x000000E9 System.Void Cinemachine.CinemachinePath::.ctor()
extern void CinemachinePath__ctor_m29E35B45E4AF67EC3D12CED0F10D7C9014115765 ();
// 0x000000EA System.Void Cinemachine.CinemachinePipeline::.ctor()
extern void CinemachinePipeline__ctor_mA25F961124A6357A5F945EED40D0FBD495840695 ();
// 0x000000EB System.Void Cinemachine.CinemachinePixelPerfect::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachinePixelPerfect_PostPipelineStageCallback_mD4F59744645E787D73375AE345486512EF2C284A ();
// 0x000000EC System.Void Cinemachine.CinemachinePixelPerfect::.ctor()
extern void CinemachinePixelPerfect__ctor_m3AFA2D3FFAB18B940EE356FD8FE96724CBCFD987 ();
// 0x000000ED System.Single Cinemachine.CinemachineSmoothPath::get_MinPos()
extern void CinemachineSmoothPath_get_MinPos_m6E0E2A097F67A6B10D6CAC35922DA832B7192598 ();
// 0x000000EE System.Single Cinemachine.CinemachineSmoothPath::get_MaxPos()
extern void CinemachineSmoothPath_get_MaxPos_m47FAC15FD184422858C94D12FB59C0DF68196B9A ();
// 0x000000EF System.Boolean Cinemachine.CinemachineSmoothPath::get_Looped()
extern void CinemachineSmoothPath_get_Looped_m581212992BAC29DDBA308B93A7E078EA7757BEFB ();
// 0x000000F0 System.Int32 Cinemachine.CinemachineSmoothPath::get_DistanceCacheSampleStepsPerSegment()
extern void CinemachineSmoothPath_get_DistanceCacheSampleStepsPerSegment_m1B87916ED182DE5DF0033DFD586A9205E087C8EA ();
// 0x000000F1 System.Void Cinemachine.CinemachineSmoothPath::OnValidate()
extern void CinemachineSmoothPath_OnValidate_m0D0A65B796AA7D6014FF0FC2B2171EA5DB0DD422 ();
// 0x000000F2 System.Void Cinemachine.CinemachineSmoothPath::Reset()
extern void CinemachineSmoothPath_Reset_m667726E5707A48BA067A7A7133857087FDC4058E ();
// 0x000000F3 System.Void Cinemachine.CinemachineSmoothPath::InvalidateDistanceCache()
extern void CinemachineSmoothPath_InvalidateDistanceCache_mC7B4228D400267E0F50D1F8E65696DFE40D28F55 ();
// 0x000000F4 System.Void Cinemachine.CinemachineSmoothPath::UpdateControlPoints()
extern void CinemachineSmoothPath_UpdateControlPoints_m2F8ADDDCC7E141ED441095D92EA8723A6C2380D6 ();
// 0x000000F5 System.Single Cinemachine.CinemachineSmoothPath::GetBoundingIndices(System.Single,System.Int32&,System.Int32&)
extern void CinemachineSmoothPath_GetBoundingIndices_mE692833D63163F7B69AD841A2EA29D7F4A9BE752 ();
// 0x000000F6 UnityEngine.Vector3 Cinemachine.CinemachineSmoothPath::EvaluatePosition(System.Single)
extern void CinemachineSmoothPath_EvaluatePosition_mCCAABE1DD14E499B981C439C9F30C68F21A66100 ();
// 0x000000F7 UnityEngine.Vector3 Cinemachine.CinemachineSmoothPath::EvaluateTangent(System.Single)
extern void CinemachineSmoothPath_EvaluateTangent_m0D0D59143BB5132ABD5433E90817F44B302C6B26 ();
// 0x000000F8 UnityEngine.Quaternion Cinemachine.CinemachineSmoothPath::EvaluateOrientation(System.Single)
extern void CinemachineSmoothPath_EvaluateOrientation_mEC5A8EA90524DE4125735E85D9FCC5080D8B065B ();
// 0x000000F9 UnityEngine.Quaternion Cinemachine.CinemachineSmoothPath::RollAroundForward(System.Single)
extern void CinemachineSmoothPath_RollAroundForward_m6D915BAFDE9ECFAC37C521C4F662D68134417065 ();
// 0x000000FA System.Void Cinemachine.CinemachineSmoothPath::.ctor()
extern void CinemachineSmoothPath__ctor_m45C209574B2FCAE3239F335EF383D4D513DB7623 ();
// 0x000000FB System.String Cinemachine.CinemachineStateDrivenCamera::get_Description()
extern void CinemachineStateDrivenCamera_get_Description_m721AB0951987E2034EA458440177C8EF9528CAD5 ();
// 0x000000FC System.Void Cinemachine.CinemachineStateDrivenCamera::set_LiveChild(Cinemachine.ICinemachineCamera)
extern void CinemachineStateDrivenCamera_set_LiveChild_m58CFBD5BCD7718A20DB92DFCB57407A51DB967AE ();
// 0x000000FD Cinemachine.ICinemachineCamera Cinemachine.CinemachineStateDrivenCamera::get_LiveChild()
extern void CinemachineStateDrivenCamera_get_LiveChild_m4FE60C58C46FDB216A5B65BE67166D2715711A3A ();
// 0x000000FE System.Boolean Cinemachine.CinemachineStateDrivenCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineStateDrivenCamera_IsLiveChild_mDB2DC4068402D3D55B40D792828EBB8C32A083E3 ();
// 0x000000FF Cinemachine.CameraState Cinemachine.CinemachineStateDrivenCamera::get_State()
extern void CinemachineStateDrivenCamera_get_State_m5A79A831DF33719426266F8DC14CE7BC74DAD1A7 ();
// 0x00000100 UnityEngine.Transform Cinemachine.CinemachineStateDrivenCamera::get_LookAt()
extern void CinemachineStateDrivenCamera_get_LookAt_m8DC447924D0D74AFE9F9EE6528A4A71640720560 ();
// 0x00000101 System.Void Cinemachine.CinemachineStateDrivenCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineStateDrivenCamera_set_LookAt_m58802064EE2F513FCB7FFCA3FF421BA36CA340ED ();
// 0x00000102 UnityEngine.Transform Cinemachine.CinemachineStateDrivenCamera::get_Follow()
extern void CinemachineStateDrivenCamera_get_Follow_m7B3B9088B452F0AC4803FEA6C0B21BE0359E6517 ();
// 0x00000103 System.Void Cinemachine.CinemachineStateDrivenCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineStateDrivenCamera_set_Follow_mDFD75630E23CC129D727B564643EE86C58314284 ();
// 0x00000104 System.Void Cinemachine.CinemachineStateDrivenCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineStateDrivenCamera_OnTargetObjectWarped_mF70391759212BE63CEB7FB51B0A45B93157A14D8 ();
// 0x00000105 System.Void Cinemachine.CinemachineStateDrivenCamera::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineStateDrivenCamera_ForceCameraPosition_m29A24C9E4E02555029FD1FC6912BB3D54A35B156 ();
// 0x00000106 System.Void Cinemachine.CinemachineStateDrivenCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineStateDrivenCamera_OnTransitionFromCamera_mEBE4A9F7099581DD5988F7D06E19056C906DEA19 ();
// 0x00000107 Cinemachine.ICinemachineCamera Cinemachine.CinemachineStateDrivenCamera::get_TransitioningFrom()
extern void CinemachineStateDrivenCamera_get_TransitioningFrom_m6D611FD16354DACC78A99F2B8E3CC13327CCF104 ();
// 0x00000108 System.Void Cinemachine.CinemachineStateDrivenCamera::set_TransitioningFrom(Cinemachine.ICinemachineCamera)
extern void CinemachineStateDrivenCamera_set_TransitioningFrom_mC376F532563E04695BD810AFB8FF63589AD82B5C ();
// 0x00000109 System.Void Cinemachine.CinemachineStateDrivenCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineStateDrivenCamera_InternalUpdateCameraState_m15DA964B37A1A8B67ACC8D3429089D1948F3FD92 ();
// 0x0000010A System.Void Cinemachine.CinemachineStateDrivenCamera::OnEnable()
extern void CinemachineStateDrivenCamera_OnEnable_m73592A142BE908F77B0AA271DAB6D3931F0985AB ();
// 0x0000010B System.Void Cinemachine.CinemachineStateDrivenCamera::OnDisable()
extern void CinemachineStateDrivenCamera_OnDisable_m0A9782361F2D03D44648E382D7CF8C43BB9C30A0 ();
// 0x0000010C System.Void Cinemachine.CinemachineStateDrivenCamera::OnTransformChildrenChanged()
extern void CinemachineStateDrivenCamera_OnTransformChildrenChanged_mC0E38B870F9476DB6863BCB16D18C36B9BBFFECD ();
// 0x0000010D System.Void Cinemachine.CinemachineStateDrivenCamera::OnGuiHandler()
extern void CinemachineStateDrivenCamera_OnGuiHandler_mDB24B0B122B8F3CF847139FDC147B7F3CBFE3F05 ();
// 0x0000010E Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineStateDrivenCamera::get_ChildCameras()
extern void CinemachineStateDrivenCamera_get_ChildCameras_m4C9CBF7126E384CDBBB2AAFE86108F43A2DF6E52 ();
// 0x0000010F System.Boolean Cinemachine.CinemachineStateDrivenCamera::get_IsBlending()
extern void CinemachineStateDrivenCamera_get_IsBlending_mD0DC02C494368EF1946180D261E072CC70A859C5 ();
// 0x00000110 System.Int32 Cinemachine.CinemachineStateDrivenCamera::CreateFakeHash(System.Int32,UnityEngine.AnimationClip)
extern void CinemachineStateDrivenCamera_CreateFakeHash_m1B5D689454467E54101D56E7FC1096E4E709B80F ();
// 0x00000111 System.Int32 Cinemachine.CinemachineStateDrivenCamera::LookupFakeHash(System.Int32,UnityEngine.AnimationClip)
extern void CinemachineStateDrivenCamera_LookupFakeHash_m06759C84A0584A1F9F290C5E58DFB0FF0AE4BD5B ();
// 0x00000112 System.Void Cinemachine.CinemachineStateDrivenCamera::InvalidateListOfChildren()
extern void CinemachineStateDrivenCamera_InvalidateListOfChildren_m09761689924E32C52613DFE05E80CD9D7FC3AA0E ();
// 0x00000113 System.Void Cinemachine.CinemachineStateDrivenCamera::UpdateListOfChildren()
extern void CinemachineStateDrivenCamera_UpdateListOfChildren_mBA707781DC4090145A34A24903B7F08FD0875AF8 ();
// 0x00000114 System.Void Cinemachine.CinemachineStateDrivenCamera::ValidateInstructions()
extern void CinemachineStateDrivenCamera_ValidateInstructions_m3283C4B0462AC49AAFDBF8020BFCD8E296E7542B ();
// 0x00000115 Cinemachine.CinemachineVirtualCameraBase Cinemachine.CinemachineStateDrivenCamera::ChooseCurrentCamera()
extern void CinemachineStateDrivenCamera_ChooseCurrentCamera_m3D70AE6707397EEE221D01F8B25119B2BC7A370F ();
// 0x00000116 System.Int32 Cinemachine.CinemachineStateDrivenCamera::GetClipHash(System.Int32,System.Collections.Generic.List`1<UnityEngine.AnimatorClipInfo>)
extern void CinemachineStateDrivenCamera_GetClipHash_mAD02DF3C8A12333C4D93FF1DA54D30B4DF2178CA ();
// 0x00000117 Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineStateDrivenCamera::LookupBlend(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera)
extern void CinemachineStateDrivenCamera_LookupBlend_mD0B7CD5CF181EDDABF0EFE90C829DC5DF5262C41 ();
// 0x00000118 System.Void Cinemachine.CinemachineStateDrivenCamera::.ctor()
extern void CinemachineStateDrivenCamera__ctor_mB23005EB5EC0817BDFE10B9A1F0865DA83D3CBFE ();
// 0x00000119 System.Void Cinemachine.CinemachineStoryboard::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineStoryboard_PostPipelineStageCallback_mCABE6FCDDBC249650661E7F9E4879D456950332B ();
// 0x0000011A System.Void Cinemachine.CinemachineStoryboard::ConnectToVcam(System.Boolean)
extern void CinemachineStoryboard_ConnectToVcam_m8C550061C8C0F5CF8AA3D57DFCDC41C103FDF66D ();
// 0x0000011B System.String Cinemachine.CinemachineStoryboard::get_CanvasName()
extern void CinemachineStoryboard_get_CanvasName_m7B8D386FB493150485E1D44C62A7096F2F657C5F ();
// 0x0000011C System.Void Cinemachine.CinemachineStoryboard::CameraUpdatedCallback(Cinemachine.CinemachineBrain)
extern void CinemachineStoryboard_CameraUpdatedCallback_m234F18B313AD4C89E918AC2F4239FFE79E2C47CD ();
// 0x0000011D Cinemachine.CinemachineStoryboard_CanvasInfo Cinemachine.CinemachineStoryboard::LocateMyCanvas(Cinemachine.CinemachineBrain,System.Boolean)
extern void CinemachineStoryboard_LocateMyCanvas_mCCD4AE8516711F4F7947F1403DEC3BD31879C6B6 ();
// 0x0000011E System.Void Cinemachine.CinemachineStoryboard::CreateCanvas(Cinemachine.CinemachineStoryboard_CanvasInfo)
extern void CinemachineStoryboard_CreateCanvas_m8646630AFE1182FFF350AE7277070C881913905E ();
// 0x0000011F System.Void Cinemachine.CinemachineStoryboard::DestroyCanvas()
extern void CinemachineStoryboard_DestroyCanvas_mDAE4469DDC233DADBC9940C3C50BE2F0AE15E7A7 ();
// 0x00000120 System.Void Cinemachine.CinemachineStoryboard::PlaceImage(Cinemachine.CinemachineStoryboard_CanvasInfo,System.Single)
extern void CinemachineStoryboard_PlaceImage_m2B8471FE0B239D371527BB2670785AB6B86108AF ();
// 0x00000121 System.Void Cinemachine.CinemachineStoryboard::StaticBlendingHandler(Cinemachine.CinemachineBrain)
extern void CinemachineStoryboard_StaticBlendingHandler_mB063E4C83DB301BC5F947A7E6E7830C40EE663B1 ();
// 0x00000122 System.Void Cinemachine.CinemachineStoryboard::InitializeModule()
extern void CinemachineStoryboard_InitializeModule_m6F699FC72AEB7184BE2AEFF42BB6FC6794D44EB7 ();
// 0x00000123 System.Void Cinemachine.CinemachineStoryboard::.ctor()
extern void CinemachineStoryboard__ctor_m5B6932E31A0425FB1C6EFDE4CC048CEC1F0B89ED ();
// 0x00000124 UnityEngine.Transform Cinemachine.ICinemachineTargetGroup::get_Transform()
// 0x00000125 UnityEngine.Bounds Cinemachine.ICinemachineTargetGroup::get_BoundingBox()
// 0x00000126 UnityEngine.BoundingSphere Cinemachine.ICinemachineTargetGroup::get_Sphere()
// 0x00000127 System.Boolean Cinemachine.ICinemachineTargetGroup::get_IsEmpty()
// 0x00000128 UnityEngine.Bounds Cinemachine.ICinemachineTargetGroup::GetViewSpaceBoundingBox(UnityEngine.Matrix4x4)
// 0x00000129 System.Void Cinemachine.ICinemachineTargetGroup::GetViewSpaceAngularBounds(UnityEngine.Matrix4x4,UnityEngine.Vector2&,UnityEngine.Vector2&,UnityEngine.Vector2&)
// 0x0000012A UnityEngine.Transform Cinemachine.CinemachineTargetGroup::get_Transform()
extern void CinemachineTargetGroup_get_Transform_mADEBFE4BA9AF2FDC94C7302B1872D93B40F31586 ();
// 0x0000012B UnityEngine.Bounds Cinemachine.CinemachineTargetGroup::get_BoundingBox()
extern void CinemachineTargetGroup_get_BoundingBox_mF6801A2838567BE9DE910D45D9BF05A760646933 ();
// 0x0000012C System.Void Cinemachine.CinemachineTargetGroup::set_BoundingBox(UnityEngine.Bounds)
extern void CinemachineTargetGroup_set_BoundingBox_m4E6C1E1267D257AEDBA80318354B60A655D1097C ();
// 0x0000012D UnityEngine.BoundingSphere Cinemachine.CinemachineTargetGroup::get_Sphere()
extern void CinemachineTargetGroup_get_Sphere_m3548B36218DC82389D27BAF6410BD34C1BBE75E8 ();
// 0x0000012E System.Boolean Cinemachine.CinemachineTargetGroup::get_IsEmpty()
extern void CinemachineTargetGroup_get_IsEmpty_mA2CEE80C159101E17390EAE7A9F1E7F60ECA227C ();
// 0x0000012F System.Void Cinemachine.CinemachineTargetGroup::AddMember(UnityEngine.Transform,System.Single,System.Single)
extern void CinemachineTargetGroup_AddMember_mDE00B3D9AB65CBAA2649A911C546D0D00170D67C ();
// 0x00000130 System.Void Cinemachine.CinemachineTargetGroup::RemoveMember(UnityEngine.Transform)
extern void CinemachineTargetGroup_RemoveMember_mBAB8FD54B83FC8749A6709F8573FFB9B78A17E08 ();
// 0x00000131 System.Int32 Cinemachine.CinemachineTargetGroup::FindMember(UnityEngine.Transform)
extern void CinemachineTargetGroup_FindMember_mD60C186B1844C2FF84E3B10D0F5952A89CCD614D ();
// 0x00000132 UnityEngine.BoundingSphere Cinemachine.CinemachineTargetGroup::GetWeightedBoundsForMember(System.Int32)
extern void CinemachineTargetGroup_GetWeightedBoundsForMember_m879BB7436547F7658E13FE9D4B1E9831BF6983CE ();
// 0x00000133 UnityEngine.Bounds Cinemachine.CinemachineTargetGroup::GetViewSpaceBoundingBox(UnityEngine.Matrix4x4)
extern void CinemachineTargetGroup_GetViewSpaceBoundingBox_m419CDD33E962D72D728E5351BE524B4887284BA0 ();
// 0x00000134 UnityEngine.BoundingSphere Cinemachine.CinemachineTargetGroup::WeightedMemberBounds(Cinemachine.CinemachineTargetGroup_Target,UnityEngine.Vector3,System.Single)
extern void CinemachineTargetGroup_WeightedMemberBounds_mCBA0F61AABF001E2088F03BC99CF3200FC7C7CCA ();
// 0x00000135 System.Void Cinemachine.CinemachineTargetGroup::DoUpdate()
extern void CinemachineTargetGroup_DoUpdate_m298B1536B6884019681B7DA4E50000ECE3B63D8E ();
// 0x00000136 UnityEngine.Vector3 Cinemachine.CinemachineTargetGroup::CalculateAveragePosition(System.Single&)
extern void CinemachineTargetGroup_CalculateAveragePosition_mF78C3AF8AAD414B79ECA6B7995BD8CEF3B51F88C ();
// 0x00000137 UnityEngine.Quaternion Cinemachine.CinemachineTargetGroup::CalculateAverageOrientation()
extern void CinemachineTargetGroup_CalculateAverageOrientation_m4112A1C8E182CA4C8C5642F908A59FD21732E7F8 ();
// 0x00000138 UnityEngine.Bounds Cinemachine.CinemachineTargetGroup::CalculateBoundingBox(UnityEngine.Vector3,System.Single)
extern void CinemachineTargetGroup_CalculateBoundingBox_m8FC29A766DAA5EA8D9D770A70C3BA3F33BCF9C45 ();
// 0x00000139 System.Void Cinemachine.CinemachineTargetGroup::OnValidate()
extern void CinemachineTargetGroup_OnValidate_m00BCA97645EBF6D84D566D10ADADE897E573D300 ();
// 0x0000013A System.Void Cinemachine.CinemachineTargetGroup::FixedUpdate()
extern void CinemachineTargetGroup_FixedUpdate_m51E54F0F8EB6C01A45EA6ADC82929B9D63A7D1C6 ();
// 0x0000013B System.Void Cinemachine.CinemachineTargetGroup::Update()
extern void CinemachineTargetGroup_Update_m6CF5BB9923882A14E2EB426056BE160EDCB781D9 ();
// 0x0000013C System.Void Cinemachine.CinemachineTargetGroup::LateUpdate()
extern void CinemachineTargetGroup_LateUpdate_m320382F4ADE5662C7F06D81ED7505FF0FDAE41B5 ();
// 0x0000013D System.Void Cinemachine.CinemachineTargetGroup::GetViewSpaceAngularBounds(UnityEngine.Matrix4x4,UnityEngine.Vector2&,UnityEngine.Vector2&,UnityEngine.Vector2&)
extern void CinemachineTargetGroup_GetViewSpaceAngularBounds_mBCCF672D0664D37BA01D432B888F37A7665361BD ();
// 0x0000013E System.Void Cinemachine.CinemachineTargetGroup::.ctor()
extern void CinemachineTargetGroup__ctor_m59C958FBF749CEEA369DDF27BAA3E9216CA99399 ();
// 0x0000013F Cinemachine.CameraState Cinemachine.CinemachineVirtualCamera::get_State()
extern void CinemachineVirtualCamera_get_State_mF61B23491D389A88595DD95EB27E44EE09F3D40C ();
// 0x00000140 UnityEngine.Transform Cinemachine.CinemachineVirtualCamera::get_LookAt()
extern void CinemachineVirtualCamera_get_LookAt_m7FA8E1F163BBB41806692C120B1A3531872E9173 ();
// 0x00000141 System.Void Cinemachine.CinemachineVirtualCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineVirtualCamera_set_LookAt_m16EAA4A1653EAE5AC3490E2B2653E9C15856B199 ();
// 0x00000142 UnityEngine.Transform Cinemachine.CinemachineVirtualCamera::get_Follow()
extern void CinemachineVirtualCamera_get_Follow_m2D4644BF8364F8EC6366E86D0E628AF7FBA8884D ();
// 0x00000143 System.Void Cinemachine.CinemachineVirtualCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineVirtualCamera_set_Follow_mBC7DE30C2BF4E62258116D9AA8F300A1468D0410 ();
// 0x00000144 System.Single Cinemachine.CinemachineVirtualCamera::GetMaxDampTime()
extern void CinemachineVirtualCamera_GetMaxDampTime_m401AE8ABB66092E3E93BCADF35D846D5E44DAD16 ();
// 0x00000145 System.Void Cinemachine.CinemachineVirtualCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCamera_InternalUpdateCameraState_m0A8D802327119F624F26C694E6341B34D38B1057 ();
// 0x00000146 System.Void Cinemachine.CinemachineVirtualCamera::OnEnable()
extern void CinemachineVirtualCamera_OnEnable_m05A075F14A81B8DF7362BADC9B3F5B195F912CE1 ();
// 0x00000147 System.Void Cinemachine.CinemachineVirtualCamera::OnDestroy()
extern void CinemachineVirtualCamera_OnDestroy_m69759804B4988BF64EF56B3F32DFC63BC4C5D533 ();
// 0x00000148 System.Void Cinemachine.CinemachineVirtualCamera::OnValidate()
extern void CinemachineVirtualCamera_OnValidate_m6B4FF3C2AD8B3992E2E6759D1D72388EF013F4C5 ();
// 0x00000149 System.Void Cinemachine.CinemachineVirtualCamera::OnTransformChildrenChanged()
extern void CinemachineVirtualCamera_OnTransformChildrenChanged_mF04206FB649F578387FF1B5E2690862861730775 ();
// 0x0000014A System.Void Cinemachine.CinemachineVirtualCamera::Reset()
extern void CinemachineVirtualCamera_Reset_mB1C37515D1DF02DDC6EBECAC6F5E8EC2DAAA0990 ();
// 0x0000014B System.Void Cinemachine.CinemachineVirtualCamera::DestroyPipeline()
extern void CinemachineVirtualCamera_DestroyPipeline_mBF0ACCB0E14994F96A0DA4F766E9DC4CD65298E4 ();
// 0x0000014C UnityEngine.Transform Cinemachine.CinemachineVirtualCamera::CreatePipeline(Cinemachine.CinemachineVirtualCamera)
extern void CinemachineVirtualCamera_CreatePipeline_mFE25AD716DEA1E9468F5963DAA0252E300D1EA8D ();
// 0x0000014D System.Void Cinemachine.CinemachineVirtualCamera::InvalidateComponentPipeline()
extern void CinemachineVirtualCamera_InvalidateComponentPipeline_m74BC28C9508EA3673CD8DA028883B069A94F652C ();
// 0x0000014E UnityEngine.Transform Cinemachine.CinemachineVirtualCamera::GetComponentOwner()
extern void CinemachineVirtualCamera_GetComponentOwner_m8901A99D0106ADD7B9DF483D5A899E07C6B55DF4 ();
// 0x0000014F Cinemachine.CinemachineComponentBase[] Cinemachine.CinemachineVirtualCamera::GetComponentPipeline()
extern void CinemachineVirtualCamera_GetComponentPipeline_mD2C278143444B6D6CC40EE5DC5AA5B7259C67296 ();
// 0x00000150 Cinemachine.CinemachineComponentBase Cinemachine.CinemachineVirtualCamera::GetCinemachineComponent(Cinemachine.CinemachineCore_Stage)
extern void CinemachineVirtualCamera_GetCinemachineComponent_m9FA6F90B033903CAFFD1149E0A58A06313FDC7F3 ();
// 0x00000151 T Cinemachine.CinemachineVirtualCamera::GetCinemachineComponent()
// 0x00000152 T Cinemachine.CinemachineVirtualCamera::AddCinemachineComponent()
// 0x00000153 System.Void Cinemachine.CinemachineVirtualCamera::DestroyCinemachineComponent()
// 0x00000154 System.Boolean Cinemachine.CinemachineVirtualCamera::get_UserIsDragging()
extern void CinemachineVirtualCamera_get_UserIsDragging_mCC9BCC63272BBC50DD6C1C930A1E162F2E7FB118 ();
// 0x00000155 System.Void Cinemachine.CinemachineVirtualCamera::set_UserIsDragging(System.Boolean)
extern void CinemachineVirtualCamera_set_UserIsDragging_mA66BB2778AD5A2D17230207CC6FE1A5055764E51 ();
// 0x00000156 System.Void Cinemachine.CinemachineVirtualCamera::UpdateComponentPipeline()
extern void CinemachineVirtualCamera_UpdateComponentPipeline_m40B9D8AFC178A45C7FEE7A5E151D9232E05201AA ();
// 0x00000157 System.Void Cinemachine.CinemachineVirtualCamera::SetFlagsForHiddenChild(UnityEngine.GameObject)
extern void CinemachineVirtualCamera_SetFlagsForHiddenChild_m0B6CC9E477DF3FDC4A4C85B397DBC02987B8FFFF ();
// 0x00000158 Cinemachine.CameraState Cinemachine.CinemachineVirtualCamera::CalculateNewState(UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCamera_CalculateNewState_mDC69D1DC2332963E4EE05DC6B3278483DDB7E271 ();
// 0x00000159 System.Void Cinemachine.CinemachineVirtualCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineVirtualCamera_OnTargetObjectWarped_m97A56F2EF2CAB7C830FE81D8DAF69D70302F3087 ();
// 0x0000015A System.Void Cinemachine.CinemachineVirtualCamera::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineVirtualCamera_ForceCameraPosition_mA54274F343A60C2D8B5D0918B113F8D52A9C096F ();
// 0x0000015B System.Void Cinemachine.CinemachineVirtualCamera::SetStateRawPosition(UnityEngine.Vector3)
extern void CinemachineVirtualCamera_SetStateRawPosition_mC33AAABD638BAF99907C51E241D339706F2A6591 ();
// 0x0000015C System.Void Cinemachine.CinemachineVirtualCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCamera_OnTransitionFromCamera_m621F8E4CE89A6CD4C718BAE9127944BBBE8A8C39 ();
// 0x0000015D System.Void Cinemachine.CinemachineVirtualCamera::.ctor()
extern void CinemachineVirtualCamera__ctor_mE54D1FBAC8B30DADC6D1A1FF4E7526BEF47AA9D3 ();
// 0x0000015E System.Void Cinemachine.Cinemachine3rdPersonFollow::OnValidate()
extern void Cinemachine3rdPersonFollow_OnValidate_mD52752FC1E0022C921AE0857A427EA108096BA83 ();
// 0x0000015F System.Void Cinemachine.Cinemachine3rdPersonFollow::Reset()
extern void Cinemachine3rdPersonFollow_Reset_m7B9D8F5575FCA0073A412D0147A5949A72D4D39B ();
// 0x00000160 System.Boolean Cinemachine.Cinemachine3rdPersonFollow::get_IsValid()
extern void Cinemachine3rdPersonFollow_get_IsValid_mA7AB0949602C57690E5DA8A590D80112BAB000DA ();
// 0x00000161 Cinemachine.CinemachineCore_Stage Cinemachine.Cinemachine3rdPersonFollow::get_Stage()
extern void Cinemachine3rdPersonFollow_get_Stage_m1859D4E263C07EACAD8C3C899D327FC85761FFC2 ();
// 0x00000162 System.Single Cinemachine.Cinemachine3rdPersonFollow::GetMaxDampTime()
extern void Cinemachine3rdPersonFollow_GetMaxDampTime_m98EDF505AFFC8235F306E91EB8C2B1A867A4B641 ();
// 0x00000163 System.Void Cinemachine.Cinemachine3rdPersonFollow::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void Cinemachine3rdPersonFollow_MutateCameraState_m8EF4ADD2CE87316458D9B4D365FF587EDEE26C4F ();
// 0x00000164 System.Void Cinemachine.Cinemachine3rdPersonFollow::PositionCamera(Cinemachine.CameraState&,System.Single)
extern void Cinemachine3rdPersonFollow_PositionCamera_mD6357591900C0D7F3740BCE6FB061F1287630B21 ();
// 0x00000165 System.Void Cinemachine.Cinemachine3rdPersonFollow::GetRigPositions(UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void Cinemachine3rdPersonFollow_GetRigPositions_m0B350EE139BBE08CEC35AC25DE11BB0D76B9F8E5 ();
// 0x00000166 UnityEngine.Vector3 Cinemachine.Cinemachine3rdPersonFollow::PullTowardsStartOnCollision(UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.LayerMask&,System.Single)
extern void Cinemachine3rdPersonFollow_PullTowardsStartOnCollision_m59213AF7DEE90CC29F3FDBB404D283810F824333 ();
// 0x00000167 System.Void Cinemachine.Cinemachine3rdPersonFollow::.ctor()
extern void Cinemachine3rdPersonFollow__ctor_m9FC063AEC945BFF7CB0D77584F0B4A09546BC805 ();
// 0x00000168 System.Boolean Cinemachine.CinemachineBasicMultiChannelPerlin::get_IsValid()
extern void CinemachineBasicMultiChannelPerlin_get_IsValid_m89FD92464853D4D80540492E7A94B293D637536E ();
// 0x00000169 Cinemachine.CinemachineCore_Stage Cinemachine.CinemachineBasicMultiChannelPerlin::get_Stage()
extern void CinemachineBasicMultiChannelPerlin_get_Stage_mFBFFEC86F9A8F773FA9028D684D39194F8DF042D ();
// 0x0000016A System.Void Cinemachine.CinemachineBasicMultiChannelPerlin::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineBasicMultiChannelPerlin_MutateCameraState_m71D2179E138E53253A53FC2033BBF5DB002CB888 ();
// 0x0000016B System.Void Cinemachine.CinemachineBasicMultiChannelPerlin::ReSeed()
extern void CinemachineBasicMultiChannelPerlin_ReSeed_m55B7DB6DDB8B7864790E509C07A73E263072A2C9 ();
// 0x0000016C System.Void Cinemachine.CinemachineBasicMultiChannelPerlin::Initialize()
extern void CinemachineBasicMultiChannelPerlin_Initialize_mBE33134720655F241B32247831C18F3F4AC7E7E5 ();
// 0x0000016D System.Void Cinemachine.CinemachineBasicMultiChannelPerlin::.ctor()
extern void CinemachineBasicMultiChannelPerlin__ctor_m03392D8E786B297606FC3029C2468621D0BD267A ();
// 0x0000016E System.Boolean Cinemachine.CinemachineComposer::get_IsValid()
extern void CinemachineComposer_get_IsValid_mDD8A6301558F8579A65C82A84A073EF6CC9F7275 ();
// 0x0000016F Cinemachine.CinemachineCore_Stage Cinemachine.CinemachineComposer::get_Stage()
extern void CinemachineComposer_get_Stage_m20189F84AF9911702526B12CB5B27411538D4663 ();
// 0x00000170 UnityEngine.Vector3 Cinemachine.CinemachineComposer::get_TrackedPoint()
extern void CinemachineComposer_get_TrackedPoint_mBD61C246B60BC598EF2F407F11BF2162139F54B1 ();
// 0x00000171 System.Void Cinemachine.CinemachineComposer::set_TrackedPoint(UnityEngine.Vector3)
extern void CinemachineComposer_set_TrackedPoint_m15F609367B526B54845CB4A22D1874E01B84EDFD ();
// 0x00000172 UnityEngine.Vector3 Cinemachine.CinemachineComposer::GetLookAtPointAndSetTrackedPoint(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CinemachineComposer_GetLookAtPointAndSetTrackedPoint_m6191ABF0FD235956D9416A5B96C70504548D7CD0 ();
// 0x00000173 System.Void Cinemachine.CinemachineComposer::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineComposer_OnTargetObjectWarped_m3E15015DF195EEA065F733FC3A201F22FBBBA7C6 ();
// 0x00000174 System.Void Cinemachine.CinemachineComposer::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineComposer_ForceCameraPosition_m5B8C9B0D268DEE13C478EAA9F7B7A1DBB3411B90 ();
// 0x00000175 System.Single Cinemachine.CinemachineComposer::GetMaxDampTime()
extern void CinemachineComposer_GetMaxDampTime_mF9651558C16FD35EF56B69268E44F114EB21646A ();
// 0x00000176 System.Void Cinemachine.CinemachineComposer::PrePipelineMutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineComposer_PrePipelineMutateCameraState_mBEE9891FE6C2A3EA29A82BDD152C737774D0B462 ();
// 0x00000177 System.Void Cinemachine.CinemachineComposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineComposer_MutateCameraState_m500BDD47385EEE6373A5B5919D4B7B06CC798D57 ();
// 0x00000178 UnityEngine.Rect Cinemachine.CinemachineComposer::get_SoftGuideRect()
extern void CinemachineComposer_get_SoftGuideRect_m2B2596665A05FF432BE719AE225A570F3C83DF8C ();
// 0x00000179 System.Void Cinemachine.CinemachineComposer::set_SoftGuideRect(UnityEngine.Rect)
extern void CinemachineComposer_set_SoftGuideRect_mC46E102F64D6B1A70F528E2226C0935E485C183D ();
// 0x0000017A UnityEngine.Rect Cinemachine.CinemachineComposer::get_HardGuideRect()
extern void CinemachineComposer_get_HardGuideRect_m552C95A5B89097FD385E6DED3C04B53B2556A2EE ();
// 0x0000017B System.Void Cinemachine.CinemachineComposer::set_HardGuideRect(UnityEngine.Rect)
extern void CinemachineComposer_set_HardGuideRect_mAB65433485E384647C3B7D5BA9BE55A841E33AB9 ();
// 0x0000017C System.Void Cinemachine.CinemachineComposer::RotateToScreenBounds(Cinemachine.CameraState&,UnityEngine.Rect,UnityEngine.Vector3,UnityEngine.Quaternion&,System.Single,System.Single,System.Single)
extern void CinemachineComposer_RotateToScreenBounds_m62769940088AAC4509FEB682F5902D582B1AE6C1 ();
// 0x0000017D System.Boolean Cinemachine.CinemachineComposer::ClampVerticalBounds(UnityEngine.Rect&,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CinemachineComposer_ClampVerticalBounds_mAEA1A39D3A98ACAA5AC36B7E3B11376E99E2E68E ();
// 0x0000017E System.Void Cinemachine.CinemachineComposer::.ctor()
extern void CinemachineComposer__ctor_mA02E72656795D0813435386C46CEEB144AB29820 ();
// 0x0000017F UnityEngine.Rect Cinemachine.CinemachineFramingTransposer::get_SoftGuideRect()
extern void CinemachineFramingTransposer_get_SoftGuideRect_mEAA618B22D45A8C57B8A5AE984660585B0EE2D87 ();
// 0x00000180 System.Void Cinemachine.CinemachineFramingTransposer::set_SoftGuideRect(UnityEngine.Rect)
extern void CinemachineFramingTransposer_set_SoftGuideRect_mC3076D642DBCDBC1AC725A4F1E1E090F8F1AC9EF ();
// 0x00000181 UnityEngine.Rect Cinemachine.CinemachineFramingTransposer::get_HardGuideRect()
extern void CinemachineFramingTransposer_get_HardGuideRect_mC861BBCE9D49993E237ADA9BBAC17665264A87FA ();
// 0x00000182 System.Void Cinemachine.CinemachineFramingTransposer::set_HardGuideRect(UnityEngine.Rect)
extern void CinemachineFramingTransposer_set_HardGuideRect_m1138240B8F7657519AC0571ECE2E6EFB89CC634E ();
// 0x00000183 System.Void Cinemachine.CinemachineFramingTransposer::OnValidate()
extern void CinemachineFramingTransposer_OnValidate_mC01E2DF60BA5B6B8D678E429D2FD2C1BE20EDA79 ();
// 0x00000184 System.Boolean Cinemachine.CinemachineFramingTransposer::get_IsValid()
extern void CinemachineFramingTransposer_get_IsValid_mA6BEC5FF4B2BCA542CACB93FC8817DC0E222CA8B ();
// 0x00000185 Cinemachine.CinemachineCore_Stage Cinemachine.CinemachineFramingTransposer::get_Stage()
extern void CinemachineFramingTransposer_get_Stage_m46D483051C135C5A2FAA11127927B477E4C3A4B3 ();
// 0x00000186 System.Boolean Cinemachine.CinemachineFramingTransposer::get_BodyAppliesAfterAim()
extern void CinemachineFramingTransposer_get_BodyAppliesAfterAim_mDE58AC6238D9FFF902F3A490BE5ABEF7CCC350F0 ();
// 0x00000187 UnityEngine.Vector3 Cinemachine.CinemachineFramingTransposer::get_TrackedPoint()
extern void CinemachineFramingTransposer_get_TrackedPoint_m7AD13AA3ED1185BE57C57925A65A457052F646B7 ();
// 0x00000188 System.Void Cinemachine.CinemachineFramingTransposer::set_TrackedPoint(UnityEngine.Vector3)
extern void CinemachineFramingTransposer_set_TrackedPoint_m0F66F2FD792A1BC7873FAF52A9975CF2CB30DD82 ();
// 0x00000189 System.Void Cinemachine.CinemachineFramingTransposer::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineFramingTransposer_OnTargetObjectWarped_m363404C45AF56465366357A3C1C6CE455BDD8045 ();
// 0x0000018A System.Void Cinemachine.CinemachineFramingTransposer::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineFramingTransposer_ForceCameraPosition_m359218276D2C475F79427C2BBA9D880F0EF847B0 ();
// 0x0000018B System.Single Cinemachine.CinemachineFramingTransposer::GetMaxDampTime()
extern void CinemachineFramingTransposer_GetMaxDampTime_m972BD3E7124A8630DC0C905993BBDE6D1AC9A275 ();
// 0x0000018C System.Boolean Cinemachine.CinemachineFramingTransposer::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single,Cinemachine.CinemachineVirtualCameraBase_TransitionParams&)
extern void CinemachineFramingTransposer_OnTransitionFromCamera_mB359F165B80CA2A10C19EA3AF33A9259F0A461BE ();
// 0x0000018D System.Boolean Cinemachine.CinemachineFramingTransposer::get_InheritingPosition()
extern void CinemachineFramingTransposer_get_InheritingPosition_m6FD62CC6C818D58C1BDAD0CFDB0DB17490098FAC ();
// 0x0000018E System.Void Cinemachine.CinemachineFramingTransposer::set_InheritingPosition(System.Boolean)
extern void CinemachineFramingTransposer_set_InheritingPosition_mE8AC7F16BC034AC01F63BF8871A2380BA533DFEF ();
// 0x0000018F UnityEngine.Rect Cinemachine.CinemachineFramingTransposer::ScreenToOrtho(UnityEngine.Rect,System.Single,System.Single)
extern void CinemachineFramingTransposer_ScreenToOrtho_mB36BB70462CD2EE36203D5AD3E4CA83D6CDDB23C ();
// 0x00000190 UnityEngine.Vector3 Cinemachine.CinemachineFramingTransposer::OrthoOffsetToScreenBounds(UnityEngine.Vector3,UnityEngine.Rect)
extern void CinemachineFramingTransposer_OrthoOffsetToScreenBounds_m537A7A773E2161BCDBA155497EE09CE363319A92 ();
// 0x00000191 UnityEngine.Bounds Cinemachine.CinemachineFramingTransposer::get_LastBounds()
extern void CinemachineFramingTransposer_get_LastBounds_mA41F708F5427B0DCABFAD74902AD2FA131B9315A ();
// 0x00000192 System.Void Cinemachine.CinemachineFramingTransposer::set_LastBounds(UnityEngine.Bounds)
extern void CinemachineFramingTransposer_set_LastBounds_mE7C62D2CDC58E8491783977BB73EAB7C1286B76A ();
// 0x00000193 UnityEngine.Matrix4x4 Cinemachine.CinemachineFramingTransposer::get_LastBoundsMatrix()
extern void CinemachineFramingTransposer_get_LastBoundsMatrix_mE543BEE3801C0D544E132F28F45F0593AABF0BD4 ();
// 0x00000194 System.Void Cinemachine.CinemachineFramingTransposer::set_LastBoundsMatrix(UnityEngine.Matrix4x4)
extern void CinemachineFramingTransposer_set_LastBoundsMatrix_m82659FE5FB87F1959EAF0BB4F3FC4A53A4FCADDD ();
// 0x00000195 System.Void Cinemachine.CinemachineFramingTransposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineFramingTransposer_MutateCameraState_m738B55893FF0A80A26234C5CBABDF4441EA13111 ();
// 0x00000196 System.Single Cinemachine.CinemachineFramingTransposer::GetTargetHeight(UnityEngine.Vector2)
extern void CinemachineFramingTransposer_GetTargetHeight_mC4D0F3C7F1916B41E47FCA12F06B481A83AAF545 ();
// 0x00000197 UnityEngine.Vector3 Cinemachine.CinemachineFramingTransposer::ComputeGroupBounds(Cinemachine.ICinemachineTargetGroup,Cinemachine.CameraState&)
extern void CinemachineFramingTransposer_ComputeGroupBounds_m266F186335242EE480FA0DA8D2477B9672A9441F ();
// 0x00000198 UnityEngine.Bounds Cinemachine.CinemachineFramingTransposer::GetScreenSpaceGroupBoundingBox(Cinemachine.ICinemachineTargetGroup,UnityEngine.Vector3&,UnityEngine.Quaternion)
extern void CinemachineFramingTransposer_GetScreenSpaceGroupBoundingBox_mF4E5D1B62BA2FA5EB6A3D83A77E0B3E6F2580148 ();
// 0x00000199 System.Void Cinemachine.CinemachineFramingTransposer::.ctor()
extern void CinemachineFramingTransposer__ctor_m43A25F96041552E3943E1A17419C76CD73DD5067 ();
// 0x0000019A System.Void Cinemachine.CinemachineGroupComposer::OnValidate()
extern void CinemachineGroupComposer_OnValidate_m056733D87C52B7481CB62EAC67A97465E94A344D ();
// 0x0000019B UnityEngine.Bounds Cinemachine.CinemachineGroupComposer::get_LastBounds()
extern void CinemachineGroupComposer_get_LastBounds_mBDD21C72B4902994C351AE2BE99CDE33790374ED ();
// 0x0000019C System.Void Cinemachine.CinemachineGroupComposer::set_LastBounds(UnityEngine.Bounds)
extern void CinemachineGroupComposer_set_LastBounds_m65665450515CF77E6E04C5242803C9E2ED4950A6 ();
// 0x0000019D UnityEngine.Matrix4x4 Cinemachine.CinemachineGroupComposer::get_LastBoundsMatrix()
extern void CinemachineGroupComposer_get_LastBoundsMatrix_mAD7553857814F97F5B338B1090953E68487F26F8 ();
// 0x0000019E System.Void Cinemachine.CinemachineGroupComposer::set_LastBoundsMatrix(UnityEngine.Matrix4x4)
extern void CinemachineGroupComposer_set_LastBoundsMatrix_m17F3517E0D09514D674A5D2B589E02BA75916BB5 ();
// 0x0000019F System.Single Cinemachine.CinemachineGroupComposer::GetMaxDampTime()
extern void CinemachineGroupComposer_GetMaxDampTime_m7EFF6674345C28E480109CE58B36C3553E71BA77 ();
// 0x000001A0 System.Void Cinemachine.CinemachineGroupComposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineGroupComposer_MutateCameraState_m3F09674F5DB0D0D30F4E700F40A59EEA4827D961 ();
// 0x000001A1 System.Single Cinemachine.CinemachineGroupComposer::GetTargetHeight(UnityEngine.Vector2)
extern void CinemachineGroupComposer_GetTargetHeight_m765D054C90533C449002E5C506D18A980D66E48A ();
// 0x000001A2 UnityEngine.Bounds Cinemachine.CinemachineGroupComposer::GetScreenSpaceGroupBoundingBox(Cinemachine.ICinemachineTargetGroup,UnityEngine.Matrix4x4,UnityEngine.Vector3&)
extern void CinemachineGroupComposer_GetScreenSpaceGroupBoundingBox_mD21F1915940A7444B239E306204AC359485DA3C8 ();
// 0x000001A3 System.Void Cinemachine.CinemachineGroupComposer::.ctor()
extern void CinemachineGroupComposer__ctor_m7FC019C66BF7BFC724ECBE6614922A341CEAEB9F ();
// 0x000001A4 System.Boolean Cinemachine.CinemachineHardLockToTarget::get_IsValid()
extern void CinemachineHardLockToTarget_get_IsValid_mB4B8596FAC003DDB676DA62F8791144FF82EC9FF ();
// 0x000001A5 Cinemachine.CinemachineCore_Stage Cinemachine.CinemachineHardLockToTarget::get_Stage()
extern void CinemachineHardLockToTarget_get_Stage_m5593A2FD90EE9EBEA068EE1D2316B2A17BB445C7 ();
// 0x000001A6 System.Single Cinemachine.CinemachineHardLockToTarget::GetMaxDampTime()
extern void CinemachineHardLockToTarget_GetMaxDampTime_m9AE2387AE059EECF8F26E7F790D64B3051DDE58A ();
// 0x000001A7 System.Void Cinemachine.CinemachineHardLockToTarget::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineHardLockToTarget_MutateCameraState_mA26502B42607E6B42316FDB154CCA0F0677D7FB2 ();
// 0x000001A8 System.Void Cinemachine.CinemachineHardLockToTarget::.ctor()
extern void CinemachineHardLockToTarget__ctor_m80D0530B0306D501FB1279AD9D5FC08C86954F39 ();
// 0x000001A9 System.Boolean Cinemachine.CinemachineHardLookAt::get_IsValid()
extern void CinemachineHardLookAt_get_IsValid_m14C472D0B12C8ED2F7CBEDE1463485F546FB8856 ();
// 0x000001AA Cinemachine.CinemachineCore_Stage Cinemachine.CinemachineHardLookAt::get_Stage()
extern void CinemachineHardLookAt_get_Stage_mF5E12651C246600173A452EB64701A6D385CF832 ();
// 0x000001AB System.Void Cinemachine.CinemachineHardLookAt::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineHardLookAt_MutateCameraState_mC529F56FDA06226E4280449F649102B7392C4D17 ();
// 0x000001AC System.Void Cinemachine.CinemachineHardLookAt::.ctor()
extern void CinemachineHardLookAt__ctor_mC6209571CD75BACFB0D27C6A4F23294C575CD139 ();
// 0x000001AD System.Void Cinemachine.CinemachineOrbitalTransposer::OnValidate()
extern void CinemachineOrbitalTransposer_OnValidate_m16936FC098624F28C992EF3A43A2A30E01F24478 ();
// 0x000001AE System.Single Cinemachine.CinemachineOrbitalTransposer::UpdateHeading(System.Single,UnityEngine.Vector3,Cinemachine.AxisState&)
extern void CinemachineOrbitalTransposer_UpdateHeading_m51697AD5EA097970B5E4A2257741553B45B8E8E5 ();
// 0x000001AF System.Single Cinemachine.CinemachineOrbitalTransposer::UpdateHeading(System.Single,UnityEngine.Vector3,Cinemachine.AxisState&,Cinemachine.AxisState_Recentering&,System.Boolean)
extern void CinemachineOrbitalTransposer_UpdateHeading_mB62BE9B437A813916796102106A15EC88B7D6D38 ();
// 0x000001B0 System.Void Cinemachine.CinemachineOrbitalTransposer::OnEnable()
extern void CinemachineOrbitalTransposer_OnEnable_m1009CB168A884E6799875A253AB33B9BA429FE21 ();
// 0x000001B1 System.Void Cinemachine.CinemachineOrbitalTransposer::UpdateInputAxisProvider()
extern void CinemachineOrbitalTransposer_UpdateInputAxisProvider_m577FF1105D78BEA23D538257216CCA6AA3939C1D ();
// 0x000001B2 UnityEngine.Transform Cinemachine.CinemachineOrbitalTransposer::get_PreviousTarget()
extern void CinemachineOrbitalTransposer_get_PreviousTarget_mCD7F8B212E3CF07C2B28269DBD9AEED8FFBCC36B ();
// 0x000001B3 System.Void Cinemachine.CinemachineOrbitalTransposer::set_PreviousTarget(UnityEngine.Transform)
extern void CinemachineOrbitalTransposer_set_PreviousTarget_m8C785BA96B2C5495772AB2CE5B8AC7A11B5E9B18 ();
// 0x000001B4 System.Void Cinemachine.CinemachineOrbitalTransposer::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineOrbitalTransposer_OnTargetObjectWarped_m9D46C90267A97EB8DCA88B03C0ACEFFC29B1B424 ();
// 0x000001B5 System.Void Cinemachine.CinemachineOrbitalTransposer::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineOrbitalTransposer_ForceCameraPosition_m2152590E3A98A5FDAAF49699DE9EF9311B00BCC4 ();
// 0x000001B6 System.Boolean Cinemachine.CinemachineOrbitalTransposer::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single,Cinemachine.CinemachineVirtualCameraBase_TransitionParams&)
extern void CinemachineOrbitalTransposer_OnTransitionFromCamera_m28AA80DA45100E312174A830FD1AE9676548B391 ();
// 0x000001B7 System.Single Cinemachine.CinemachineOrbitalTransposer::GetAxisClosestValue(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineOrbitalTransposer_GetAxisClosestValue_m49678E8EEBDB7B18ABA126F1A53ED3DC412DF606 ();
// 0x000001B8 System.Single Cinemachine.CinemachineOrbitalTransposer::get_LastHeading()
extern void CinemachineOrbitalTransposer_get_LastHeading_m2E84E64E45CCFA5EDF4281474B39D2C2D4E77E65 ();
// 0x000001B9 System.Void Cinemachine.CinemachineOrbitalTransposer::set_LastHeading(System.Single)
extern void CinemachineOrbitalTransposer_set_LastHeading_m1081AD7C55D275B8A6CD15E356C6E0896967FCF7 ();
// 0x000001BA System.Void Cinemachine.CinemachineOrbitalTransposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineOrbitalTransposer_MutateCameraState_m3D0B7E27178F330F093CEEE6AE93326CBDFF57AF ();
// 0x000001BB UnityEngine.Vector3 Cinemachine.CinemachineOrbitalTransposer::GetTargetCameraPosition(UnityEngine.Vector3)
extern void CinemachineOrbitalTransposer_GetTargetCameraPosition_mEF6CEF0A22C999B4B3C29860138A88B629EDA7EC ();
// 0x000001BC System.String Cinemachine.CinemachineOrbitalTransposer::GetFullName(UnityEngine.GameObject)
extern void CinemachineOrbitalTransposer_GetFullName_m772DD042360A89E3FB812EEA5B8137AF4431DE9C ();
// 0x000001BD System.Single Cinemachine.CinemachineOrbitalTransposer::GetTargetHeading(System.Single,UnityEngine.Quaternion)
extern void CinemachineOrbitalTransposer_GetTargetHeading_m474077AD308ACEAFFCFFE43ED36B0A645B4FA786 ();
// 0x000001BE System.Void Cinemachine.CinemachineOrbitalTransposer::.ctor()
extern void CinemachineOrbitalTransposer__ctor_m00999B24FD592B5C32C79C99C6C68B30CB456206 ();
// 0x000001BF System.Boolean Cinemachine.CinemachinePOV::get_IsValid()
extern void CinemachinePOV_get_IsValid_m56F4CD3C9FE5795343397325D6128B34F7282DF3 ();
// 0x000001C0 Cinemachine.CinemachineCore_Stage Cinemachine.CinemachinePOV::get_Stage()
extern void CinemachinePOV_get_Stage_m87C432BCA78705401251C2E0E474704E22CE6D7C ();
// 0x000001C1 System.Void Cinemachine.CinemachinePOV::OnValidate()
extern void CinemachinePOV_OnValidate_m7AC95AEC250D1606DDE3ACDA968E7F6312BA60F7 ();
// 0x000001C2 System.Void Cinemachine.CinemachinePOV::OnEnable()
extern void CinemachinePOV_OnEnable_mD7B0A5051C115961BD8D43641B70BD2512E19B72 ();
// 0x000001C3 System.Void Cinemachine.CinemachinePOV::UpdateInputAxisProvider()
extern void CinemachinePOV_UpdateInputAxisProvider_m47A7388954C01FFE0948F4601D4CE198BEFC221B ();
// 0x000001C4 System.Void Cinemachine.CinemachinePOV::PrePipelineMutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachinePOV_PrePipelineMutateCameraState_m9BB2531A4EF28FD3221EB302288BACC4DE852F4A ();
// 0x000001C5 System.Void Cinemachine.CinemachinePOV::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachinePOV_MutateCameraState_mBBA8EDDE3AD2CD0AA9AF831D81D0A14FAC4BF0E7 ();
// 0x000001C6 UnityEngine.Vector2 Cinemachine.CinemachinePOV::GetRecenterTarget()
extern void CinemachinePOV_GetRecenterTarget_mC5206D2FC5D9809E62E8A536B59700C9F4F38876 ();
// 0x000001C7 System.Void Cinemachine.CinemachinePOV::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachinePOV_ForceCameraPosition_mF4DB8EC103BCAB1AB82FF19EC542E4F6E54D041A ();
// 0x000001C8 System.Boolean Cinemachine.CinemachinePOV::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single,Cinemachine.CinemachineVirtualCameraBase_TransitionParams&)
extern void CinemachinePOV_OnTransitionFromCamera_m6BC39D7F60175A61C402C262EDC067793F0F789C ();
// 0x000001C9 System.Void Cinemachine.CinemachinePOV::SetAxesForRotation(UnityEngine.Quaternion)
extern void CinemachinePOV_SetAxesForRotation_m2FAD19EC947F4B355DED9537C8622F028F01A507 ();
// 0x000001CA System.Void Cinemachine.CinemachinePOV::.ctor()
extern void CinemachinePOV__ctor_m697E2E56E6B944C9E7334DCFC8AC0BF06DA6BCD0 ();
// 0x000001CB System.Boolean Cinemachine.CinemachineSameAsFollowTarget::get_IsValid()
extern void CinemachineSameAsFollowTarget_get_IsValid_m1809C5E540F7537CC4286F0958FD1539EECA1125 ();
// 0x000001CC Cinemachine.CinemachineCore_Stage Cinemachine.CinemachineSameAsFollowTarget::get_Stage()
extern void CinemachineSameAsFollowTarget_get_Stage_m2113E69CBB5E0167E4A5D5B431C70DC7705B6707 ();
// 0x000001CD System.Single Cinemachine.CinemachineSameAsFollowTarget::GetMaxDampTime()
extern void CinemachineSameAsFollowTarget_GetMaxDampTime_m77DFBB864C5C83A91406C04F746665E4CABC45E4 ();
// 0x000001CE System.Void Cinemachine.CinemachineSameAsFollowTarget::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineSameAsFollowTarget_MutateCameraState_m85AEA567E9CC87451D0024879F38BCD53C506B00 ();
// 0x000001CF System.Void Cinemachine.CinemachineSameAsFollowTarget::.ctor()
extern void CinemachineSameAsFollowTarget__ctor_m81457B118206C0E0D833F0015A799194E9774814 ();
// 0x000001D0 System.Boolean Cinemachine.CinemachineTrackedDolly::get_IsValid()
extern void CinemachineTrackedDolly_get_IsValid_m8EDE6D1E0B40C6F90871E4B95DB5E1F4DD49BB4E ();
// 0x000001D1 Cinemachine.CinemachineCore_Stage Cinemachine.CinemachineTrackedDolly::get_Stage()
extern void CinemachineTrackedDolly_get_Stage_mFB4BDBA8C38A47C2E380E031DA81B0D1C3F22433 ();
// 0x000001D2 System.Single Cinemachine.CinemachineTrackedDolly::GetMaxDampTime()
extern void CinemachineTrackedDolly_GetMaxDampTime_m16C0CFB0875FEB726F78C571B4316AC7ADAC5D9C ();
// 0x000001D3 System.Void Cinemachine.CinemachineTrackedDolly::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineTrackedDolly_MutateCameraState_mC2D7BE38E781EDAC4B28B381BBA53F27429CB812 ();
// 0x000001D4 UnityEngine.Quaternion Cinemachine.CinemachineTrackedDolly::GetCameraOrientationAtPathPoint(UnityEngine.Quaternion,UnityEngine.Vector3)
extern void CinemachineTrackedDolly_GetCameraOrientationAtPathPoint_mEDA3B0646C44F84366FA86CD999E75DAE106CB30 ();
// 0x000001D5 UnityEngine.Vector3 Cinemachine.CinemachineTrackedDolly::get_AngularDamping()
extern void CinemachineTrackedDolly_get_AngularDamping_mC3701A9FAAE10CE9FC4F82FC6D3593866C03B6D4 ();
// 0x000001D6 System.Void Cinemachine.CinemachineTrackedDolly::.ctor()
extern void CinemachineTrackedDolly__ctor_mC643FD4B96CA4A08FA2BC2E3800FA9B448A65CEE ();
// 0x000001D7 System.Void Cinemachine.CinemachineTransposer::OnValidate()
extern void CinemachineTransposer_OnValidate_mBD6D72D809B998114DE4FDE462D39D9596E4EED9 ();
// 0x000001D8 System.Boolean Cinemachine.CinemachineTransposer::get_HideOffsetInInspector()
extern void CinemachineTransposer_get_HideOffsetInInspector_m937352B22116BAB61B21EBBF6D3417EE52F0158D ();
// 0x000001D9 System.Void Cinemachine.CinemachineTransposer::set_HideOffsetInInspector(System.Boolean)
extern void CinemachineTransposer_set_HideOffsetInInspector_m8C4560481CC4C6864C5F49A32C3495659E18521E ();
// 0x000001DA UnityEngine.Vector3 Cinemachine.CinemachineTransposer::get_EffectiveOffset()
extern void CinemachineTransposer_get_EffectiveOffset_m66C67B1F9882DF5B424E58F4B904ED0A3A519183 ();
// 0x000001DB System.Boolean Cinemachine.CinemachineTransposer::get_IsValid()
extern void CinemachineTransposer_get_IsValid_m60005E62926B8E9927396938C4C980F873F91232 ();
// 0x000001DC Cinemachine.CinemachineCore_Stage Cinemachine.CinemachineTransposer::get_Stage()
extern void CinemachineTransposer_get_Stage_mD4AE770AE7489A2D32E847C2370E0881BB1E81FB ();
// 0x000001DD System.Single Cinemachine.CinemachineTransposer::GetMaxDampTime()
extern void CinemachineTransposer_GetMaxDampTime_m4E1F2298C32E2EE3FE5D3ACCEE6F1C990D68F9F9 ();
// 0x000001DE System.Void Cinemachine.CinemachineTransposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineTransposer_MutateCameraState_m52392553F3D657BD1825ACC8EDFE79AA520DF52C ();
// 0x000001DF System.Void Cinemachine.CinemachineTransposer::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineTransposer_OnTargetObjectWarped_m898C8AABB73BBF79CA0825BB3F1F1C0FA19EA9A0 ();
// 0x000001E0 System.Void Cinemachine.CinemachineTransposer::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineTransposer_ForceCameraPosition_m839D8ADF7D8EABD7D108B71DD028C85C119D56E4 ();
// 0x000001E1 System.Void Cinemachine.CinemachineTransposer::InitPrevFrameStateInfo(Cinemachine.CameraState&,System.Single)
extern void CinemachineTransposer_InitPrevFrameStateInfo_m392AB50EFACB254C9CE86F0270ED4A9103AA753C ();
// 0x000001E2 System.Void Cinemachine.CinemachineTransposer::TrackTarget(System.Single,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void CinemachineTransposer_TrackTarget_m6681DA4BA5675F68E5EB9BB179AEF1E8A01D64D9 ();
// 0x000001E3 UnityEngine.Vector3 Cinemachine.CinemachineTransposer::GetOffsetForMinimumTargetDistance(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineTransposer_GetOffsetForMinimumTargetDistance_mC844A89B44991A156705B0169529FF39BE30ECC8 ();
// 0x000001E4 UnityEngine.Vector3 Cinemachine.CinemachineTransposer::get_Damping()
extern void CinemachineTransposer_get_Damping_m54AE51D0991EF38C1D58A464FBE0B71E8EAA53E9 ();
// 0x000001E5 UnityEngine.Vector3 Cinemachine.CinemachineTransposer::get_AngularDamping()
extern void CinemachineTransposer_get_AngularDamping_mBBC748334418408B75EC350A2E92833FEDD11276 ();
// 0x000001E6 UnityEngine.Vector3 Cinemachine.CinemachineTransposer::GetTargetCameraPosition(UnityEngine.Vector3)
extern void CinemachineTransposer_GetTargetCameraPosition_m1BB4ED7FA1B3BB3EABE41E73C6B46E6E39C671F7 ();
// 0x000001E7 UnityEngine.Quaternion Cinemachine.CinemachineTransposer::GetReferenceOrientation(UnityEngine.Vector3)
extern void CinemachineTransposer_GetReferenceOrientation_m6052EF55BF3528A668CEBE505F8E33708360F0F5 ();
// 0x000001E8 System.Void Cinemachine.CinemachineTransposer::.ctor()
extern void CinemachineTransposer__ctor_m3FA3755910D644CBE2EF94268677DCDE7C24D584 ();
// 0x000001E9 System.Void Cinemachine.AxisState::.ctor(System.Single,System.Single,System.Boolean,System.Boolean,System.Single,System.Single,System.Single,System.String,System.Boolean)
extern void AxisState__ctor_mE1E3449CB695DD0B97602DA2309969235F2AE8A0_AdjustorThunk ();
// 0x000001EA System.Void Cinemachine.AxisState::Validate()
extern void AxisState_Validate_mD31D13D5FBDA48541D62D25EBA58C6615141115C_AdjustorThunk ();
// 0x000001EB System.Void Cinemachine.AxisState::Reset()
extern void AxisState_Reset_m467FB333DF4E419185F468B80CD82F75C773A3FE_AdjustorThunk ();
// 0x000001EC System.Void Cinemachine.AxisState::SetInputAxisProvider(System.Int32,Cinemachine.AxisState_IInputAxisProvider)
extern void AxisState_SetInputAxisProvider_m7396F12E659493FD37D66F79B04CF93D4BBDA527_AdjustorThunk ();
// 0x000001ED System.Boolean Cinemachine.AxisState::get_HasInputProvider()
extern void AxisState_get_HasInputProvider_m38460D72EBD97A207B33485CA157D6D4D3193226_AdjustorThunk ();
// 0x000001EE System.Boolean Cinemachine.AxisState::Update(System.Single)
extern void AxisState_Update_mEA3BADC4B491D705D61357CD1ECE295FC243670A_AdjustorThunk ();
// 0x000001EF System.Single Cinemachine.AxisState::ClampValue(System.Single)
extern void AxisState_ClampValue_m44330844584E13D1E1921B6174DD5257CDFFA960_AdjustorThunk ();
// 0x000001F0 System.Boolean Cinemachine.AxisState::MaxSpeedUpdate(System.Single,System.Single)
extern void AxisState_MaxSpeedUpdate_mC53D3EABA41652F2D991263538542FA23B8FB517_AdjustorThunk ();
// 0x000001F1 System.Single Cinemachine.AxisState::GetMaxSpeed()
extern void AxisState_GetMaxSpeed_mE2AB97681281AA228333FC67BD9AB5F8CEA640AA_AdjustorThunk ();
// 0x000001F2 System.Boolean Cinemachine.AxisState::get_ValueRangeLocked()
extern void AxisState_get_ValueRangeLocked_mAA8A098676C624D20443DC6207F7CE4268824369_AdjustorThunk ();
// 0x000001F3 System.Void Cinemachine.AxisState::set_ValueRangeLocked(System.Boolean)
extern void AxisState_set_ValueRangeLocked_m556066F839F1D835CFB65398E5D2776E74510F2A_AdjustorThunk ();
// 0x000001F4 System.Boolean Cinemachine.AxisState::get_HasRecentering()
extern void AxisState_get_HasRecentering_m02782E465AF3A314B2586C24230C03FBD609EB12_AdjustorThunk ();
// 0x000001F5 System.Void Cinemachine.AxisState::set_HasRecentering(System.Boolean)
extern void AxisState_set_HasRecentering_m30D6476F657160F87D850632F36DA226C04FCDE6_AdjustorThunk ();
// 0x000001F6 Cinemachine.LensSettings Cinemachine.CameraState::get_Lens()
extern void CameraState_get_Lens_m8DD7FD2B8954A56E2CBD83D1EF7A77958F685893_AdjustorThunk ();
// 0x000001F7 System.Void Cinemachine.CameraState::set_Lens(Cinemachine.LensSettings)
extern void CameraState_set_Lens_mAABE6FFC1E5F9A33EE16A7B009B927ECB2F29523_AdjustorThunk ();
// 0x000001F8 UnityEngine.Vector3 Cinemachine.CameraState::get_ReferenceUp()
extern void CameraState_get_ReferenceUp_m9A1F4A533328BABA7C81C4AD2F1E830375495B5A_AdjustorThunk ();
// 0x000001F9 System.Void Cinemachine.CameraState::set_ReferenceUp(UnityEngine.Vector3)
extern void CameraState_set_ReferenceUp_mE156A37CA4B6BF3E8BA65A391730873572F24358_AdjustorThunk ();
// 0x000001FA UnityEngine.Vector3 Cinemachine.CameraState::get_ReferenceLookAt()
extern void CameraState_get_ReferenceLookAt_m32BCDF0492BA9AAECC597DF02676D66BF0566548_AdjustorThunk ();
// 0x000001FB System.Void Cinemachine.CameraState::set_ReferenceLookAt(UnityEngine.Vector3)
extern void CameraState_set_ReferenceLookAt_mF7CF3F3DD4D8DA16C08C4706E6C1128B48A3CEA2_AdjustorThunk ();
// 0x000001FC System.Boolean Cinemachine.CameraState::get_HasLookAt()
extern void CameraState_get_HasLookAt_mE3BC5114383606752FDDED488732126B5644E81D_AdjustorThunk ();
// 0x000001FD UnityEngine.Vector3 Cinemachine.CameraState::get_RawPosition()
extern void CameraState_get_RawPosition_mA01BC7F842C837D49F0542A0475AE0EA9C88539D_AdjustorThunk ();
// 0x000001FE System.Void Cinemachine.CameraState::set_RawPosition(UnityEngine.Vector3)
extern void CameraState_set_RawPosition_m0E1142A79939C7AD7156986F91CD0F1D60499A31_AdjustorThunk ();
// 0x000001FF UnityEngine.Quaternion Cinemachine.CameraState::get_RawOrientation()
extern void CameraState_get_RawOrientation_m61C0AC1D87FB6C869DA02458732BF6023130F163_AdjustorThunk ();
// 0x00000200 System.Void Cinemachine.CameraState::set_RawOrientation(UnityEngine.Quaternion)
extern void CameraState_set_RawOrientation_mF473C9D14F4C653E31B9D17B29198A0A26FB710E_AdjustorThunk ();
// 0x00000201 UnityEngine.Vector3 Cinemachine.CameraState::get_PositionDampingBypass()
extern void CameraState_get_PositionDampingBypass_m4F3CAC6077C7D9CE366DE64FDC0F76B8E4309965_AdjustorThunk ();
// 0x00000202 System.Void Cinemachine.CameraState::set_PositionDampingBypass(UnityEngine.Vector3)
extern void CameraState_set_PositionDampingBypass_m6ED6EE6829EAD07FB68F3281F682360F9E0B5707_AdjustorThunk ();
// 0x00000203 System.Single Cinemachine.CameraState::get_ShotQuality()
extern void CameraState_get_ShotQuality_m3FE037E90A92A214DAEEA694D75ECF717520E285_AdjustorThunk ();
// 0x00000204 System.Void Cinemachine.CameraState::set_ShotQuality(System.Single)
extern void CameraState_set_ShotQuality_m02E14BA3BB2628501258190348C309AF56836E3B_AdjustorThunk ();
// 0x00000205 UnityEngine.Vector3 Cinemachine.CameraState::get_PositionCorrection()
extern void CameraState_get_PositionCorrection_m19DFDEC5E34379495FE563689462063CF01CC87B_AdjustorThunk ();
// 0x00000206 System.Void Cinemachine.CameraState::set_PositionCorrection(UnityEngine.Vector3)
extern void CameraState_set_PositionCorrection_m5A6BC8785013D7DA1B8B814BEA2FB2893C8D681B_AdjustorThunk ();
// 0x00000207 UnityEngine.Quaternion Cinemachine.CameraState::get_OrientationCorrection()
extern void CameraState_get_OrientationCorrection_m50B2841F1C1C41B276CE76048DBE68CC355EBE9E_AdjustorThunk ();
// 0x00000208 System.Void Cinemachine.CameraState::set_OrientationCorrection(UnityEngine.Quaternion)
extern void CameraState_set_OrientationCorrection_m78B62F6D9C90041D16F969BF5C5DF5775380F4E3_AdjustorThunk ();
// 0x00000209 UnityEngine.Vector3 Cinemachine.CameraState::get_CorrectedPosition()
extern void CameraState_get_CorrectedPosition_mFEB78C718574311BE01F52353220D8E3EC062344_AdjustorThunk ();
// 0x0000020A UnityEngine.Quaternion Cinemachine.CameraState::get_CorrectedOrientation()
extern void CameraState_get_CorrectedOrientation_mB74864040A12CF81360C263385AE1CFFFA73E9BB_AdjustorThunk ();
// 0x0000020B UnityEngine.Vector3 Cinemachine.CameraState::get_FinalPosition()
extern void CameraState_get_FinalPosition_mABA119F4F7BDAB3C56B5A9D50A0A4E9F0EC5BFBA_AdjustorThunk ();
// 0x0000020C UnityEngine.Quaternion Cinemachine.CameraState::get_FinalOrientation()
extern void CameraState_get_FinalOrientation_m44213894D5B3665846C120EA54FD5F116FBBBC40_AdjustorThunk ();
// 0x0000020D Cinemachine.CameraState_BlendHintValue Cinemachine.CameraState::get_BlendHint()
extern void CameraState_get_BlendHint_m787612D5DE9717F032149B538F603DA69B26FC75_AdjustorThunk ();
// 0x0000020E System.Void Cinemachine.CameraState::set_BlendHint(Cinemachine.CameraState_BlendHintValue)
extern void CameraState_set_BlendHint_mFEAA3F666F38C388C5CCF863FF3711CEEE3A0A52_AdjustorThunk ();
// 0x0000020F Cinemachine.CameraState Cinemachine.CameraState::get_Default()
extern void CameraState_get_Default_m12D560DD60BC9AC6B1A0287EF92D21BFF1C1C8A7 ();
// 0x00000210 System.Int32 Cinemachine.CameraState::get_NumCustomBlendables()
extern void CameraState_get_NumCustomBlendables_m45122BC6F6592ACC07FD85C38B3A756FEC60A7CF_AdjustorThunk ();
// 0x00000211 System.Void Cinemachine.CameraState::set_NumCustomBlendables(System.Int32)
extern void CameraState_set_NumCustomBlendables_mF90E1B32FE572F25B187D449C5AEE2499AAE564F_AdjustorThunk ();
// 0x00000212 Cinemachine.CameraState_CustomBlendable Cinemachine.CameraState::GetCustomBlendable(System.Int32)
extern void CameraState_GetCustomBlendable_mD4E4CD7E5D2F4ABF74B78B4997BEA73C65C704BF_AdjustorThunk ();
// 0x00000213 System.Int32 Cinemachine.CameraState::FindCustomBlendable(UnityEngine.Object)
extern void CameraState_FindCustomBlendable_mADB6FC113F422BEEA9B9DE3CCEAA69C505BEEDAC_AdjustorThunk ();
// 0x00000214 System.Void Cinemachine.CameraState::AddCustomBlendable(Cinemachine.CameraState_CustomBlendable)
extern void CameraState_AddCustomBlendable_mD2B67C82217C56D550713328D287282A0548CD97_AdjustorThunk ();
// 0x00000215 Cinemachine.CameraState Cinemachine.CameraState::Lerp(Cinemachine.CameraState,Cinemachine.CameraState,System.Single)
extern void CameraState_Lerp_m29CBA400AE3DAD80F7B1F9B81B9758244530CB9B ();
// 0x00000216 System.Single Cinemachine.CameraState::InterpolateFOV(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void CameraState_InterpolateFOV_m2C5E3CCFCAE4D654A2BD7F07A50F5E52EEBB8E02 ();
// 0x00000217 UnityEngine.Vector3 Cinemachine.CameraState::ApplyPosBlendHint(UnityEngine.Vector3,Cinemachine.CameraState_BlendHintValue,UnityEngine.Vector3,Cinemachine.CameraState_BlendHintValue,UnityEngine.Vector3,UnityEngine.Vector3)
extern void CameraState_ApplyPosBlendHint_m9A27867615504FB4A36D503396BA10DE7603986C ();
// 0x00000218 UnityEngine.Quaternion Cinemachine.CameraState::ApplyRotBlendHint(UnityEngine.Quaternion,Cinemachine.CameraState_BlendHintValue,UnityEngine.Quaternion,Cinemachine.CameraState_BlendHintValue,UnityEngine.Quaternion,UnityEngine.Quaternion)
extern void CameraState_ApplyRotBlendHint_mECDD8502F1EB7BC1B728A7DC3247AEC7B618DDE5 ();
// 0x00000219 UnityEngine.Vector3 Cinemachine.CameraState::InterpolatePosition(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CameraState_InterpolatePosition_m731CF3321931B836BFF7D6025001E0DBDBBF8341_AdjustorThunk ();
// 0x0000021A System.Void Cinemachine.CameraState::.cctor()
extern void CameraState__cctor_m9FC1441CCCB6B5F891327B1F238C4B26FEC06760 ();
// 0x0000021B Cinemachine.ICinemachineCamera Cinemachine.CinemachineBlend::get_CamA()
extern void CinemachineBlend_get_CamA_m84EE61BF64BEBAA6DD45591F1D6E727B894DAC91 ();
// 0x0000021C System.Void Cinemachine.CinemachineBlend::set_CamA(Cinemachine.ICinemachineCamera)
extern void CinemachineBlend_set_CamA_m5E656E137DE95F70ADF349416BDF9845358143BF ();
// 0x0000021D Cinemachine.ICinemachineCamera Cinemachine.CinemachineBlend::get_CamB()
extern void CinemachineBlend_get_CamB_m81ADE44158093EBCB50F04D90A1DD775FC02C4A7 ();
// 0x0000021E System.Void Cinemachine.CinemachineBlend::set_CamB(Cinemachine.ICinemachineCamera)
extern void CinemachineBlend_set_CamB_m502F49F7663036661B7C21945F58ED2C584308EA ();
// 0x0000021F UnityEngine.AnimationCurve Cinemachine.CinemachineBlend::get_BlendCurve()
extern void CinemachineBlend_get_BlendCurve_m6A1FF79078DEA51B8343A4135E7A5E002D5D13C6 ();
// 0x00000220 System.Void Cinemachine.CinemachineBlend::set_BlendCurve(UnityEngine.AnimationCurve)
extern void CinemachineBlend_set_BlendCurve_m1C92DE13808FD00C1AE25E8D2AA898B82E77129C ();
// 0x00000221 System.Single Cinemachine.CinemachineBlend::get_TimeInBlend()
extern void CinemachineBlend_get_TimeInBlend_mFA561FA319D53F2A245E6D14A67F10356FDE9502 ();
// 0x00000222 System.Void Cinemachine.CinemachineBlend::set_TimeInBlend(System.Single)
extern void CinemachineBlend_set_TimeInBlend_mCB11D4F786D1D2201521E1C5E43FBAA7CF77202E ();
// 0x00000223 System.Single Cinemachine.CinemachineBlend::get_BlendWeight()
extern void CinemachineBlend_get_BlendWeight_mCCA9907E0F251FB96CCC75DE16EB76359E69D392 ();
// 0x00000224 System.Boolean Cinemachine.CinemachineBlend::get_IsValid()
extern void CinemachineBlend_get_IsValid_m55FFFA5BC32710DA0EF7CA8DBD7B0303D562D0D2 ();
// 0x00000225 System.Single Cinemachine.CinemachineBlend::get_Duration()
extern void CinemachineBlend_get_Duration_mB9E2A918F60A7F8BFFADB38BE2D51455FECDF7E4 ();
// 0x00000226 System.Void Cinemachine.CinemachineBlend::set_Duration(System.Single)
extern void CinemachineBlend_set_Duration_m6624099445533093B65C3E92C25060E2C5B2692B ();
// 0x00000227 System.Boolean Cinemachine.CinemachineBlend::get_IsComplete()
extern void CinemachineBlend_get_IsComplete_m3FF0BF1A998D7E09ED0FCBEA109C9BEE7721CA50 ();
// 0x00000228 System.String Cinemachine.CinemachineBlend::get_Description()
extern void CinemachineBlend_get_Description_m4096D0C82956E1009FA82A07FA6BB184FD5EBC59 ();
// 0x00000229 System.Boolean Cinemachine.CinemachineBlend::Uses(Cinemachine.ICinemachineCamera)
extern void CinemachineBlend_Uses_mE5C14AEF4BE8C61F17564F4F5DA84831449B6F4B ();
// 0x0000022A System.Void Cinemachine.CinemachineBlend::.ctor(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,UnityEngine.AnimationCurve,System.Single,System.Single)
extern void CinemachineBlend__ctor_mB06EF56D92F3900609669689E8820647EE84B5A3 ();
// 0x0000022B System.Void Cinemachine.CinemachineBlend::UpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineBlend_UpdateCameraState_m4B58F6808D5B9494A583E9C0CBDC4841CBEB99E1 ();
// 0x0000022C Cinemachine.CameraState Cinemachine.CinemachineBlend::get_State()
extern void CinemachineBlend_get_State_m353325CD92B13EF46EAF00985769217EA4F98FA1 ();
// 0x0000022D System.Single Cinemachine.CinemachineBlendDefinition::get_BlendTime()
extern void CinemachineBlendDefinition_get_BlendTime_m2185E8662569BE0201996EAA3AC55C1A095CA5E3_AdjustorThunk ();
// 0x0000022E System.Void Cinemachine.CinemachineBlendDefinition::.ctor(Cinemachine.CinemachineBlendDefinition_Style,System.Single)
extern void CinemachineBlendDefinition__ctor_m51379366ABFBFF4642735E6C843F54CF45D642CF_AdjustorThunk ();
// 0x0000022F System.Void Cinemachine.CinemachineBlendDefinition::CreateStandardCurves()
extern void CinemachineBlendDefinition_CreateStandardCurves_m4877FF63D3A4E8933F6817ECAEB9B500B9A3D56B_AdjustorThunk ();
// 0x00000230 UnityEngine.AnimationCurve Cinemachine.CinemachineBlendDefinition::get_BlendCurve()
extern void CinemachineBlendDefinition_get_BlendCurve_m547D15706E83EACB4DE888750C0728BDE5974873_AdjustorThunk ();
// 0x00000231 System.Void Cinemachine.StaticPointVirtualCamera::.ctor(Cinemachine.CameraState,System.String)
extern void StaticPointVirtualCamera__ctor_mAC0BFA55F9A05C87AFAFC15C1282DCF7A88F7330 ();
// 0x00000232 System.Void Cinemachine.StaticPointVirtualCamera::SetState(Cinemachine.CameraState)
extern void StaticPointVirtualCamera_SetState_m0111F6AAC091400D8554DFCD60258C958D241933 ();
// 0x00000233 System.String Cinemachine.StaticPointVirtualCamera::get_Name()
extern void StaticPointVirtualCamera_get_Name_m88CDC311CAE2371482E697C343C5D364D3921FBA ();
// 0x00000234 System.Void Cinemachine.StaticPointVirtualCamera::set_Name(System.String)
extern void StaticPointVirtualCamera_set_Name_mC42E291C5240205CAE873C773EA2B4D1AEBCBA38 ();
// 0x00000235 System.String Cinemachine.StaticPointVirtualCamera::get_Description()
extern void StaticPointVirtualCamera_get_Description_mD42A5CEF974DE56D2F2ADEE0D041A51FAA24FDA8 ();
// 0x00000236 System.Int32 Cinemachine.StaticPointVirtualCamera::get_Priority()
extern void StaticPointVirtualCamera_get_Priority_mD186335682BAEEA3BDBB50BA6667DC287FAFAF55 ();
// 0x00000237 System.Void Cinemachine.StaticPointVirtualCamera::set_Priority(System.Int32)
extern void StaticPointVirtualCamera_set_Priority_m1200B4DCA10859C74244CBA6D6619222450613A4 ();
// 0x00000238 UnityEngine.Transform Cinemachine.StaticPointVirtualCamera::get_LookAt()
extern void StaticPointVirtualCamera_get_LookAt_m81DE46064CF375735C542138F35390F99692F864 ();
// 0x00000239 System.Void Cinemachine.StaticPointVirtualCamera::set_LookAt(UnityEngine.Transform)
extern void StaticPointVirtualCamera_set_LookAt_m0AB6CA2B5FCE282A9D34CF1F90D6B53E538921D3 ();
// 0x0000023A UnityEngine.Transform Cinemachine.StaticPointVirtualCamera::get_Follow()
extern void StaticPointVirtualCamera_get_Follow_m5C80C9614891CEA38FD1C386B5EA6A0A5D2D856C ();
// 0x0000023B System.Void Cinemachine.StaticPointVirtualCamera::set_Follow(UnityEngine.Transform)
extern void StaticPointVirtualCamera_set_Follow_m607FEDDF53E09CD16CA022F1E55783558FA71746 ();
// 0x0000023C Cinemachine.CameraState Cinemachine.StaticPointVirtualCamera::get_State()
extern void StaticPointVirtualCamera_get_State_m4864EB89CDE70665713ADCF80A4612B5BDE43980 ();
// 0x0000023D System.Void Cinemachine.StaticPointVirtualCamera::set_State(Cinemachine.CameraState)
extern void StaticPointVirtualCamera_set_State_mC75EE398CBB9A6BE8054F5CD5C4AF90982EEF670 ();
// 0x0000023E UnityEngine.GameObject Cinemachine.StaticPointVirtualCamera::get_VirtualCameraGameObject()
extern void StaticPointVirtualCamera_get_VirtualCameraGameObject_mE9318C1A3D5D4779A2D20ECC5FE32C2872E8059E ();
// 0x0000023F System.Boolean Cinemachine.StaticPointVirtualCamera::get_IsValid()
extern void StaticPointVirtualCamera_get_IsValid_m207DE6EDCE733D57C032075ED3FEE27A0DA5EDA4 ();
// 0x00000240 Cinemachine.ICinemachineCamera Cinemachine.StaticPointVirtualCamera::get_ParentCamera()
extern void StaticPointVirtualCamera_get_ParentCamera_m939FE729B7EEC40DA987EA842094EF2D2D660B0E ();
// 0x00000241 System.Boolean Cinemachine.StaticPointVirtualCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void StaticPointVirtualCamera_IsLiveChild_mE99E5559C21364521C4DF662E25EC8CA3300AD45 ();
// 0x00000242 System.Void Cinemachine.StaticPointVirtualCamera::UpdateCameraState(UnityEngine.Vector3,System.Single)
extern void StaticPointVirtualCamera_UpdateCameraState_m032CCA1E862B142F48323104B4785597D6F1BE50 ();
// 0x00000243 System.Void Cinemachine.StaticPointVirtualCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void StaticPointVirtualCamera_InternalUpdateCameraState_m1B0FEA4EB03147B15FDA4D1B8BC57F1259BB4008 ();
// 0x00000244 System.Void Cinemachine.StaticPointVirtualCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void StaticPointVirtualCamera_OnTransitionFromCamera_m9B762A7A6E09D9F4B670045857761C91EFC28823 ();
// 0x00000245 System.Void Cinemachine.StaticPointVirtualCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void StaticPointVirtualCamera_OnTargetObjectWarped_m41F5BB8D4A13B4B4D72A8B764E61A077F8CD167F ();
// 0x00000246 System.Void Cinemachine.BlendSourceVirtualCamera::.ctor(Cinemachine.CinemachineBlend)
extern void BlendSourceVirtualCamera__ctor_m762CFEB65D584FC854F9653CF1A97444FF86E08B ();
// 0x00000247 Cinemachine.CinemachineBlend Cinemachine.BlendSourceVirtualCamera::get_Blend()
extern void BlendSourceVirtualCamera_get_Blend_mB5C0C8918EA30ABEE4F85F1BB493075EFF0F1B60 ();
// 0x00000248 System.Void Cinemachine.BlendSourceVirtualCamera::set_Blend(Cinemachine.CinemachineBlend)
extern void BlendSourceVirtualCamera_set_Blend_m2EBC2E6A8F75FF3F416F0FE2583DA24E6320FEFA ();
// 0x00000249 System.String Cinemachine.BlendSourceVirtualCamera::get_Name()
extern void BlendSourceVirtualCamera_get_Name_m4F4C48F79D68A9E15606415175DD1067B950677C ();
// 0x0000024A System.String Cinemachine.BlendSourceVirtualCamera::get_Description()
extern void BlendSourceVirtualCamera_get_Description_m3B5EA1CECACCF4EA3B337E1DEA134DE4F87234C5 ();
// 0x0000024B System.Int32 Cinemachine.BlendSourceVirtualCamera::get_Priority()
extern void BlendSourceVirtualCamera_get_Priority_m043ABE54F59106B010EEBC2F48AEF70E82AFBF92 ();
// 0x0000024C System.Void Cinemachine.BlendSourceVirtualCamera::set_Priority(System.Int32)
extern void BlendSourceVirtualCamera_set_Priority_mC7108E9EAC45C4F8492791A250F72100A044508C ();
// 0x0000024D UnityEngine.Transform Cinemachine.BlendSourceVirtualCamera::get_LookAt()
extern void BlendSourceVirtualCamera_get_LookAt_m923B7FD1549B3E1090A3ACBB9E51A28A195D7813 ();
// 0x0000024E System.Void Cinemachine.BlendSourceVirtualCamera::set_LookAt(UnityEngine.Transform)
extern void BlendSourceVirtualCamera_set_LookAt_m4D4DB97225E4779DBE60447EF5E89A8EA91CEDFC ();
// 0x0000024F UnityEngine.Transform Cinemachine.BlendSourceVirtualCamera::get_Follow()
extern void BlendSourceVirtualCamera_get_Follow_m2AFD8A2446B3DD4C713C4BE180974AEA67F27B7C ();
// 0x00000250 System.Void Cinemachine.BlendSourceVirtualCamera::set_Follow(UnityEngine.Transform)
extern void BlendSourceVirtualCamera_set_Follow_m24D9B623C684CD670659A4E36371C78007DEE55A ();
// 0x00000251 Cinemachine.CameraState Cinemachine.BlendSourceVirtualCamera::get_State()
extern void BlendSourceVirtualCamera_get_State_mA0FD90B6B6D4FF668604E9B199E4DBB6299D28D8 ();
// 0x00000252 System.Void Cinemachine.BlendSourceVirtualCamera::set_State(Cinemachine.CameraState)
extern void BlendSourceVirtualCamera_set_State_m1939F89FAA80BDCB54AA3983EA6DDCB582E1C6BB ();
// 0x00000253 UnityEngine.GameObject Cinemachine.BlendSourceVirtualCamera::get_VirtualCameraGameObject()
extern void BlendSourceVirtualCamera_get_VirtualCameraGameObject_mFA88FE034A5AD685D2E797CD21050EEF5FE3E2AB ();
// 0x00000254 System.Boolean Cinemachine.BlendSourceVirtualCamera::get_IsValid()
extern void BlendSourceVirtualCamera_get_IsValid_m4D11A4E0F85913145D907D6DF092E653D3BCB272 ();
// 0x00000255 Cinemachine.ICinemachineCamera Cinemachine.BlendSourceVirtualCamera::get_ParentCamera()
extern void BlendSourceVirtualCamera_get_ParentCamera_mAAB7D1922FEB01F0D76E175DFF5F588B3557B46D ();
// 0x00000256 System.Boolean Cinemachine.BlendSourceVirtualCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void BlendSourceVirtualCamera_IsLiveChild_m5D3C8B7EA632D8E40D2D5B75F43B762524A3D8BB ();
// 0x00000257 Cinemachine.CameraState Cinemachine.BlendSourceVirtualCamera::CalculateNewState(System.Single)
extern void BlendSourceVirtualCamera_CalculateNewState_mA5EA36A4D37412F1B2B14CFA7E7C1478CACEEF5D ();
// 0x00000258 System.Void Cinemachine.BlendSourceVirtualCamera::UpdateCameraState(UnityEngine.Vector3,System.Single)
extern void BlendSourceVirtualCamera_UpdateCameraState_m7B24A298453FCB56F8B840E7DA846270F621AE55 ();
// 0x00000259 System.Void Cinemachine.BlendSourceVirtualCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void BlendSourceVirtualCamera_InternalUpdateCameraState_m4E07980798FF47304F5A3A420EDDFD99E8F7B62F ();
// 0x0000025A System.Void Cinemachine.BlendSourceVirtualCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void BlendSourceVirtualCamera_OnTransitionFromCamera_mEACC986DA2FD0B5ECA68773558FC33504FB32947 ();
// 0x0000025B System.Void Cinemachine.BlendSourceVirtualCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void BlendSourceVirtualCamera_OnTargetObjectWarped_mBA61A40425AE0741B93ABEC054F616B6E7C39A4C ();
// 0x0000025C Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineBlenderSettings::GetBlendForVirtualCameras(System.String,System.String,Cinemachine.CinemachineBlendDefinition)
extern void CinemachineBlenderSettings_GetBlendForVirtualCameras_m83B852A5B14C8ED39E2FC581D3BB11528FD3B565 ();
// 0x0000025D System.Void Cinemachine.CinemachineBlenderSettings::.ctor()
extern void CinemachineBlenderSettings__ctor_m8548E0C3CD5CBF25ADEE8574A5258A021D1E1A07 ();
// 0x0000025E Cinemachine.CinemachineVirtualCameraBase Cinemachine.CinemachineComponentBase::get_VirtualCamera()
extern void CinemachineComponentBase_get_VirtualCamera_mDDC4BEDF77A93F4C25C2E62CBF96542ABB6FE3BA ();
// 0x0000025F UnityEngine.Transform Cinemachine.CinemachineComponentBase::get_FollowTarget()
extern void CinemachineComponentBase_get_FollowTarget_m6A52B9EAC2F1B1DD8D8F901A48F52A296B4715AC ();
// 0x00000260 UnityEngine.Transform Cinemachine.CinemachineComponentBase::get_LookAtTarget()
extern void CinemachineComponentBase_get_LookAtTarget_m0B8D7462A7C631E082634733954374BD9C030F70 ();
// 0x00000261 System.Void Cinemachine.CinemachineComponentBase::UpdateFollowTargetCache()
extern void CinemachineComponentBase_UpdateFollowTargetCache_m8047A77301A9616719C733A8D394D881FB78BA0B ();
// 0x00000262 Cinemachine.ICinemachineTargetGroup Cinemachine.CinemachineComponentBase::get_AbstractFollowTargetGroup()
extern void CinemachineComponentBase_get_AbstractFollowTargetGroup_m3A97181333E7E463488F030F83D72D4D671946D1 ();
// 0x00000263 Cinemachine.CinemachineTargetGroup Cinemachine.CinemachineComponentBase::get_FollowTargetGroup()
extern void CinemachineComponentBase_get_FollowTargetGroup_m7AFAB2E9C70EC126379938A1FCFC90B14EC20472 ();
// 0x00000264 UnityEngine.Vector3 Cinemachine.CinemachineComponentBase::get_FollowTargetPosition()
extern void CinemachineComponentBase_get_FollowTargetPosition_mF3A92D2EE8A07BC0E1FC820AFAA5F4CC24CD1C94 ();
// 0x00000265 UnityEngine.Quaternion Cinemachine.CinemachineComponentBase::get_FollowTargetRotation()
extern void CinemachineComponentBase_get_FollowTargetRotation_m63FA12EC6372FC0D1D4C0224C86AD054EA31387F ();
// 0x00000266 System.Void Cinemachine.CinemachineComponentBase::UpdateLookAtTargetCache()
extern void CinemachineComponentBase_UpdateLookAtTargetCache_m0E7E8C9C13122A00F3506B5094A71A22DD001DE6 ();
// 0x00000267 Cinemachine.ICinemachineTargetGroup Cinemachine.CinemachineComponentBase::get_AbstractLookAtTargetGroup()
extern void CinemachineComponentBase_get_AbstractLookAtTargetGroup_m09E391BC22E9B714A1A18DC19BEF1E445A39AAA8 ();
// 0x00000268 Cinemachine.CinemachineTargetGroup Cinemachine.CinemachineComponentBase::get_LookAtTargetGroup()
extern void CinemachineComponentBase_get_LookAtTargetGroup_mF5DE59F602311812B2A1B3EC112ECB26DB0585BA ();
// 0x00000269 UnityEngine.Vector3 Cinemachine.CinemachineComponentBase::get_LookAtTargetPosition()
extern void CinemachineComponentBase_get_LookAtTargetPosition_m276755F157FCDC7F0933FF7E965826B6B782031B ();
// 0x0000026A UnityEngine.Quaternion Cinemachine.CinemachineComponentBase::get_LookAtTargetRotation()
extern void CinemachineComponentBase_get_LookAtTargetRotation_mCCBCCE7A00B6FECC898C11A787FB18432EF38A86 ();
// 0x0000026B Cinemachine.CameraState Cinemachine.CinemachineComponentBase::get_VcamState()
extern void CinemachineComponentBase_get_VcamState_m0F36DA00A9FF33209646471FDF6F7EC6F7DF6B80 ();
// 0x0000026C System.Boolean Cinemachine.CinemachineComponentBase::get_IsValid()
// 0x0000026D System.Void Cinemachine.CinemachineComponentBase::PrePipelineMutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineComponentBase_PrePipelineMutateCameraState_mAFE097E8C3220CE39BEFFFB48BDF31779A6C68D0 ();
// 0x0000026E Cinemachine.CinemachineCore_Stage Cinemachine.CinemachineComponentBase::get_Stage()
// 0x0000026F System.Boolean Cinemachine.CinemachineComponentBase::get_BodyAppliesAfterAim()
extern void CinemachineComponentBase_get_BodyAppliesAfterAim_mE51BED341B65934E6CA3D8AE31A4F84B2525F52A ();
// 0x00000270 System.Void Cinemachine.CinemachineComponentBase::MutateCameraState(Cinemachine.CameraState&,System.Single)
// 0x00000271 System.Boolean Cinemachine.CinemachineComponentBase::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single,Cinemachine.CinemachineVirtualCameraBase_TransitionParams&)
extern void CinemachineComponentBase_OnTransitionFromCamera_m9DD4DF577144AF4CEA69C855EAA324D1168EBBE4 ();
// 0x00000272 System.Void Cinemachine.CinemachineComponentBase::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineComponentBase_OnTargetObjectWarped_m68C3CCD5A93FF2DD4013F33DDC1204A97B54A701 ();
// 0x00000273 System.Void Cinemachine.CinemachineComponentBase::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineComponentBase_ForceCameraPosition_mFDFA0AE6EA6C4E03EAB878E392AD312AAD454EF4 ();
// 0x00000274 System.Single Cinemachine.CinemachineComponentBase::GetMaxDampTime()
extern void CinemachineComponentBase_GetMaxDampTime_m630233212BCB908E0F9EF150C2FDF5559808691F ();
// 0x00000275 System.Void Cinemachine.CinemachineComponentBase::.ctor()
extern void CinemachineComponentBase__ctor_mF80CD1194482BC499205396A8622FAE20F5B75D4 ();
// 0x00000276 Cinemachine.CinemachineCore Cinemachine.CinemachineCore::get_Instance()
extern void CinemachineCore_get_Instance_mCD8E65EBCBB58BEDC6FD0C503AB9E866B76AFA83 ();
// 0x00000277 System.Single Cinemachine.CinemachineCore::get_DeltaTime()
extern void CinemachineCore_get_DeltaTime_m8AC61BA9F0163DFE1A3D0FC5C40937B7722EB883 ();
// 0x00000278 System.Single Cinemachine.CinemachineCore::get_CurrentTime()
extern void CinemachineCore_get_CurrentTime_mBD3A55B23004CB425D9297086BC20D7C55797625 ();
// 0x00000279 System.Int32 Cinemachine.CinemachineCore::get_BrainCount()
extern void CinemachineCore_get_BrainCount_mA544A424A3E3FC613955E2D60CA93484BC97616C ();
// 0x0000027A Cinemachine.CinemachineBrain Cinemachine.CinemachineCore::GetActiveBrain(System.Int32)
extern void CinemachineCore_GetActiveBrain_m99FB4BE86B83C680EB414B5D1770908EA7ADF558 ();
// 0x0000027B System.Void Cinemachine.CinemachineCore::AddActiveBrain(Cinemachine.CinemachineBrain)
extern void CinemachineCore_AddActiveBrain_m0BD0B7F334ABB98A322EACBA8285BD164D6E69AB ();
// 0x0000027C System.Void Cinemachine.CinemachineCore::RemoveActiveBrain(Cinemachine.CinemachineBrain)
extern void CinemachineCore_RemoveActiveBrain_m1FF228AA890EFDF236F0E434A1C88701A66BAE15 ();
// 0x0000027D System.Int32 Cinemachine.CinemachineCore::get_VirtualCameraCount()
extern void CinemachineCore_get_VirtualCameraCount_m09675B5895A728AC31A0892F5343264CB34FE708 ();
// 0x0000027E Cinemachine.CinemachineVirtualCameraBase Cinemachine.CinemachineCore::GetVirtualCamera(System.Int32)
extern void CinemachineCore_GetVirtualCamera_m648982BBF286DB719899EB96C4E7FF17B1B5C86C ();
// 0x0000027F System.Void Cinemachine.CinemachineCore::AddActiveCamera(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_AddActiveCamera_m15B0C7AD4C1A0F46FC24A1121B399D80F7026DB7 ();
// 0x00000280 System.Void Cinemachine.CinemachineCore::RemoveActiveCamera(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_RemoveActiveCamera_mD28005289E4D2F4000E8121243A97DCE8922B4C1 ();
// 0x00000281 System.Void Cinemachine.CinemachineCore::CameraDestroyed(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_CameraDestroyed_m9A825D47C357F36DABCC51C466E0704BD49E13EB ();
// 0x00000282 System.Void Cinemachine.CinemachineCore::CameraEnabled(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_CameraEnabled_m5DC7D833542C8CEA753704CE9026C4CE9A00EAC6 ();
// 0x00000283 System.Void Cinemachine.CinemachineCore::CameraDisabled(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_CameraDisabled_m9B1E9D658D5C6090F2C85A82C013908DC99A380E ();
// 0x00000284 System.Int32 Cinemachine.CinemachineCore::get_FixedFrameCount()
extern void CinemachineCore_get_FixedFrameCount_m119017A9C55B62668AFD1AE6D209A1E9B21210C8 ();
// 0x00000285 System.Void Cinemachine.CinemachineCore::set_FixedFrameCount(System.Int32)
extern void CinemachineCore_set_FixedFrameCount_m814A0AC94BD3C5FEC3CEB31390AFC79D7F664F6D ();
// 0x00000286 System.Void Cinemachine.CinemachineCore::UpdateAllActiveVirtualCameras(System.Int32,UnityEngine.Vector3,System.Single)
extern void CinemachineCore_UpdateAllActiveVirtualCameras_mCEAF2622091B0DC36A26A844C7C6022BF3C40A51 ();
// 0x00000287 System.Void Cinemachine.CinemachineCore::UpdateVirtualCamera(Cinemachine.CinemachineVirtualCameraBase,UnityEngine.Vector3,System.Single)
extern void CinemachineCore_UpdateVirtualCamera_m937B1B00C50FDEFC1C9AE346DF37A0694D04F9EF ();
// 0x00000288 System.Void Cinemachine.CinemachineCore::InitializeModule()
extern void CinemachineCore_InitializeModule_m9605C793013867D1CCFA4CE04C6673E6665B6F82 ();
// 0x00000289 Cinemachine.CinemachineCore_UpdateFilter Cinemachine.CinemachineCore::get_CurrentUpdateFilter()
extern void CinemachineCore_get_CurrentUpdateFilter_m6FC774F24C226A7BACD909FB796DC1406A5EDCD0 ();
// 0x0000028A System.Void Cinemachine.CinemachineCore::set_CurrentUpdateFilter(Cinemachine.CinemachineCore_UpdateFilter)
extern void CinemachineCore_set_CurrentUpdateFilter_m3E96AD239CF49A028CF514AE0631AA05DE5E3313 ();
// 0x0000028B UnityEngine.Transform Cinemachine.CinemachineCore::GetUpdateTarget(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_GetUpdateTarget_m4BCCFF232B14DEDDAF22E5E526638833FA065094 ();
// 0x0000028C Cinemachine.UpdateTracker_UpdateClock Cinemachine.CinemachineCore::GetVcamUpdateStatus(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_GetVcamUpdateStatus_m2C7C238F785E1F474B1707520007D3AA42129D04 ();
// 0x0000028D System.Boolean Cinemachine.CinemachineCore::IsLive(Cinemachine.ICinemachineCamera)
extern void CinemachineCore_IsLive_m61EC3BE5D22564DD740379A88639BF368EBC1E43 ();
// 0x0000028E System.Void Cinemachine.CinemachineCore::GenerateCameraActivationEvent(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera)
extern void CinemachineCore_GenerateCameraActivationEvent_m851F3990838CAAD976391EECAC4D57B1C61E938A ();
// 0x0000028F System.Void Cinemachine.CinemachineCore::GenerateCameraCutEvent(Cinemachine.ICinemachineCamera)
extern void CinemachineCore_GenerateCameraCutEvent_m38E839FFCA8034AC081D9F99FBEEC15B872F14C6 ();
// 0x00000290 Cinemachine.CinemachineBrain Cinemachine.CinemachineCore::FindPotentialTargetBrain(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_FindPotentialTargetBrain_m5DE059E6EDDE3EF8BD7258655A61A70BD7DA6F77 ();
// 0x00000291 System.Void Cinemachine.CinemachineCore::.ctor()
extern void CinemachineCore__ctor_mC1794CB6B097D4CB15080ECDB82E4F2267C1D712 ();
// 0x00000292 System.Void Cinemachine.CinemachineCore::.cctor()
extern void CinemachineCore__cctor_m5F6647805E2D5EC0C7F1B86D109D21F5D66FEEA7 ();
// 0x00000293 Cinemachine.CinemachineVirtualCameraBase Cinemachine.CinemachineExtension::get_VirtualCamera()
extern void CinemachineExtension_get_VirtualCamera_m48F40B632C12E90C690465B01A667A3748761AF8 ();
// 0x00000294 System.Void Cinemachine.CinemachineExtension::Awake()
extern void CinemachineExtension_Awake_m090793C691718BB30B2C702DC41A2EE51F47BE2E ();
// 0x00000295 System.Void Cinemachine.CinemachineExtension::OnEnable()
extern void CinemachineExtension_OnEnable_m41D46718D51487D5FD1F8C9DF9AB05831CA243A9 ();
// 0x00000296 System.Void Cinemachine.CinemachineExtension::OnDestroy()
extern void CinemachineExtension_OnDestroy_m63D31EE81830209F4127D04ED9C7021C14A13C0C ();
// 0x00000297 System.Void Cinemachine.CinemachineExtension::EnsureStarted()
extern void CinemachineExtension_EnsureStarted_m3F2553CBD100D1FC3E126F2966A6673AEE82771D ();
// 0x00000298 System.Void Cinemachine.CinemachineExtension::ConnectToVcam(System.Boolean)
extern void CinemachineExtension_ConnectToVcam_mB763D1DF3E860D7CF8392A28D47D109E261381B2 ();
// 0x00000299 System.Void Cinemachine.CinemachineExtension::PrePipelineMutateCameraStateCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CameraState&,System.Single)
extern void CinemachineExtension_PrePipelineMutateCameraStateCallback_mA26EFBE159BE7F5A906A1E7229885E49CD4D8D75 ();
// 0x0000029A System.Void Cinemachine.CinemachineExtension::InvokePostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineExtension_InvokePostPipelineStageCallback_m54C975D864B6A6818DE9658ADC23439E45B35F9C ();
// 0x0000029B System.Void Cinemachine.CinemachineExtension::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
// 0x0000029C System.Void Cinemachine.CinemachineExtension::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineExtension_OnTargetObjectWarped_m20FB23984C9395B8BF67744C1ED7832FCAAFDAAF ();
// 0x0000029D System.Void Cinemachine.CinemachineExtension::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineExtension_ForceCameraPosition_m1FD206CC4FBF213FA344D8F059BDE6100FE779FF ();
// 0x0000029E System.Boolean Cinemachine.CinemachineExtension::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineExtension_OnTransitionFromCamera_mBE45BD7A872FF8AC13C1E1EA4B59985FE9A7CD6A ();
// 0x0000029F System.Single Cinemachine.CinemachineExtension::GetMaxDampTime()
extern void CinemachineExtension_GetMaxDampTime_mD88B3216AEF6C76B58EBEF1ABAAC8B9018C47DE8 ();
// 0x000002A0 T Cinemachine.CinemachineExtension::GetExtraState(Cinemachine.ICinemachineCamera)
// 0x000002A1 System.Collections.Generic.List`1<T> Cinemachine.CinemachineExtension::GetAllExtraStates()
// 0x000002A2 System.Void Cinemachine.CinemachineExtension::.ctor()
extern void CinemachineExtension__ctor_m7331AF4105FCAFF48E3CC9A412B1953647E0BEBA ();
// 0x000002A3 System.Void Cinemachine.AxisBase::Validate()
extern void AxisBase_Validate_mEEA2E671C4CE0548BEA394B5598EA51929E7D33A_AdjustorThunk ();
// 0x000002A4 System.Void Cinemachine.CinemachineInputAxisDriver::Validate()
extern void CinemachineInputAxisDriver_Validate_m144628F55B154073CD729EE89A3F87217FC01173_AdjustorThunk ();
// 0x000002A5 System.Boolean Cinemachine.CinemachineInputAxisDriver::Update(System.Single,Cinemachine.AxisBase&)
extern void CinemachineInputAxisDriver_Update_mCF849BA78D16DF068F7723E78D6BC171890AB4CA_AdjustorThunk ();
// 0x000002A6 System.Single Cinemachine.CinemachineInputAxisDriver::ClampValue(Cinemachine.AxisBase&,System.Single)
extern void CinemachineInputAxisDriver_ClampValue_m1C0996D4C9242ACB7615CDE6C7C4BE9D39B341AF_AdjustorThunk ();
// 0x000002A7 System.Boolean Cinemachine.CinemachineInputAxisDriver::Update(System.Single,Cinemachine.AxisState&)
extern void CinemachineInputAxisDriver_Update_mB3570630DFFA0617C1E132A764E902F2848DF810_AdjustorThunk ();
// 0x000002A8 System.Single Cinemachine.CinemachinePathBase::get_MinPos()
// 0x000002A9 System.Single Cinemachine.CinemachinePathBase::get_MaxPos()
// 0x000002AA System.Boolean Cinemachine.CinemachinePathBase::get_Looped()
// 0x000002AB System.Single Cinemachine.CinemachinePathBase::StandardizePos(System.Single)
extern void CinemachinePathBase_StandardizePos_m7B0DB6BC2287BFF4EDD7B5C1351FC1570FD1C00D ();
// 0x000002AC UnityEngine.Vector3 Cinemachine.CinemachinePathBase::EvaluatePosition(System.Single)
// 0x000002AD UnityEngine.Vector3 Cinemachine.CinemachinePathBase::EvaluateTangent(System.Single)
// 0x000002AE UnityEngine.Quaternion Cinemachine.CinemachinePathBase::EvaluateOrientation(System.Single)
// 0x000002AF System.Single Cinemachine.CinemachinePathBase::FindClosestPoint(UnityEngine.Vector3,System.Int32,System.Int32,System.Int32)
extern void CinemachinePathBase_FindClosestPoint_mB3F074A56F3054EA9D9F8B87209D5A12A305BE8E ();
// 0x000002B0 System.Single Cinemachine.CinemachinePathBase::MinUnit(Cinemachine.CinemachinePathBase_PositionUnits)
extern void CinemachinePathBase_MinUnit_mBF5FEF3F3768DD5BEF8790BDBAFD800F42E170FE ();
// 0x000002B1 System.Single Cinemachine.CinemachinePathBase::MaxUnit(Cinemachine.CinemachinePathBase_PositionUnits)
extern void CinemachinePathBase_MaxUnit_m205374FE01FC307D7D7ABDC7432FED2C94561A67 ();
// 0x000002B2 System.Single Cinemachine.CinemachinePathBase::StandardizeUnit(System.Single,Cinemachine.CinemachinePathBase_PositionUnits)
extern void CinemachinePathBase_StandardizeUnit_m4771C500193C929F3F7719A44D5FF8D7E7406B7B ();
// 0x000002B3 UnityEngine.Vector3 Cinemachine.CinemachinePathBase::EvaluatePositionAtUnit(System.Single,Cinemachine.CinemachinePathBase_PositionUnits)
extern void CinemachinePathBase_EvaluatePositionAtUnit_mCC69EFCF35ED5B1210214A96C100E8B809FD5B85 ();
// 0x000002B4 UnityEngine.Vector3 Cinemachine.CinemachinePathBase::EvaluateTangentAtUnit(System.Single,Cinemachine.CinemachinePathBase_PositionUnits)
extern void CinemachinePathBase_EvaluateTangentAtUnit_mFF4C4E5806694670B0281C62E1E598350D574FE7 ();
// 0x000002B5 UnityEngine.Quaternion Cinemachine.CinemachinePathBase::EvaluateOrientationAtUnit(System.Single,Cinemachine.CinemachinePathBase_PositionUnits)
extern void CinemachinePathBase_EvaluateOrientationAtUnit_m78B5F5388A3DD41392F335CA7DB59CA1D8B978F5 ();
// 0x000002B6 System.Int32 Cinemachine.CinemachinePathBase::get_DistanceCacheSampleStepsPerSegment()
// 0x000002B7 System.Void Cinemachine.CinemachinePathBase::InvalidateDistanceCache()
extern void CinemachinePathBase_InvalidateDistanceCache_m630E60D7B6535CD35356161A2C4FE94CBA726C63 ();
// 0x000002B8 System.Boolean Cinemachine.CinemachinePathBase::DistanceCacheIsValid()
extern void CinemachinePathBase_DistanceCacheIsValid_m5B4999C83A60EA0834AB8ACBFBFE298EE5AA6FA9 ();
// 0x000002B9 System.Single Cinemachine.CinemachinePathBase::get_PathLength()
extern void CinemachinePathBase_get_PathLength_m46723487D97919331857A8975C397CB25DAB319D ();
// 0x000002BA System.Single Cinemachine.CinemachinePathBase::StandardizePathDistance(System.Single)
extern void CinemachinePathBase_StandardizePathDistance_mB0DABA55052793902DC03DF700AE54A9A560A3E0 ();
// 0x000002BB System.Single Cinemachine.CinemachinePathBase::ToNativePathUnits(System.Single,Cinemachine.CinemachinePathBase_PositionUnits)
extern void CinemachinePathBase_ToNativePathUnits_mDB615D10D6E1F61AF70B41A508AC8986AE59D683 ();
// 0x000002BC System.Single Cinemachine.CinemachinePathBase::FromPathNativeUnits(System.Single,Cinemachine.CinemachinePathBase_PositionUnits)
extern void CinemachinePathBase_FromPathNativeUnits_m7817218D78BFF77C9F0D52C41B9538E6C6DCF2EB ();
// 0x000002BD System.Void Cinemachine.CinemachinePathBase::ResamplePath(System.Int32)
extern void CinemachinePathBase_ResamplePath_m87F9A39480F5A2EFBC1ACB5361BD8F1F3316FD01 ();
// 0x000002BE System.Void Cinemachine.CinemachinePathBase::.ctor()
extern void CinemachinePathBase__ctor_mA1D4CC9C83F490A407AF3B7EB143BEA58C879EEE ();
// 0x000002BF System.Void Cinemachine.AxisStatePropertyAttribute::.ctor()
extern void AxisStatePropertyAttribute__ctor_mE6EC085C305D367A9C13C5A8F9C71CF740CF31D4 ();
// 0x000002C0 System.Void Cinemachine.OrbitalTransposerHeadingPropertyAttribute::.ctor()
extern void OrbitalTransposerHeadingPropertyAttribute__ctor_mE270F93BA1EA61B3B8D08EEB564E23317ADC7DBA ();
// 0x000002C1 System.Void Cinemachine.LensSettingsPropertyAttribute::.ctor()
extern void LensSettingsPropertyAttribute__ctor_mD29DB77CB5CB59D292D9524BE6909CFAA0554780 ();
// 0x000002C2 System.Void Cinemachine.VcamTargetPropertyAttribute::.ctor()
extern void VcamTargetPropertyAttribute__ctor_m997379231EB2F108F80DC83B01246F4E35D71570 ();
// 0x000002C3 System.Void Cinemachine.CinemachineBlendDefinitionPropertyAttribute::.ctor()
extern void CinemachineBlendDefinitionPropertyAttribute__ctor_mA08F1AA4EB4CEB0759F1C838F8E7D923A12439D7 ();
// 0x000002C4 System.Void Cinemachine.SaveDuringPlayAttribute::.ctor()
extern void SaveDuringPlayAttribute__ctor_m7E6683931B2115F1902B29FCC2B4ED8A166AE4FE ();
// 0x000002C5 System.Void Cinemachine.NoSaveDuringPlayAttribute::.ctor()
extern void NoSaveDuringPlayAttribute__ctor_m999A1E82E9072D6B63A1EE6080F68AFDB15A847B ();
// 0x000002C6 System.Void Cinemachine.TagFieldAttribute::.ctor()
extern void TagFieldAttribute__ctor_m30326F8DBA12F4CB1BE7710455DCFAE79EE3994C ();
// 0x000002C7 System.Void Cinemachine.NoiseSettingsPropertyAttribute::.ctor()
extern void NoiseSettingsPropertyAttribute__ctor_m5C02E6DFB9B65AA11259F8EDF2DA72DFB08DB09F ();
// 0x000002C8 System.Void Cinemachine.CinemachineEmbeddedAssetPropertyAttribute::.ctor(System.Boolean)
extern void CinemachineEmbeddedAssetPropertyAttribute__ctor_mD6C290E553336787289444791FE7FD0E7B57126E ();
// 0x000002C9 Cinemachine.DocumentationSortingAttribute_Level Cinemachine.DocumentationSortingAttribute::get_Category()
extern void DocumentationSortingAttribute_get_Category_mFBDC5B03E1DC7E69766579396C0DE6A5B794B8C1 ();
// 0x000002CA System.Void Cinemachine.DocumentationSortingAttribute::set_Category(Cinemachine.DocumentationSortingAttribute_Level)
extern void DocumentationSortingAttribute_set_Category_mEF229C6814354009B21F2401F708D041751876D8 ();
// 0x000002CB System.Void Cinemachine.DocumentationSortingAttribute::.ctor(Cinemachine.DocumentationSortingAttribute_Level)
extern void DocumentationSortingAttribute__ctor_mC444D8C194E049D0E1A8A4E6F83D7D69938B4CEF ();
// 0x000002CC System.Int32 Cinemachine.CinemachineVirtualCameraBase::get_ValidatingStreamVersion()
extern void CinemachineVirtualCameraBase_get_ValidatingStreamVersion_mAB15E72A5D80AED2EFD0DA0BD8AB00E98030CA73 ();
// 0x000002CD System.Void Cinemachine.CinemachineVirtualCameraBase::set_ValidatingStreamVersion(System.Int32)
extern void CinemachineVirtualCameraBase_set_ValidatingStreamVersion_m5AB3A39B6875CC5C403E49D9FFF6318CD77E6E6D ();
// 0x000002CE System.Single Cinemachine.CinemachineVirtualCameraBase::get_FollowTargetAttachment()
extern void CinemachineVirtualCameraBase_get_FollowTargetAttachment_mC63610049FFE9F70B89E7F310C47253C90363352 ();
// 0x000002CF System.Void Cinemachine.CinemachineVirtualCameraBase::set_FollowTargetAttachment(System.Single)
extern void CinemachineVirtualCameraBase_set_FollowTargetAttachment_m35C90295A253C3071DCF473D134700F3A8F6757C ();
// 0x000002D0 System.Single Cinemachine.CinemachineVirtualCameraBase::get_LookAtTargetAttachment()
extern void CinemachineVirtualCameraBase_get_LookAtTargetAttachment_m54302207ED2A1A7E96A1F9DB52EC0C223754D532 ();
// 0x000002D1 System.Void Cinemachine.CinemachineVirtualCameraBase::set_LookAtTargetAttachment(System.Single)
extern void CinemachineVirtualCameraBase_set_LookAtTargetAttachment_m344BCE5B2905887C117E70412FBE6DF6C704A995 ();
// 0x000002D2 System.Single Cinemachine.CinemachineVirtualCameraBase::GetMaxDampTime()
extern void CinemachineVirtualCameraBase_GetMaxDampTime_m534FD1A5F0E5B1A3F4418266045FEB5CC734C4F3 ();
// 0x000002D3 System.Single Cinemachine.CinemachineVirtualCameraBase::DetachedFollowTargetDamp(System.Single,System.Single,System.Single)
extern void CinemachineVirtualCameraBase_DetachedFollowTargetDamp_mA248235BC7D1A8F9199DFEC135D8770629214BDA ();
// 0x000002D4 UnityEngine.Vector3 Cinemachine.CinemachineVirtualCameraBase::DetachedFollowTargetDamp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_DetachedFollowTargetDamp_mFA07AB4CA8E758190A3AD4D83392619A10E19BEB ();
// 0x000002D5 UnityEngine.Vector3 Cinemachine.CinemachineVirtualCameraBase::DetachedFollowTargetDamp(UnityEngine.Vector3,System.Single,System.Single)
extern void CinemachineVirtualCameraBase_DetachedFollowTargetDamp_m4CE171B4B2D093A57D4DA99688A0BFD8788BDA68 ();
// 0x000002D6 System.Single Cinemachine.CinemachineVirtualCameraBase::DetachedLookAtTargetDamp(System.Single,System.Single,System.Single)
extern void CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_m644A94A63215474706B7D1357D810F4CDF309F0A ();
// 0x000002D7 UnityEngine.Vector3 Cinemachine.CinemachineVirtualCameraBase::DetachedLookAtTargetDamp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_mD2B62A9293DA4E8913ADF89C61A98FE4F966888E ();
// 0x000002D8 UnityEngine.Vector3 Cinemachine.CinemachineVirtualCameraBase::DetachedLookAtTargetDamp(UnityEngine.Vector3,System.Single,System.Single)
extern void CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_m4F4C54F140B29348D732A4155AB228C5C9CB9DBD ();
// 0x000002D9 System.Void Cinemachine.CinemachineVirtualCameraBase::AddExtension(Cinemachine.CinemachineExtension)
extern void CinemachineVirtualCameraBase_AddExtension_m687616F9DD87E599D98CA6595C522C726BE25C91 ();
// 0x000002DA System.Void Cinemachine.CinemachineVirtualCameraBase::RemoveExtension(Cinemachine.CinemachineExtension)
extern void CinemachineVirtualCameraBase_RemoveExtension_m4F693698B2195006C3B65D6634106BC5743298BC ();
// 0x000002DB System.Void Cinemachine.CinemachineVirtualCameraBase::InvokePostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineVirtualCameraBase_InvokePostPipelineStageCallback_mD4F5668E9AB96E8C11F16EC0D3CA769D663F5F51 ();
// 0x000002DC System.Void Cinemachine.CinemachineVirtualCameraBase::InvokePrePipelineMutateCameraStateCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CameraState&,System.Single)
extern void CinemachineVirtualCameraBase_InvokePrePipelineMutateCameraStateCallback_m1C96DE73EEBCA5BB20BF67FAE3201CD2FC528D8C ();
// 0x000002DD System.Boolean Cinemachine.CinemachineVirtualCameraBase::InvokeOnTransitionInExtensions(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_InvokeOnTransitionInExtensions_mB3E9947AB53FC729921300DAA1ACEEE493894846 ();
// 0x000002DE System.String Cinemachine.CinemachineVirtualCameraBase::get_Name()
extern void CinemachineVirtualCameraBase_get_Name_m15C2DEF15C6C85BDEB8AEE64AB915DBE173F0BA0 ();
// 0x000002DF System.String Cinemachine.CinemachineVirtualCameraBase::get_Description()
extern void CinemachineVirtualCameraBase_get_Description_m198BF619FE868398029A2631C8D11C68F553AF63 ();
// 0x000002E0 System.Int32 Cinemachine.CinemachineVirtualCameraBase::get_Priority()
extern void CinemachineVirtualCameraBase_get_Priority_m56656A6C1F3F6EDABE61AC85E1BA8C638B470310 ();
// 0x000002E1 System.Void Cinemachine.CinemachineVirtualCameraBase::set_Priority(System.Int32)
extern void CinemachineVirtualCameraBase_set_Priority_m6C180B742F19E669D648B6D1BE4D9D9C5824962B ();
// 0x000002E2 System.Void Cinemachine.CinemachineVirtualCameraBase::ApplyPositionBlendMethod(Cinemachine.CameraState&,Cinemachine.CinemachineVirtualCameraBase_BlendHint)
extern void CinemachineVirtualCameraBase_ApplyPositionBlendMethod_m4CA02DB42D981721D75169ACDD7900477819EEC0 ();
// 0x000002E3 UnityEngine.GameObject Cinemachine.CinemachineVirtualCameraBase::get_VirtualCameraGameObject()
extern void CinemachineVirtualCameraBase_get_VirtualCameraGameObject_mDE6EBE29EC5093FDCE5E40963BFB8E39F6C7B518 ();
// 0x000002E4 System.Boolean Cinemachine.CinemachineVirtualCameraBase::get_IsValid()
extern void CinemachineVirtualCameraBase_get_IsValid_m4A8B615DDFE153258564AE9D4ED8F257E9C7E5C5 ();
// 0x000002E5 Cinemachine.CameraState Cinemachine.CinemachineVirtualCameraBase::get_State()
// 0x000002E6 Cinemachine.ICinemachineCamera Cinemachine.CinemachineVirtualCameraBase::get_ParentCamera()
extern void CinemachineVirtualCameraBase_get_ParentCamera_mF5286EB2177F8957BC48A0BD3A5815EB408FD60C ();
// 0x000002E7 System.Boolean Cinemachine.CinemachineVirtualCameraBase::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineVirtualCameraBase_IsLiveChild_m1BA561E87306CCFFA9300C53CF38C5940AD1B247 ();
// 0x000002E8 UnityEngine.Transform Cinemachine.CinemachineVirtualCameraBase::get_LookAt()
// 0x000002E9 System.Void Cinemachine.CinemachineVirtualCameraBase::set_LookAt(UnityEngine.Transform)
// 0x000002EA UnityEngine.Transform Cinemachine.CinemachineVirtualCameraBase::get_Follow()
// 0x000002EB System.Void Cinemachine.CinemachineVirtualCameraBase::set_Follow(UnityEngine.Transform)
// 0x000002EC System.Boolean Cinemachine.CinemachineVirtualCameraBase::get_PreviousStateIsValid()
extern void CinemachineVirtualCameraBase_get_PreviousStateIsValid_m9AC6D8672852D072384B03B9433FAA24B6021F35 ();
// 0x000002ED System.Void Cinemachine.CinemachineVirtualCameraBase::set_PreviousStateIsValid(System.Boolean)
extern void CinemachineVirtualCameraBase_set_PreviousStateIsValid_m6B3E5DD2C1EA71B2BA04072A0E3505AAFB2AF008 ();
// 0x000002EE System.Void Cinemachine.CinemachineVirtualCameraBase::UpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_UpdateCameraState_mBCA1562C197A11110116B3909711D0D0EE5F1733 ();
// 0x000002EF System.Void Cinemachine.CinemachineVirtualCameraBase::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
// 0x000002F0 System.Void Cinemachine.CinemachineVirtualCameraBase::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_OnTransitionFromCamera_mF18AFCD175FF50DBA6851279E6C93D0A3625618E ();
// 0x000002F1 System.Void Cinemachine.CinemachineVirtualCameraBase::OnDestroy()
extern void CinemachineVirtualCameraBase_OnDestroy_mFF393A0D56A6468E4A055DC86B52654763CF5C01 ();
// 0x000002F2 System.Void Cinemachine.CinemachineVirtualCameraBase::OnTransformParentChanged()
extern void CinemachineVirtualCameraBase_OnTransformParentChanged_m30B1976A8C859FADD7DBF6508018A382A921A41D ();
// 0x000002F3 System.Void Cinemachine.CinemachineVirtualCameraBase::Start()
extern void CinemachineVirtualCameraBase_Start_mAC4E3C7862E1898426BD04C03F97D2CB65B3E463 ();
// 0x000002F4 System.Void Cinemachine.CinemachineVirtualCameraBase::EnsureStarted()
extern void CinemachineVirtualCameraBase_EnsureStarted_m849F12F97E34D0BB2CFAB2178B5933CB3C07155F ();
// 0x000002F5 Cinemachine.AxisState_IInputAxisProvider Cinemachine.CinemachineVirtualCameraBase::GetInputAxisProvider()
extern void CinemachineVirtualCameraBase_GetInputAxisProvider_m7691338DE9A7FEBB16AE3BC6AD15AC61D2E4D046 ();
// 0x000002F6 System.Void Cinemachine.CinemachineVirtualCameraBase::OnValidate()
extern void CinemachineVirtualCameraBase_OnValidate_mE1DC3F4318A152EE8B1821DE638615477645EF55 ();
// 0x000002F7 System.Void Cinemachine.CinemachineVirtualCameraBase::OnEnable()
extern void CinemachineVirtualCameraBase_OnEnable_m0D02925B2AB25A5F7FB3B032332B70685FCEC035 ();
// 0x000002F8 System.Void Cinemachine.CinemachineVirtualCameraBase::OnDisable()
extern void CinemachineVirtualCameraBase_OnDisable_m385039B02BB5EF010B8F7CD5C8D5FED7BBE7C2D1 ();
// 0x000002F9 System.Void Cinemachine.CinemachineVirtualCameraBase::Update()
extern void CinemachineVirtualCameraBase_Update_m947321B86273A2372CF670BF61DD8763993B63E3 ();
// 0x000002FA System.Void Cinemachine.CinemachineVirtualCameraBase::UpdateSlaveStatus()
extern void CinemachineVirtualCameraBase_UpdateSlaveStatus_m78E02F6B18B2C3FAF666F744FEA33D2357541557 ();
// 0x000002FB UnityEngine.Transform Cinemachine.CinemachineVirtualCameraBase::ResolveLookAt(UnityEngine.Transform)
extern void CinemachineVirtualCameraBase_ResolveLookAt_mB4648E8AB85834A25B30DA49D5A200B74F1CC7A5 ();
// 0x000002FC UnityEngine.Transform Cinemachine.CinemachineVirtualCameraBase::ResolveFollow(UnityEngine.Transform)
extern void CinemachineVirtualCameraBase_ResolveFollow_mC991CC084D6046862E0E0D3172CF7C12FE8EC4F0 ();
// 0x000002FD System.Void Cinemachine.CinemachineVirtualCameraBase::UpdateVcamPoolStatus()
extern void CinemachineVirtualCameraBase_UpdateVcamPoolStatus_m00D7E5F25FC9CC434AD143635F630984354301C9 ();
// 0x000002FE System.Void Cinemachine.CinemachineVirtualCameraBase::MoveToTopOfPrioritySubqueue()
extern void CinemachineVirtualCameraBase_MoveToTopOfPrioritySubqueue_m1C3187B5E5F52FA2D2924CD3443435BCA449B631 ();
// 0x000002FF System.Void Cinemachine.CinemachineVirtualCameraBase::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineVirtualCameraBase_OnTargetObjectWarped_m7FFE5632C56D724943F8663E2A4A4B0E3B958946 ();
// 0x00000300 System.Void Cinemachine.CinemachineVirtualCameraBase::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineVirtualCameraBase_ForceCameraPosition_mBF134754EAD8C7F6DA33A8A52FFD75BEF7C8A31F ();
// 0x00000301 Cinemachine.CinemachineBlend Cinemachine.CinemachineVirtualCameraBase::CreateBlend(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,Cinemachine.CinemachineBlendDefinition,Cinemachine.CinemachineBlend)
extern void CinemachineVirtualCameraBase_CreateBlend_m95B3B2E83C066360A8A238BB5613E979E6369541 ();
// 0x00000302 Cinemachine.CameraState Cinemachine.CinemachineVirtualCameraBase::PullStateFromVirtualCamera(UnityEngine.Vector3,Cinemachine.LensSettings&)
extern void CinemachineVirtualCameraBase_PullStateFromVirtualCamera_m3F65D0956F682ED45F836E6D7950E40EB6C7D84E ();
// 0x00000303 System.Void Cinemachine.CinemachineVirtualCameraBase::.ctor()
extern void CinemachineVirtualCameraBase__ctor_m5B13AF0337DBE27A89CAF6E30FA97CBE38823F84 ();
// 0x00000304 System.String Cinemachine.ICinemachineCamera::get_Name()
// 0x00000305 System.String Cinemachine.ICinemachineCamera::get_Description()
// 0x00000306 System.Int32 Cinemachine.ICinemachineCamera::get_Priority()
// 0x00000307 System.Void Cinemachine.ICinemachineCamera::set_Priority(System.Int32)
// 0x00000308 UnityEngine.Transform Cinemachine.ICinemachineCamera::get_LookAt()
// 0x00000309 System.Void Cinemachine.ICinemachineCamera::set_LookAt(UnityEngine.Transform)
// 0x0000030A UnityEngine.Transform Cinemachine.ICinemachineCamera::get_Follow()
// 0x0000030B System.Void Cinemachine.ICinemachineCamera::set_Follow(UnityEngine.Transform)
// 0x0000030C Cinemachine.CameraState Cinemachine.ICinemachineCamera::get_State()
// 0x0000030D UnityEngine.GameObject Cinemachine.ICinemachineCamera::get_VirtualCameraGameObject()
// 0x0000030E System.Boolean Cinemachine.ICinemachineCamera::get_IsValid()
// 0x0000030F Cinemachine.ICinemachineCamera Cinemachine.ICinemachineCamera::get_ParentCamera()
// 0x00000310 System.Boolean Cinemachine.ICinemachineCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
// 0x00000311 System.Void Cinemachine.ICinemachineCamera::UpdateCameraState(UnityEngine.Vector3,System.Single)
// 0x00000312 System.Void Cinemachine.ICinemachineCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
// 0x00000313 System.Void Cinemachine.ICinemachineCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
// 0x00000314 System.Void Cinemachine.ICinemachineCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
// 0x00000315 System.Boolean Cinemachine.LensSettings::get_Orthographic()
extern void LensSettings_get_Orthographic_mD89E6548BD05054F1ADFF7CB767ADCBA147970A0_AdjustorThunk ();
// 0x00000316 System.Void Cinemachine.LensSettings::set_Orthographic(System.Boolean)
extern void LensSettings_set_Orthographic_m17D40EA48E03E6E1D1FCBC23FCC01599BD7DEC0F_AdjustorThunk ();
// 0x00000317 UnityEngine.Vector2 Cinemachine.LensSettings::get_SensorSize()
extern void LensSettings_get_SensorSize_mED4695A443BA5CD05E9BF20A8B435B9CEAF56F56_AdjustorThunk ();
// 0x00000318 System.Void Cinemachine.LensSettings::set_SensorSize(UnityEngine.Vector2)
extern void LensSettings_set_SensorSize_mCF61646CF243535A7A0FE1C18D187D68F76AA849_AdjustorThunk ();
// 0x00000319 System.Single Cinemachine.LensSettings::get_Aspect()
extern void LensSettings_get_Aspect_m9CC9D04C1503CE0708B7E8D7918D51E6D105CBA6_AdjustorThunk ();
// 0x0000031A System.Boolean Cinemachine.LensSettings::get_IsPhysicalCamera()
extern void LensSettings_get_IsPhysicalCamera_m51B84703CAE764F7D3F7E581D6374080F3065891_AdjustorThunk ();
// 0x0000031B System.Void Cinemachine.LensSettings::set_IsPhysicalCamera(System.Boolean)
extern void LensSettings_set_IsPhysicalCamera_mAD4EF6D6C68EC05EC70CF69FBD4B186BAEEAEE8D_AdjustorThunk ();
// 0x0000031C Cinemachine.LensSettings Cinemachine.LensSettings::FromCamera(UnityEngine.Camera)
extern void LensSettings_FromCamera_mB70878A0FEE612591846D38DEB0C519E62D26062 ();
// 0x0000031D System.Void Cinemachine.LensSettings::SnapshotCameraReadOnlyProperties(UnityEngine.Camera)
extern void LensSettings_SnapshotCameraReadOnlyProperties_mBE8E0F11CA4B7B16A6FB8C6C0EAD3215BD18F952_AdjustorThunk ();
// 0x0000031E System.Void Cinemachine.LensSettings::SnapshotCameraReadOnlyProperties(Cinemachine.LensSettings&)
extern void LensSettings_SnapshotCameraReadOnlyProperties_m1AF99FBBE30EEDEAAFB4F7C6EBC63C4F7BFE0E5D_AdjustorThunk ();
// 0x0000031F System.Void Cinemachine.LensSettings::.ctor(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void LensSettings__ctor_m33701EC0CE3BE15F0CC8BC926D4BB090D59FD206_AdjustorThunk ();
// 0x00000320 Cinemachine.LensSettings Cinemachine.LensSettings::Lerp(Cinemachine.LensSettings,Cinemachine.LensSettings,System.Single)
extern void LensSettings_Lerp_m388C5EBB582A55DC6F8BA3E748270E68752E9582 ();
// 0x00000321 System.Void Cinemachine.LensSettings::Validate()
extern void LensSettings_Validate_mB36D902613DCFA1D4F31A16CDB87FE2AB23570AF_AdjustorThunk ();
// 0x00000322 System.Void Cinemachine.LensSettings::.cctor()
extern void LensSettings__cctor_m83C48E930BB642670AF6DCF8B5600901D03F49F5 ();
// 0x00000323 UnityEngine.Vector3 Cinemachine.NoiseSettings::GetCombinedFilterResults(Cinemachine.NoiseSettings_TransformNoiseParams[],System.Single,UnityEngine.Vector3)
extern void NoiseSettings_GetCombinedFilterResults_m2D89EDF921D81B5476532B768C2099BDCBA047AF ();
// 0x00000324 System.Single Cinemachine.NoiseSettings::get_SignalDuration()
extern void NoiseSettings_get_SignalDuration_mA7535F6F59953F1931926872B12D6FEC56976AAF ();
// 0x00000325 System.Void Cinemachine.NoiseSettings::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void NoiseSettings_GetSignal_m2E1DEBB169108D53CB89571DB973B6AE997B2B96 ();
// 0x00000326 System.Void Cinemachine.NoiseSettings::.ctor()
extern void NoiseSettings__ctor_mFC841D4CF7C2F2B0B0666F32FAF561E8BE089A47 ();
// 0x00000327 System.Void Cinemachine.RuntimeUtility::DestroyObject(UnityEngine.Object)
extern void RuntimeUtility_DestroyObject_m6D1DDFE4299B3873067DC7E57851288F8F78F252 ();
// 0x00000328 System.Boolean Cinemachine.RuntimeUtility::IsPrefab(UnityEngine.GameObject)
extern void RuntimeUtility_IsPrefab_m073F89A3A5B106FD66AB93D1BE52B27612126F5F ();
// 0x00000329 System.Boolean Cinemachine.RuntimeUtility::RaycastIgnoreTag(UnityEngine.Ray,UnityEngine.RaycastHit&,System.Single,System.Int32,System.String&)
extern void RuntimeUtility_RaycastIgnoreTag_m028B24F950C8BC320919E184362FEF37DBE54D90 ();
// 0x0000032A System.Boolean Cinemachine.RuntimeUtility::SphereCastIgnoreTag(UnityEngine.Vector3,System.Single,UnityEngine.Vector3,UnityEngine.RaycastHit&,System.Single,System.Int32,System.String&)
extern void RuntimeUtility_SphereCastIgnoreTag_mF63BBA794BD68DF691D1EC863B2CA138CECA6D64 ();
// 0x0000032B System.Single Cinemachine.ISignalSource6D::get_SignalDuration()
// 0x0000032C System.Void Cinemachine.ISignalSource6D::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
// 0x0000032D System.Single Cinemachine.SignalSourceAsset::get_SignalDuration()
// 0x0000032E System.Void Cinemachine.SignalSourceAsset::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
// 0x0000032F System.Void Cinemachine.SignalSourceAsset::.ctor()
extern void SignalSourceAsset__ctor_m6BD0FCB4BC617B1339DD54AF64C68D73217F15C4 ();
// 0x00000330 System.Boolean Cinemachine.TargetPositionCache::get_UseCache()
extern void TargetPositionCache_get_UseCache_m2A4E7042538DD9DB3384B1F655C2F5F241287ED3 ();
// 0x00000331 System.Void Cinemachine.TargetPositionCache::set_UseCache(System.Boolean)
extern void TargetPositionCache_set_UseCache_mE9841EC91604F0D0249732E8AD668C59D46BE7E9 ();
// 0x00000332 Cinemachine.TargetPositionCache_Mode Cinemachine.TargetPositionCache::get_CacheMode()
extern void TargetPositionCache_get_CacheMode_mC4847BC1073AF20F9206798A04F0AAEB7675EF2D ();
// 0x00000333 System.Void Cinemachine.TargetPositionCache::set_CacheMode(Cinemachine.TargetPositionCache_Mode)
extern void TargetPositionCache_set_CacheMode_mA409087DB626DAE734E50B8F32E458AF8586A819 ();
// 0x00000334 System.Boolean Cinemachine.TargetPositionCache::get_IsRecording()
extern void TargetPositionCache_get_IsRecording_m0E103654E5042F7C81BF3E8F6683767490885F63 ();
// 0x00000335 System.Boolean Cinemachine.TargetPositionCache::get_CurrentPlaybackTimeValid()
extern void TargetPositionCache_get_CurrentPlaybackTimeValid_m52161DB6E5E14903123C1C92B14D48228165B646 ();
// 0x00000336 System.Boolean Cinemachine.TargetPositionCache::get_IsEmpty()
extern void TargetPositionCache_get_IsEmpty_m05036B2EE99C645BC889DF7A34BB38CD9F701F17 ();
// 0x00000337 System.Single Cinemachine.TargetPositionCache::get_CurrentTime()
extern void TargetPositionCache_get_CurrentTime_m3F5821119AECD4EC85404EAD43A2165DBC2637C5 ();
// 0x00000338 System.Void Cinemachine.TargetPositionCache::set_CurrentTime(System.Single)
extern void TargetPositionCache_set_CurrentTime_mA19CF3213984B76FA56B4E05C67CFA4C38665383 ();
// 0x00000339 System.Int32 Cinemachine.TargetPositionCache::get_CurrentFrame()
extern void TargetPositionCache_get_CurrentFrame_m2319ECEB0B10124D15B040B2990DB4ACA50BB07C ();
// 0x0000033A System.Void Cinemachine.TargetPositionCache::set_CurrentFrame(System.Int32)
extern void TargetPositionCache_set_CurrentFrame_m989E6580A4D827FE06BCB7F5819794C116E4D584 ();
// 0x0000033B System.Boolean Cinemachine.TargetPositionCache::get_IsCameraCut()
extern void TargetPositionCache_get_IsCameraCut_mD135E2C327DC1F9AB5D41DD29F50C60020788DA2 ();
// 0x0000033C System.Void Cinemachine.TargetPositionCache::set_IsCameraCut(System.Boolean)
extern void TargetPositionCache_set_IsCameraCut_m129E28E786C665E5DE495E5D1BC511A46CB30ABF ();
// 0x0000033D Cinemachine.TargetPositionCache_TimeRange Cinemachine.TargetPositionCache::get_CacheTimeRange()
extern void TargetPositionCache_get_CacheTimeRange_m26A353A12C7452C99C2FEF71809C25914C78529E ();
// 0x0000033E System.Boolean Cinemachine.TargetPositionCache::get_HasHurrentTime()
extern void TargetPositionCache_get_HasHurrentTime_mD38DDBFB10FC5D0FB648E927AA8B3F2434DC547E ();
// 0x0000033F System.Void Cinemachine.TargetPositionCache::ClearCache()
extern void TargetPositionCache_ClearCache_mEAEE54E7ACFE79BB323DFA679789206770BE11ED ();
// 0x00000340 System.Void Cinemachine.TargetPositionCache::CreatePlaybackCurves()
extern void TargetPositionCache_CreatePlaybackCurves_m335FD074A23437FF0DDE3C70BED8EDAC5FFD8BA7 ();
// 0x00000341 UnityEngine.Vector3 Cinemachine.TargetPositionCache::GetTargetPosition(UnityEngine.Transform)
extern void TargetPositionCache_GetTargetPosition_m683592ADC5C5B6597CE3A781E1BBE89A1AC9CBB1 ();
// 0x00000342 UnityEngine.Quaternion Cinemachine.TargetPositionCache::GetTargetRotation(UnityEngine.Transform)
extern void TargetPositionCache_GetTargetRotation_mBAA85634FCB43634065191EB1F2217462334679D ();
// 0x00000343 System.Void Cinemachine.TargetPositionCache::.ctor()
extern void TargetPositionCache__ctor_m0173991EBB133E2CDEF09D3C495FC3CE14ECE9C1 ();
// 0x00000344 System.Void Cinemachine.TargetPositionCache::.cctor()
extern void TargetPositionCache__cctor_mF31DF1BD5AFDB4275E7FC81F08D3A03B1EDF3FC1 ();
// 0x00000345 System.Void Cinemachine.UpdateTracker::InitializeModule()
extern void UpdateTracker_InitializeModule_m5370F8DEE455815F90E3D955CE59DB9913D08E8F ();
// 0x00000346 System.Void Cinemachine.UpdateTracker::UpdateTargets(Cinemachine.UpdateTracker_UpdateClock)
extern void UpdateTracker_UpdateTargets_mD0D8D76B9072DEA87E45FE9A440CF8324C93DEE0 ();
// 0x00000347 Cinemachine.UpdateTracker_UpdateClock Cinemachine.UpdateTracker::GetPreferredUpdate(UnityEngine.Transform)
extern void UpdateTracker_GetPreferredUpdate_m9C3AD495B5ABFE52C7FF420870F93315B9E85219 ();
// 0x00000348 System.Void Cinemachine.UpdateTracker::OnUpdate(Cinemachine.UpdateTracker_UpdateClock)
extern void UpdateTracker_OnUpdate_m5F262770C3B9222F8503D50DFE21FF7C9A902C41 ();
// 0x00000349 System.Void Cinemachine.UpdateTracker::.ctor()
extern void UpdateTracker__ctor_m96110261C2684D9D4FF348FDC8C2C9ADA9107C56 ();
// 0x0000034A System.Void Cinemachine.UpdateTracker::.cctor()
extern void UpdateTracker__cctor_mED7C5FD366A149F1208622A2F59654F6713B1E65 ();
// 0x0000034B System.Void Cinemachine.CinemachineInputProvider::.ctor()
extern void CinemachineInputProvider__ctor_m8777E62CF2666361F27D23EBB1C9DCEFA089DC4D ();
// 0x0000034C System.Boolean Cinemachine.CinemachineTriggerAction::Filter(UnityEngine.GameObject)
extern void CinemachineTriggerAction_Filter_m24E0C2EA06B01EDE65C5ABCF0FF7412C15FBA2C9 ();
// 0x0000034D System.Void Cinemachine.CinemachineTriggerAction::InternalDoTriggerEnter(UnityEngine.GameObject)
extern void CinemachineTriggerAction_InternalDoTriggerEnter_mB3988F520BC8AA59D9234D2ADF740F0B042CF468 ();
// 0x0000034E System.Void Cinemachine.CinemachineTriggerAction::InternalDoTriggerExit(UnityEngine.GameObject)
extern void CinemachineTriggerAction_InternalDoTriggerExit_mCD95F85A77DEA5ADA44117BB83D060759735B673 ();
// 0x0000034F System.Void Cinemachine.CinemachineTriggerAction::OnTriggerEnter(UnityEngine.Collider)
extern void CinemachineTriggerAction_OnTriggerEnter_m96928EE1C51134E6F263AF38DF3F935B6AE9B437 ();
// 0x00000350 System.Void Cinemachine.CinemachineTriggerAction::OnTriggerExit(UnityEngine.Collider)
extern void CinemachineTriggerAction_OnTriggerExit_m064EAE63E912234D6C9FEBD36C93B365E7C254A7 ();
// 0x00000351 System.Void Cinemachine.CinemachineTriggerAction::OnCollisionEnter(UnityEngine.Collision)
extern void CinemachineTriggerAction_OnCollisionEnter_m30F4858ADE6F9AE24968B6C4B53003A64C649EFB ();
// 0x00000352 System.Void Cinemachine.CinemachineTriggerAction::OnCollisionExit(UnityEngine.Collision)
extern void CinemachineTriggerAction_OnCollisionExit_m14FC07565358A5C444DC58DEDF873F9EAB166B68 ();
// 0x00000353 System.Void Cinemachine.CinemachineTriggerAction::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void CinemachineTriggerAction_OnTriggerEnter2D_m761334328569C317AF12D5DC97F15FB754433A75 ();
// 0x00000354 System.Void Cinemachine.CinemachineTriggerAction::OnTriggerExit2D(UnityEngine.Collider2D)
extern void CinemachineTriggerAction_OnTriggerExit2D_mC612B5BBC49A435C39F90DA58E87C48996A21087 ();
// 0x00000355 System.Void Cinemachine.CinemachineTriggerAction::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void CinemachineTriggerAction_OnCollisionEnter2D_m1102D331D5FCC51055E4AC4CC6B36BE4966ADB52 ();
// 0x00000356 System.Void Cinemachine.CinemachineTriggerAction::OnCollisionExit2D(UnityEngine.Collision2D)
extern void CinemachineTriggerAction_OnCollisionExit2D_m0BF8AFA822490D1DC0E3720DA83D12AC8A34FE90 ();
// 0x00000357 System.Void Cinemachine.CinemachineTriggerAction::OnEnable()
extern void CinemachineTriggerAction_OnEnable_m79D396A5F205F320779F5A574F809E5CCA823EA0 ();
// 0x00000358 System.Void Cinemachine.CinemachineTriggerAction::.ctor()
extern void CinemachineTriggerAction__ctor_m51FC885E516BEAA36487E1C69FC60915A4499FB8 ();
// 0x00000359 System.Void Cinemachine.GroupWeightManipulator::Start()
extern void GroupWeightManipulator_Start_m75C9527F322AAB1342866F0E3C9A95A47CD3ADD8 ();
// 0x0000035A System.Void Cinemachine.GroupWeightManipulator::OnValidate()
extern void GroupWeightManipulator_OnValidate_m03475E611BFE066FB8D68DF536E590D7A898986D ();
// 0x0000035B System.Void Cinemachine.GroupWeightManipulator::Update()
extern void GroupWeightManipulator_Update_mF97C2AA28515F222056573441CA7323BCA2A4263 ();
// 0x0000035C System.Void Cinemachine.GroupWeightManipulator::UpdateWeights()
extern void GroupWeightManipulator_UpdateWeights_m7AD8CE24D796B0B7DBEC5B8CE80EF22791216939 ();
// 0x0000035D System.Void Cinemachine.GroupWeightManipulator::.ctor()
extern void GroupWeightManipulator__ctor_mB7E3E90299CFB064DFC0735B0D3A95F756B520DB ();
// 0x0000035E System.Void Cinemachine.CinemachineCollisionImpulseSource::Start()
extern void CinemachineCollisionImpulseSource_Start_m5E5E851F56BBEB52056D04A8BAA9A09628D648E9 ();
// 0x0000035F System.Void Cinemachine.CinemachineCollisionImpulseSource::OnEnable()
extern void CinemachineCollisionImpulseSource_OnEnable_m96262CAFC11EEA2C8E93D1C5C43550EBBBD5F5F5 ();
// 0x00000360 System.Void Cinemachine.CinemachineCollisionImpulseSource::OnCollisionEnter(UnityEngine.Collision)
extern void CinemachineCollisionImpulseSource_OnCollisionEnter_m83A9DF31C999E8DADB0ECC1785811FE9E13DF31F ();
// 0x00000361 System.Void Cinemachine.CinemachineCollisionImpulseSource::OnTriggerEnter(UnityEngine.Collider)
extern void CinemachineCollisionImpulseSource_OnTriggerEnter_mF2DE5CAE0F47A55DBD93891E8BE3878CD2EC13C6 ();
// 0x00000362 System.Single Cinemachine.CinemachineCollisionImpulseSource::GetMassAndVelocity(UnityEngine.Collider,UnityEngine.Vector3&)
extern void CinemachineCollisionImpulseSource_GetMassAndVelocity_mB95B2A247A38FC23502BFCE4ACBECBB8E6D5478B ();
// 0x00000363 System.Void Cinemachine.CinemachineCollisionImpulseSource::GenerateImpactEvent(UnityEngine.Collider,UnityEngine.Vector3)
extern void CinemachineCollisionImpulseSource_GenerateImpactEvent_m02923185427CABBF74C0E310B6631551881B084D ();
// 0x00000364 System.Void Cinemachine.CinemachineCollisionImpulseSource::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void CinemachineCollisionImpulseSource_OnCollisionEnter2D_m3EA8BBA135D81259C8F0C98CB504F61E86A1FCED ();
// 0x00000365 System.Void Cinemachine.CinemachineCollisionImpulseSource::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void CinemachineCollisionImpulseSource_OnTriggerEnter2D_m128B0315FD9184DC00A136E4C24A19C6D3305FE3 ();
// 0x00000366 System.Single Cinemachine.CinemachineCollisionImpulseSource::GetMassAndVelocity2D(UnityEngine.Collider2D,UnityEngine.Vector3&)
extern void CinemachineCollisionImpulseSource_GetMassAndVelocity2D_mD290AA11EAE21CDD0B3743B070AD3B1C630DC2C7 ();
// 0x00000367 System.Void Cinemachine.CinemachineCollisionImpulseSource::GenerateImpactEvent2D(UnityEngine.Collider2D,UnityEngine.Vector3)
extern void CinemachineCollisionImpulseSource_GenerateImpactEvent2D_m7054A182B1B724BFD0BBB6F3867466449495A5A0 ();
// 0x00000368 System.Void Cinemachine.CinemachineCollisionImpulseSource::.ctor()
extern void CinemachineCollisionImpulseSource__ctor_m52C884476834730DD21BA513FFE95FAF03A1EE72 ();
// 0x00000369 System.Single Cinemachine.CinemachineFixedSignal::get_SignalDuration()
extern void CinemachineFixedSignal_get_SignalDuration_m45BF3B9C17DCD224D52644987797EF5AD3F2B335 ();
// 0x0000036A System.Single Cinemachine.CinemachineFixedSignal::AxisDuration(UnityEngine.AnimationCurve)
extern void CinemachineFixedSignal_AxisDuration_m722605DBBFEB163DC9787AD18CD8F7920121B0DC ();
// 0x0000036B System.Void Cinemachine.CinemachineFixedSignal::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void CinemachineFixedSignal_GetSignal_m92E661706E11B9D9C231CE543903182387B01FA2 ();
// 0x0000036C System.Single Cinemachine.CinemachineFixedSignal::AxisValue(UnityEngine.AnimationCurve,System.Single)
extern void CinemachineFixedSignal_AxisValue_mADA40BCB50D24AFA3B306B3C21759DB00CB4116C ();
// 0x0000036D System.Void Cinemachine.CinemachineFixedSignal::.ctor()
extern void CinemachineFixedSignal__ctor_mBF0542616A9718A1756FDCC01BB94235B9DEE404 ();
// 0x0000036E System.Void Cinemachine.CinemachineImpulseDefinitionPropertyAttribute::.ctor()
extern void CinemachineImpulseDefinitionPropertyAttribute__ctor_mF66F03AD5A4EB4ECA78856EEAEE26142F522E1D1 ();
// 0x0000036F System.Void Cinemachine.CinemachineImpulseDefinition::OnValidate()
extern void CinemachineImpulseDefinition_OnValidate_mFA3F1DA4B88CBB26F7529483BAB1AFB7D1ACA39E ();
// 0x00000370 System.Void Cinemachine.CinemachineImpulseDefinition::CreateEvent(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineImpulseDefinition_CreateEvent_m4321107CAE385B5FB027FBFF5DD5B7D5B034C783 ();
// 0x00000371 Cinemachine.CinemachineImpulseManager_ImpulseEvent Cinemachine.CinemachineImpulseDefinition::CreateAndReturnEvent(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineImpulseDefinition_CreateAndReturnEvent_mA242BCF220FF29B7BD481ECFD63485A8AE5F8220 ();
// 0x00000372 System.Void Cinemachine.CinemachineImpulseDefinition::.ctor()
extern void CinemachineImpulseDefinition__ctor_mD30405D1F3CE7A681B0907945FB88F845C2FED85 ();
// 0x00000373 System.Void Cinemachine.CinemachineImpulseListener::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineImpulseListener_PostPipelineStageCallback_m5DB0EB79B863014AEA4AD493E8989EB789B83119 ();
// 0x00000374 System.Void Cinemachine.CinemachineImpulseListener::.ctor()
extern void CinemachineImpulseListener__ctor_m4D00191CF14DEA2304345E89ABF693D06026AF33 ();
// 0x00000375 System.Void Cinemachine.CinemachineImpulseEnvelopePropertyAttribute::.ctor()
extern void CinemachineImpulseEnvelopePropertyAttribute__ctor_m102C22E2CEE8BF51F3C95D3C751035320B1C8574 ();
// 0x00000376 System.Void Cinemachine.CinemachineImpulseChannelPropertyAttribute::.ctor()
extern void CinemachineImpulseChannelPropertyAttribute__ctor_mB2115A1DF97474375A0EF9E96301CF5273149443 ();
// 0x00000377 System.Void Cinemachine.CinemachineImpulseManager::.ctor()
extern void CinemachineImpulseManager__ctor_m00612FBC540CE6AACDFECE7943168B27C2A3848F ();
// 0x00000378 Cinemachine.CinemachineImpulseManager Cinemachine.CinemachineImpulseManager::get_Instance()
extern void CinemachineImpulseManager_get_Instance_m2610081DC5D98082D240CE3FD7C6C6CEAE571DE4 ();
// 0x00000379 System.Boolean Cinemachine.CinemachineImpulseManager::GetImpulseAt(UnityEngine.Vector3,System.Boolean,System.Int32,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void CinemachineImpulseManager_GetImpulseAt_mD63748BEEF92691CD8962594BC86D8AACC6908D6 ();
// 0x0000037A System.Boolean Cinemachine.CinemachineImpulseManager::get_IgnoreTimeScale()
extern void CinemachineImpulseManager_get_IgnoreTimeScale_m7286B8E9A54BE18D4D002F7824057EF9B4A6F581 ();
// 0x0000037B System.Void Cinemachine.CinemachineImpulseManager::set_IgnoreTimeScale(System.Boolean)
extern void CinemachineImpulseManager_set_IgnoreTimeScale_m734F8037EA5DDBAFEFE2AE02FE1AC87AD5FD333F ();
// 0x0000037C System.Single Cinemachine.CinemachineImpulseManager::get_CurrentTime()
extern void CinemachineImpulseManager_get_CurrentTime_mE6D6E38260F7F6CA352A44825C905F3CABC331ED ();
// 0x0000037D Cinemachine.CinemachineImpulseManager_ImpulseEvent Cinemachine.CinemachineImpulseManager::NewImpulseEvent()
extern void CinemachineImpulseManager_NewImpulseEvent_mF579A9519CE81229E765EFF552B4556FE8625198 ();
// 0x0000037E System.Void Cinemachine.CinemachineImpulseManager::AddImpulseEvent(Cinemachine.CinemachineImpulseManager_ImpulseEvent)
extern void CinemachineImpulseManager_AddImpulseEvent_m3C54AC87600E365FB98F0A8D43B6A1A0F96EA3C7 ();
// 0x0000037F System.Void Cinemachine.CinemachineImpulseManager::Clear()
extern void CinemachineImpulseManager_Clear_mA812D41CE685AADD048C6257BBC2EF82F0022F13 ();
// 0x00000380 System.Void Cinemachine.CinemachineImpulseManager::.cctor()
extern void CinemachineImpulseManager__cctor_mA7E7C7140C2AF2C42811EC72E2B137314E583114 ();
// 0x00000381 System.Void Cinemachine.CinemachineImpulseSource::OnValidate()
extern void CinemachineImpulseSource_OnValidate_m83C3BD911B9348F88DC2AE85D1DB974A8E10979D ();
// 0x00000382 System.Void Cinemachine.CinemachineImpulseSource::GenerateImpulseAt(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineImpulseSource_GenerateImpulseAt_m0A99A6E18F64EB89296877D1A6816D72CB58CA3B ();
// 0x00000383 System.Void Cinemachine.CinemachineImpulseSource::GenerateImpulse(UnityEngine.Vector3)
extern void CinemachineImpulseSource_GenerateImpulse_mA0BA98729D31DAA4489F8A795460312C6AC987A0 ();
// 0x00000384 System.Void Cinemachine.CinemachineImpulseSource::GenerateImpulse(System.Single)
extern void CinemachineImpulseSource_GenerateImpulse_m2F8A5B9B2CB9F5A1F7E76D2034B8F6BBED59C083 ();
// 0x00000385 System.Void Cinemachine.CinemachineImpulseSource::GenerateImpulse()
extern void CinemachineImpulseSource_GenerateImpulse_mED2BDD40C547E077E1DF815B796F382D4354F7FC ();
// 0x00000386 System.Void Cinemachine.CinemachineImpulseSource::.ctor()
extern void CinemachineImpulseSource__ctor_m9E80ACB84814DB64C13AD8DA4FEDAF89664D081D ();
// 0x00000387 System.Void Cinemachine.CinemachineIndependentImpulseListener::Reset()
extern void CinemachineIndependentImpulseListener_Reset_mBCDD4E8A955637C2F86F03E77FD60522366EEF47 ();
// 0x00000388 System.Void Cinemachine.CinemachineIndependentImpulseListener::OnEnable()
extern void CinemachineIndependentImpulseListener_OnEnable_mB2F604C65010D97C7B9B49DE3EEEC2B2DD20595B ();
// 0x00000389 System.Void Cinemachine.CinemachineIndependentImpulseListener::Update()
extern void CinemachineIndependentImpulseListener_Update_mD29D193527AEFA832942DED9837FB503532A698F ();
// 0x0000038A System.Void Cinemachine.CinemachineIndependentImpulseListener::LateUpdate()
extern void CinemachineIndependentImpulseListener_LateUpdate_m1F8FA46BB2ABFD4EE0502A5D1A30B70E31B16971 ();
// 0x0000038B System.Void Cinemachine.CinemachineIndependentImpulseListener::.ctor()
extern void CinemachineIndependentImpulseListener__ctor_m58D3A75F484AEBA326E4631720198ED751049A38 ();
// 0x0000038C System.Void Cinemachine.PostFX.CinemachinePostProcessing::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore_Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachinePostProcessing_PostPipelineStageCallback_mBB56E45B7D4BBEAE04A420C99A3341E0EF7D1C24 ();
// 0x0000038D System.Void Cinemachine.PostFX.CinemachinePostProcessing::.ctor()
extern void CinemachinePostProcessing__ctor_m036C1F22C14AB44191F6715C831A6A10C39C64BF ();
// 0x0000038E System.Void Cinemachine.PostFX.CinemachineVolumeSettings::.ctor()
extern void CinemachineVolumeSettings__ctor_m62731AF7317EE4CE5CB2E4E624DCDE9D69EF7B06 ();
// 0x0000038F System.Void Cinemachine.Utility.CinemachineDebug::ReleaseScreenPos(UnityEngine.Object)
extern void CinemachineDebug_ReleaseScreenPos_mB86CBB15358DB61F1EE1FB14B1A75C22DF973EC1 ();
// 0x00000390 UnityEngine.Rect Cinemachine.Utility.CinemachineDebug::GetScreenPos(UnityEngine.Object,System.String,UnityEngine.GUIStyle)
extern void CinemachineDebug_GetScreenPos_mDB9E3E780C465A8773B43312A6316F11789F31DB ();
// 0x00000391 System.Text.StringBuilder Cinemachine.Utility.CinemachineDebug::SBFromPool()
extern void CinemachineDebug_SBFromPool_mB6C8A1699C089516D0C30DB54FACEA9DE7BEBEE1 ();
// 0x00000392 System.Void Cinemachine.Utility.CinemachineDebug::ReturnToPool(System.Text.StringBuilder)
extern void CinemachineDebug_ReturnToPool_mC5B15ABF0A1EAA33217EA6B204901D2817442704 ();
// 0x00000393 System.Void Cinemachine.Utility.CinemachineDebug::.ctor()
extern void CinemachineDebug__ctor_m34EA5A3E30773372406A3EFEFEAC4D512FBC53D1 ();
// 0x00000394 System.Single Cinemachine.Utility.GaussianWindow1d`1::get_Sigma()
// 0x00000395 System.Void Cinemachine.Utility.GaussianWindow1d`1::set_Sigma(System.Single)
// 0x00000396 System.Int32 Cinemachine.Utility.GaussianWindow1d`1::get_KernelSize()
// 0x00000397 System.Void Cinemachine.Utility.GaussianWindow1d`1::GenerateKernel(System.Single,System.Int32)
// 0x00000398 T Cinemachine.Utility.GaussianWindow1d`1::Compute(System.Int32)
// 0x00000399 System.Void Cinemachine.Utility.GaussianWindow1d`1::.ctor(System.Single,System.Int32)
// 0x0000039A System.Void Cinemachine.Utility.GaussianWindow1d`1::Reset()
// 0x0000039B System.Boolean Cinemachine.Utility.GaussianWindow1d`1::IsEmpty()
// 0x0000039C System.Void Cinemachine.Utility.GaussianWindow1d`1::AddValue(T)
// 0x0000039D T Cinemachine.Utility.GaussianWindow1d`1::Filter(T)
// 0x0000039E T Cinemachine.Utility.GaussianWindow1d`1::Value()
// 0x0000039F System.Int32 Cinemachine.Utility.GaussianWindow1d`1::get_BufferLength()
// 0x000003A0 System.Void Cinemachine.Utility.GaussianWindow1d`1::SetBufferValue(System.Int32,T)
// 0x000003A1 T Cinemachine.Utility.GaussianWindow1d`1::GetBufferValue(System.Int32)
// 0x000003A2 System.Void Cinemachine.Utility.GaussianWindow1D_Vector3::.ctor(System.Single,System.Int32)
extern void GaussianWindow1D_Vector3__ctor_m9F9F4D1099F38C2011F89481C3942BCF837A8C8F ();
// 0x000003A3 UnityEngine.Vector3 Cinemachine.Utility.GaussianWindow1D_Vector3::Compute(System.Int32)
extern void GaussianWindow1D_Vector3_Compute_mC47257358568DEC6D1F06A2736F9FFE72840155A ();
// 0x000003A4 System.Void Cinemachine.Utility.GaussianWindow1D_Quaternion::.ctor(System.Single,System.Int32)
extern void GaussianWindow1D_Quaternion__ctor_m42734F192A050DB0229809115A08EB5B2ACFE2B8 ();
// 0x000003A5 UnityEngine.Quaternion Cinemachine.Utility.GaussianWindow1D_Quaternion::Compute(System.Int32)
extern void GaussianWindow1D_Quaternion_Compute_m0E7848F46F6D124039571EC9E16E07F969B5A98D ();
// 0x000003A6 System.Void Cinemachine.Utility.GaussianWindow1D_CameraRotation::.ctor(System.Single,System.Int32)
extern void GaussianWindow1D_CameraRotation__ctor_m4834B72F86867A703ECCA581EA7B7D1636BAA6ED ();
// 0x000003A7 UnityEngine.Vector2 Cinemachine.Utility.GaussianWindow1D_CameraRotation::Compute(System.Int32)
extern void GaussianWindow1D_CameraRotation_Compute_mB07D3BAA51B60DCF8DCF738916D4A8F25D2851C4 ();
// 0x000003A8 System.Single Cinemachine.Utility.PositionPredictor::get_Smoothing()
extern void PositionPredictor_get_Smoothing_mB2305254F86ADC44F77B967664A836A1E523903E ();
// 0x000003A9 System.Void Cinemachine.Utility.PositionPredictor::set_Smoothing(System.Single)
extern void PositionPredictor_set_Smoothing_m4882C9C588E241A637B9E16A372B03DFD486EBB1 ();
// 0x000003AA System.Boolean Cinemachine.Utility.PositionPredictor::IsEmpty()
extern void PositionPredictor_IsEmpty_mA2B45EC05F649C5F9720C228BFED71E8AD5F62B5 ();
// 0x000003AB System.Void Cinemachine.Utility.PositionPredictor::ApplyTransformDelta(UnityEngine.Vector3)
extern void PositionPredictor_ApplyTransformDelta_m77976FB10046478DA8110E153218CB9AE00132A1 ();
// 0x000003AC System.Void Cinemachine.Utility.PositionPredictor::Reset()
extern void PositionPredictor_Reset_mB44898FC7B8E9B0A7F683840935E9BA00E699ADC ();
// 0x000003AD System.Void Cinemachine.Utility.PositionPredictor::AddPosition(UnityEngine.Vector3,System.Single,System.Single)
extern void PositionPredictor_AddPosition_m1E539B2DB83AD523581841BF1D302643CE9275B3 ();
// 0x000003AE UnityEngine.Vector3 Cinemachine.Utility.PositionPredictor::PredictPositionDelta(System.Single)
extern void PositionPredictor_PredictPositionDelta_m19C414F8AFAFC691F2FA995D77B0C694E8EDADDD ();
// 0x000003AF UnityEngine.Vector3 Cinemachine.Utility.PositionPredictor::PredictPosition(System.Single)
extern void PositionPredictor_PredictPosition_mCD92F4061A05A405E45399C22D8E68E9DCA739B8 ();
// 0x000003B0 System.Void Cinemachine.Utility.PositionPredictor::.ctor()
extern void PositionPredictor__ctor_m4D6A0B4370D8836CEF0C54F233EE351EE2A8AEFA ();
// 0x000003B1 System.Single Cinemachine.Utility.Damper::DecayConstant(System.Single,System.Single)
extern void Damper_DecayConstant_m90B73FBD9EFDFDADD53456DFBA5DC3FBD2A250B4 ();
// 0x000003B2 System.Single Cinemachine.Utility.Damper::DecayedRemainder(System.Single,System.Single,System.Single)
extern void Damper_DecayedRemainder_mA1A4A25180833287B1EB3305763101321F042E46 ();
// 0x000003B3 System.Single Cinemachine.Utility.Damper::Damp(System.Single,System.Single,System.Single)
extern void Damper_Damp_mA12020431103076AB69C0FC03C4C07B388AD9E27 ();
// 0x000003B4 UnityEngine.Vector3 Cinemachine.Utility.Damper::Damp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void Damper_Damp_m62C13BEDD585C7DE73B4BDFBC28DDA00C4F89EEE ();
// 0x000003B5 UnityEngine.Vector3 Cinemachine.Utility.Damper::Damp(UnityEngine.Vector3,System.Single,System.Single)
extern void Damper_Damp_m5F27E39708AA38EF9CC7D888B6F3681813C0E6F0 ();
// 0x000003B6 System.Void Cinemachine.Utility.HeadingTracker::.ctor(System.Int32)
extern void HeadingTracker__ctor_mF6B909E191467A5BD7D4B982E751ADA11C4608D3 ();
// 0x000003B7 System.Int32 Cinemachine.Utility.HeadingTracker::get_FilterSize()
extern void HeadingTracker_get_FilterSize_mC9A740BF0831E766A9425F01A72681EF912D08E8 ();
// 0x000003B8 System.Void Cinemachine.Utility.HeadingTracker::ClearHistory()
extern void HeadingTracker_ClearHistory_mDE5209EB31B87840F52B0407996951E343711389 ();
// 0x000003B9 System.Single Cinemachine.Utility.HeadingTracker::Decay(System.Single)
extern void HeadingTracker_Decay_mFC85AA39B403F52067DDECD6C488EFCBB7F38BE9 ();
// 0x000003BA System.Void Cinemachine.Utility.HeadingTracker::Add(UnityEngine.Vector3)
extern void HeadingTracker_Add_m1895E709261177B40C99111534D777A3E484D517 ();
// 0x000003BB System.Void Cinemachine.Utility.HeadingTracker::PopBottom()
extern void HeadingTracker_PopBottom_m22630D7ACBCF2197BD86E73F987CF15812A1D2B5 ();
// 0x000003BC System.Void Cinemachine.Utility.HeadingTracker::DecayHistory()
extern void HeadingTracker_DecayHistory_m192F30AA8475481505746C3ACE672088F9D76DBB ();
// 0x000003BD UnityEngine.Vector3 Cinemachine.Utility.HeadingTracker::GetReliableHeading()
extern void HeadingTracker_GetReliableHeading_m14DC7D8BBE3912362DF154EC669D9406A8597EF8 ();
// 0x000003BE UnityEngine.Vector3 Cinemachine.Utility.SplineHelpers::Bezier3(System.Single,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void SplineHelpers_Bezier3_m671B7D546F16979F687B01A82D9239C0FF9A6C6F ();
// 0x000003BF UnityEngine.Vector3 Cinemachine.Utility.SplineHelpers::BezierTangent3(System.Single,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void SplineHelpers_BezierTangent3_m59375A4F9C985BC314131BC4286A02967A2A99B6 ();
// 0x000003C0 System.Single Cinemachine.Utility.SplineHelpers::Bezier1(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void SplineHelpers_Bezier1_m01DF69C839E93F6D90E4CDE0E048DC8E5CEC2AE9 ();
// 0x000003C1 System.Single Cinemachine.Utility.SplineHelpers::BezierTangent1(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void SplineHelpers_BezierTangent1_m6F265CBD431F2BDA6DBBFB16AD818D6EFA3D7690 ();
// 0x000003C2 System.Void Cinemachine.Utility.SplineHelpers::ComputeSmoothControlPoints(UnityEngine.Vector4[]&,UnityEngine.Vector4[]&,UnityEngine.Vector4[]&)
extern void SplineHelpers_ComputeSmoothControlPoints_mCBC6D06822574DCF0525832339422BCBA6AD899B ();
// 0x000003C3 System.Void Cinemachine.Utility.SplineHelpers::ComputeSmoothControlPointsLooped(UnityEngine.Vector4[]&,UnityEngine.Vector4[]&,UnityEngine.Vector4[]&)
extern void SplineHelpers_ComputeSmoothControlPointsLooped_mBD24C3CF63EA1ED0D83053C14DE95515C276DD5F ();
// 0x000003C4 System.Single Cinemachine.Utility.UnityVectorExtensions::ClosestPointOnSegment(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_ClosestPointOnSegment_m1BC07881406AD228FC3BD25F04DEEFCD844D0F03 ();
// 0x000003C5 System.Single Cinemachine.Utility.UnityVectorExtensions::ClosestPointOnSegment(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2)
extern void UnityVectorExtensions_ClosestPointOnSegment_m2743E36D603D1321F3BF3F0FA76618D30CF48144 ();
// 0x000003C6 UnityEngine.Vector3 Cinemachine.Utility.UnityVectorExtensions::ProjectOntoPlane(UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_ProjectOntoPlane_m8A4C6658A16D9A9E2415D787D52AF418133790D9 ();
// 0x000003C7 UnityEngine.Vector3 Cinemachine.Utility.UnityVectorExtensions::Abs(UnityEngine.Vector3)
extern void UnityVectorExtensions_Abs_mF5BB01E967809EAD9B96646DB47CA4457CECB544 ();
// 0x000003C8 System.Boolean Cinemachine.Utility.UnityVectorExtensions::AlmostZero(UnityEngine.Vector3)
extern void UnityVectorExtensions_AlmostZero_m9F538E467290B6199EA350E4639400BF9984915B ();
// 0x000003C9 System.Single Cinemachine.Utility.UnityVectorExtensions::Angle(UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_Angle_m04A32FB43E3D540CD85EF2A061C485A0EA1848F7 ();
// 0x000003CA System.Single Cinemachine.Utility.UnityVectorExtensions::SignedAngle(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_SignedAngle_mD9BC7BAFD53B8BEE637C33AF52EAB09DFA45F939 ();
// 0x000003CB UnityEngine.Quaternion Cinemachine.Utility.UnityVectorExtensions::SafeFromToRotation(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_SafeFromToRotation_mF94D5E648352AB7EAF0B22D751DED6B1E4E54BD9 ();
// 0x000003CC UnityEngine.Vector3 Cinemachine.Utility.UnityVectorExtensions::SlerpWithReferenceUp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single,UnityEngine.Vector3)
extern void UnityVectorExtensions_SlerpWithReferenceUp_m141B1B05C8FD1F4D0C4349E9A80BCC72604F0A58 ();
// 0x000003CD UnityEngine.Quaternion Cinemachine.Utility.UnityQuaternionExtensions::SlerpWithReferenceUp(UnityEngine.Quaternion,UnityEngine.Quaternion,System.Single,UnityEngine.Vector3)
extern void UnityQuaternionExtensions_SlerpWithReferenceUp_mB984001DA18FC2FF5035301F813B132AC999F1B6 ();
// 0x000003CE UnityEngine.Quaternion Cinemachine.Utility.UnityQuaternionExtensions::Normalized(UnityEngine.Quaternion)
extern void UnityQuaternionExtensions_Normalized_m36AE449C35F60018BD511131B87E1A63D1B7DCA2 ();
// 0x000003CF UnityEngine.Vector2 Cinemachine.Utility.UnityQuaternionExtensions::GetCameraRotationToTarget(UnityEngine.Quaternion,UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityQuaternionExtensions_GetCameraRotationToTarget_m744FC3EC6D163C8E4E5FD27AA9B83ADF321ED70F ();
// 0x000003D0 UnityEngine.Quaternion Cinemachine.Utility.UnityQuaternionExtensions::ApplyCameraRotation(UnityEngine.Quaternion,UnityEngine.Vector2,UnityEngine.Vector3)
extern void UnityQuaternionExtensions_ApplyCameraRotation_m950CF054F6A2F4868E5D333046204FB7F016D2DF ();
// 0x000003D1 UnityEngine.Rect Cinemachine.Utility.UnityRectExtensions::Inflated(UnityEngine.Rect,UnityEngine.Vector2)
extern void UnityRectExtensions_Inflated_m07D1A88B141BFE8C3DB3D24ED9045D0D5AF21EB8 ();
// 0x000003D2 System.Void CinemachineMixer_MasterDirectorDelegate::.ctor(System.Object,System.IntPtr)
extern void MasterDirectorDelegate__ctor_mFC5DB393BD8432B57F3EA9E183CD4D224AD4E5B3 ();
// 0x000003D3 UnityEngine.Playables.PlayableDirector CinemachineMixer_MasterDirectorDelegate::Invoke()
extern void MasterDirectorDelegate_Invoke_mE703899DFD92246C6411D29992C32024398EB999 ();
// 0x000003D4 System.IAsyncResult CinemachineMixer_MasterDirectorDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern void MasterDirectorDelegate_BeginInvoke_m67EDBDBF4F3B3BDA4AF8FDF03D0C43F6DB657E9E ();
// 0x000003D5 UnityEngine.Playables.PlayableDirector CinemachineMixer_MasterDirectorDelegate::EndInvoke(System.IAsyncResult)
extern void MasterDirectorDelegate_EndInvoke_m0DEA9513CDDF240BD9616179C047000F1C5552C3 ();
// 0x000003D6 System.Void Cinemachine.CinemachineBrain_BrainEvent::.ctor()
extern void BrainEvent__ctor_m648F7E949F40D8EAB7019FAED3ECE88D8CAF05D7 ();
// 0x000003D7 System.Void Cinemachine.CinemachineBrain_VcamActivatedEvent::.ctor()
extern void VcamActivatedEvent__ctor_mA99C1BA22F69EE75141BFFBB810E1230DCFA15E6 ();
// 0x000003D8 System.Boolean Cinemachine.CinemachineBrain_BrainFrame::get_Active()
extern void BrainFrame_get_Active_mD8AA67B2ACCA6591C9DA9A495850D2145C5B0712 ();
// 0x000003D9 System.Void Cinemachine.CinemachineBrain_BrainFrame::.ctor()
extern void BrainFrame__ctor_mA060413F10EA79721B2D2A33D99DC1D3282831A6 ();
// 0x000003DA System.Void Cinemachine.CinemachineBrain_<AfterPhysics>d__32::.ctor(System.Int32)
extern void U3CAfterPhysicsU3Ed__32__ctor_mA6C5A5508C88D026B3A525C6CD8B02F1C43CDA4C ();
// 0x000003DB System.Void Cinemachine.CinemachineBrain_<AfterPhysics>d__32::System.IDisposable.Dispose()
extern void U3CAfterPhysicsU3Ed__32_System_IDisposable_Dispose_m051EBB18282335A0C579BDB3DAFF72BFAABB1B2A ();
// 0x000003DC System.Boolean Cinemachine.CinemachineBrain_<AfterPhysics>d__32::MoveNext()
extern void U3CAfterPhysicsU3Ed__32_MoveNext_m7E724EAB70997756F9914B75FDD882B41179D4C9 ();
// 0x000003DD System.Object Cinemachine.CinemachineBrain_<AfterPhysics>d__32::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAfterPhysicsU3Ed__32_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m44FC9408A4C7D43320E5F71D756BF14526DB5119 ();
// 0x000003DE System.Void Cinemachine.CinemachineBrain_<AfterPhysics>d__32::System.Collections.IEnumerator.Reset()
extern void U3CAfterPhysicsU3Ed__32_System_Collections_IEnumerator_Reset_m1C4AC9CF256FD26354DCD648E11DD88D3651CED6 ();
// 0x000003DF System.Object Cinemachine.CinemachineBrain_<AfterPhysics>d__32::System.Collections.IEnumerator.get_Current()
extern void U3CAfterPhysicsU3Ed__32_System_Collections_IEnumerator_get_Current_mC062E14211D5DBC08B65BB1AB2DA18E08C8E21DB ();
// 0x000003E0 System.Void Cinemachine.CinemachineClearShot_<>c::.cctor()
extern void U3CU3Ec__cctor_m9685B944F64D38F8A51929E1DCF7714D96EE5C6E ();
// 0x000003E1 System.Void Cinemachine.CinemachineClearShot_<>c::.ctor()
extern void U3CU3Ec__ctor_m02E5C011A18650E911D7DE28902B36407425A1DA ();
// 0x000003E2 System.Int32 Cinemachine.CinemachineClearShot_<>c::<Randomize>b__47_0(Cinemachine.CinemachineClearShot_Pair,Cinemachine.CinemachineClearShot_Pair)
extern void U3CU3Ec_U3CRandomizeU3Eb__47_0_m11EDFFF61087041AA23E34C5AE7D01B6976118F9 ();
// 0x000003E3 System.Void Cinemachine.CinemachineCollider_VcamExtraState::AddPointToDebugPath(UnityEngine.Vector3)
extern void VcamExtraState_AddPointToDebugPath_mFF718D5B8D9DACD1A94BAFB458A028241E0FC95B ();
// 0x000003E4 System.Single Cinemachine.CinemachineCollider_VcamExtraState::ApplyDistanceSmoothing(System.Single,System.Single)
extern void VcamExtraState_ApplyDistanceSmoothing_mB2490C4B28326713F8FAECEEBC239B46BDBB853C ();
// 0x000003E5 System.Void Cinemachine.CinemachineCollider_VcamExtraState::UpdateDistanceSmoothing(System.Single,System.Single)
extern void VcamExtraState_UpdateDistanceSmoothing_m75C77A914C361D02C7C0F9B73A874D309EC124B8 ();
// 0x000003E6 System.Void Cinemachine.CinemachineCollider_VcamExtraState::ResetDistanceSmoothing(System.Single)
extern void VcamExtraState_ResetDistanceSmoothing_m9DA2E009ED1BBFD18F811B5A1E0DF1BE9D91342C ();
// 0x000003E7 System.Void Cinemachine.CinemachineCollider_VcamExtraState::.ctor()
extern void VcamExtraState__ctor_mAD425FDD74968E2F744178F85B1C9F5FA2FA875F ();
// 0x000003E8 System.Void Cinemachine.CinemachineConfiner_VcamExtraState::.ctor()
extern void VcamExtraState__ctor_m0EE1BF4E53FB8E8DFF70446D1A47286397ED89FD ();
// 0x000003E9 System.Void Cinemachine.CinemachineFollowZoom_VcamExtraState::.ctor()
extern void VcamExtraState__ctor_m765B777C8201B5A5D21FB547AA0215538E7CD976 ();
// 0x000003EA System.Void Cinemachine.CinemachineFreeLook_Orbit::.ctor(System.Single,System.Single)
extern void Orbit__ctor_mBDC642CE7F3E574E43895420FD0343C3199FC85A_AdjustorThunk ();
// 0x000003EB System.Void Cinemachine.CinemachineFreeLook_CreateRigDelegate::.ctor(System.Object,System.IntPtr)
extern void CreateRigDelegate__ctor_m4DD0C7DBDBDA591D52EA8F0328BAB450BFCF51C2 ();
// 0x000003EC Cinemachine.CinemachineVirtualCamera Cinemachine.CinemachineFreeLook_CreateRigDelegate::Invoke(Cinemachine.CinemachineFreeLook,System.String,Cinemachine.CinemachineVirtualCamera)
extern void CreateRigDelegate_Invoke_mAD1425DD908EFF6A0D37E425A6A2503EB0C0D6F9 ();
// 0x000003ED System.IAsyncResult Cinemachine.CinemachineFreeLook_CreateRigDelegate::BeginInvoke(Cinemachine.CinemachineFreeLook,System.String,Cinemachine.CinemachineVirtualCamera,System.AsyncCallback,System.Object)
extern void CreateRigDelegate_BeginInvoke_m3026592E9652091C21A95142D9C9840AAE61EBAD ();
// 0x000003EE Cinemachine.CinemachineVirtualCamera Cinemachine.CinemachineFreeLook_CreateRigDelegate::EndInvoke(System.IAsyncResult)
extern void CreateRigDelegate_EndInvoke_mDDDCBA482E40537F256E8B0F686EA019C7FC42F7 ();
// 0x000003EF System.Void Cinemachine.CinemachineFreeLook_DestroyRigDelegate::.ctor(System.Object,System.IntPtr)
extern void DestroyRigDelegate__ctor_m6B51E8D805DD7A663BE724FC16D490F5D0D05D69 ();
// 0x000003F0 System.Void Cinemachine.CinemachineFreeLook_DestroyRigDelegate::Invoke(UnityEngine.GameObject)
extern void DestroyRigDelegate_Invoke_mE9C9FD19BE4FD0204687FA43F0C771C3C77E11C6 ();
// 0x000003F1 System.IAsyncResult Cinemachine.CinemachineFreeLook_DestroyRigDelegate::BeginInvoke(UnityEngine.GameObject,System.AsyncCallback,System.Object)
extern void DestroyRigDelegate_BeginInvoke_mC12BBE33DEEA306A7AE1FFD1E961069DCC252BE5 ();
// 0x000003F2 System.Void Cinemachine.CinemachineFreeLook_DestroyRigDelegate::EndInvoke(System.IAsyncResult)
extern void DestroyRigDelegate_EndInvoke_mE037D325234815525A86DF33050DE927EFCD8F22 ();
// 0x000003F3 UnityEngine.Vector4 Cinemachine.CinemachineSmoothPath_Waypoint::get_AsVector4()
extern void Waypoint_get_AsVector4_m9CB420052E5FB5EA1681133222C5EB982BEA6BAC_AdjustorThunk ();
// 0x000003F4 Cinemachine.CinemachineSmoothPath_Waypoint Cinemachine.CinemachineSmoothPath_Waypoint::FromVector4(UnityEngine.Vector4)
extern void Waypoint_FromVector4_m1F859E37CBC871BC98DC89550A1C6B264E46FB2A ();
// 0x000003F5 System.Void Cinemachine.CinemachineStateDrivenCamera_ParentHash::.ctor(System.Int32,System.Int32)
extern void ParentHash__ctor_mFD2F0C557399C8A6C3798E3CDC0EB58B5E82A094_AdjustorThunk ();
// 0x000003F6 System.Void Cinemachine.CinemachineStoryboard_CanvasInfo::.ctor()
extern void CanvasInfo__ctor_mD8E59D1746FD1DC9B497D9668DE2FACB016738DE ();
// 0x000003F7 System.Void Cinemachine.CinemachineVirtualCamera_CreatePipelineDelegate::.ctor(System.Object,System.IntPtr)
extern void CreatePipelineDelegate__ctor_mF51B89DEB4EAE7A714B49CA9BF703B8541D419A0 ();
// 0x000003F8 UnityEngine.Transform Cinemachine.CinemachineVirtualCamera_CreatePipelineDelegate::Invoke(Cinemachine.CinemachineVirtualCamera,System.String,Cinemachine.CinemachineComponentBase[])
extern void CreatePipelineDelegate_Invoke_mF25FE1D09EC7FB09C0E0EDF766B2A19BF31080E5 ();
// 0x000003F9 System.IAsyncResult Cinemachine.CinemachineVirtualCamera_CreatePipelineDelegate::BeginInvoke(Cinemachine.CinemachineVirtualCamera,System.String,Cinemachine.CinemachineComponentBase[],System.AsyncCallback,System.Object)
extern void CreatePipelineDelegate_BeginInvoke_m354E9436E905807B4CCD0ACB6528D067E014E638 ();
// 0x000003FA UnityEngine.Transform Cinemachine.CinemachineVirtualCamera_CreatePipelineDelegate::EndInvoke(System.IAsyncResult)
extern void CreatePipelineDelegate_EndInvoke_m038BA53E61623D2190CBCCD6649F230C29CE89F0 ();
// 0x000003FB System.Void Cinemachine.CinemachineVirtualCamera_DestroyPipelineDelegate::.ctor(System.Object,System.IntPtr)
extern void DestroyPipelineDelegate__ctor_m3D90BC04CC0ADE49A4EE6503D20E7AB776F7A6AA ();
// 0x000003FC System.Void Cinemachine.CinemachineVirtualCamera_DestroyPipelineDelegate::Invoke(UnityEngine.GameObject)
extern void DestroyPipelineDelegate_Invoke_m900F828AF1A5259B1D8606DB45BD14D4CB3274E1 ();
// 0x000003FD System.IAsyncResult Cinemachine.CinemachineVirtualCamera_DestroyPipelineDelegate::BeginInvoke(UnityEngine.GameObject,System.AsyncCallback,System.Object)
extern void DestroyPipelineDelegate_BeginInvoke_m5E9E8B1CCB62A8EA334567CE88741B5356DE062B ();
// 0x000003FE System.Void Cinemachine.CinemachineVirtualCamera_DestroyPipelineDelegate::EndInvoke(System.IAsyncResult)
extern void DestroyPipelineDelegate_EndInvoke_mD018624F272E6D61432DF250DFCDAD7DC2B53BBB ();
// 0x000003FF System.Void Cinemachine.CinemachineVirtualCamera_<>c::.cctor()
extern void U3CU3Ec__cctor_m575A5E831C9D536CC3AF82E75EBEE29E76D43C89 ();
// 0x00000400 System.Void Cinemachine.CinemachineVirtualCamera_<>c::.ctor()
extern void U3CU3Ec__ctor_mFB7EABDE6BB8BDE667A9786AC0176017ADEC9AF3 ();
// 0x00000401 System.Int32 Cinemachine.CinemachineVirtualCamera_<>c::<UpdateComponentPipeline>b__41_0(Cinemachine.CinemachineComponentBase,Cinemachine.CinemachineComponentBase)
extern void U3CU3Ec_U3CUpdateComponentPipelineU3Eb__41_0_mCE45F92D28AB75075C2C97D20DBDAF56CB6D1FA3 ();
// 0x00000402 System.Void Cinemachine.CinemachineComposer_FovCache::UpdateCache(Cinemachine.LensSettings,UnityEngine.Rect,UnityEngine.Rect,System.Single)
extern void FovCache_UpdateCache_m2EFDABF6DAFD0ACF434A8A83F5CAB0AA4B4F3519_AdjustorThunk ();
// 0x00000403 UnityEngine.Rect Cinemachine.CinemachineComposer_FovCache::ScreenToFOV(UnityEngine.Rect,System.Single,System.Single,System.Single)
extern void FovCache_ScreenToFOV_m813E0A11A9BEBC417751E33DA5E18A5A0DADFF2B_AdjustorThunk ();
// 0x00000404 System.Void Cinemachine.CinemachineOrbitalTransposer_Heading::.ctor(Cinemachine.CinemachineOrbitalTransposer_Heading_HeadingDefinition,System.Int32,System.Single)
extern void Heading__ctor_m27AC6DA9204C9B4856DEA05AAAD89E2400FF639A_AdjustorThunk ();
// 0x00000405 System.Void Cinemachine.CinemachineOrbitalTransposer_UpdateHeadingDelegate::.ctor(System.Object,System.IntPtr)
extern void UpdateHeadingDelegate__ctor_mB9BA33C54488BC8DD418BEEF3A51DB6AF40E361B ();
// 0x00000406 System.Single Cinemachine.CinemachineOrbitalTransposer_UpdateHeadingDelegate::Invoke(Cinemachine.CinemachineOrbitalTransposer,System.Single,UnityEngine.Vector3)
extern void UpdateHeadingDelegate_Invoke_m3A58C1E3FAF4FE5B175648FF19F95BAD57CC6330 ();
// 0x00000407 System.IAsyncResult Cinemachine.CinemachineOrbitalTransposer_UpdateHeadingDelegate::BeginInvoke(Cinemachine.CinemachineOrbitalTransposer,System.Single,UnityEngine.Vector3,System.AsyncCallback,System.Object)
extern void UpdateHeadingDelegate_BeginInvoke_mBDCD4A90CE6D3E50F8A7A7FF3A12039EE580E4A4 ();
// 0x00000408 System.Single Cinemachine.CinemachineOrbitalTransposer_UpdateHeadingDelegate::EndInvoke(System.IAsyncResult)
extern void UpdateHeadingDelegate_EndInvoke_m75EB1823E9A52B6FD0216E863677C5A357A13672 ();
// 0x00000409 System.Void Cinemachine.CinemachineOrbitalTransposer_<>c::.cctor()
extern void U3CU3Ec__cctor_m040BE18F4CF76FD237A199F900F8B2D09794FBBD ();
// 0x0000040A System.Void Cinemachine.CinemachineOrbitalTransposer_<>c::.ctor()
extern void U3CU3Ec__ctor_m2CC55D7CF3C4815383423BEA372FB9753A747D29 ();
// 0x0000040B System.Single Cinemachine.CinemachineOrbitalTransposer_<>c::<.ctor>b__35_0(Cinemachine.CinemachineOrbitalTransposer,System.Single,UnityEngine.Vector3)
extern void U3CU3Ec_U3C_ctorU3Eb__35_0_m15844BD8ED7CDBED9326054C7B7C6DFAD6B2C52C ();
// 0x0000040C System.Void Cinemachine.CinemachineTrackedDolly_AutoDolly::.ctor(System.Boolean,System.Single,System.Int32,System.Int32)
extern void AutoDolly__ctor_mB22E90A64C6D9D0F6C0F6FE794446F2867E76793_AdjustorThunk ();
// 0x0000040D System.Single Cinemachine.AxisState_IInputAxisProvider::GetAxisValue(System.Int32)
// 0x0000040E System.Void Cinemachine.AxisState_Recentering::.ctor(System.Boolean,System.Single,System.Single)
extern void Recentering__ctor_mDFE3D3BB932AF426369B033D18AD3FDAAF26384F_AdjustorThunk ();
// 0x0000040F System.Void Cinemachine.AxisState_Recentering::Validate()
extern void Recentering_Validate_mFB967BB954EFD0DD6E2315F53A3241FDC146B18A_AdjustorThunk ();
// 0x00000410 System.Void Cinemachine.AxisState_Recentering::CopyStateFrom(Cinemachine.AxisState_Recentering&)
extern void Recentering_CopyStateFrom_mE18BDABB9C0A8D71903C3173B9783435DDE64918_AdjustorThunk ();
// 0x00000411 System.Void Cinemachine.AxisState_Recentering::CancelRecentering()
extern void Recentering_CancelRecentering_m49877C0EBC7D9873C40CABD8EEF245954703CEC2_AdjustorThunk ();
// 0x00000412 System.Void Cinemachine.AxisState_Recentering::RecenterNow()
extern void Recentering_RecenterNow_mB95BFD6D292191AB019A574F835AE4FB2A5ECD54_AdjustorThunk ();
// 0x00000413 System.Void Cinemachine.AxisState_Recentering::DoRecentering(Cinemachine.AxisState&,System.Single,System.Single)
extern void Recentering_DoRecentering_mA1AB5ACE77B56D9357CBB46FB4BEAF42AED5CD6C_AdjustorThunk ();
// 0x00000414 System.Boolean Cinemachine.AxisState_Recentering::LegacyUpgrade(System.Int32&,System.Int32&)
extern void Recentering_LegacyUpgrade_mE331A7312B51DE3F31805A89EC3E4EB9DF71567E_AdjustorThunk ();
// 0x00000415 System.Void Cinemachine.CameraState_CustomBlendable::.ctor(UnityEngine.Object,System.Single)
extern void CustomBlendable__ctor_mA7DEF75ACB9FDE678221EF6176FBD4DC4441FB07_AdjustorThunk ();
// 0x00000416 System.Void Cinemachine.CinemachineCore_AxisInputDelegate::.ctor(System.Object,System.IntPtr)
extern void AxisInputDelegate__ctor_m55631A6E688731D441A5822CE96218E7E9CC5B01 ();
// 0x00000417 System.Single Cinemachine.CinemachineCore_AxisInputDelegate::Invoke(System.String)
extern void AxisInputDelegate_Invoke_m860AF1CED1A9DF40081361395A2E99E5913DE2D4 ();
// 0x00000418 System.IAsyncResult Cinemachine.CinemachineCore_AxisInputDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void AxisInputDelegate_BeginInvoke_mE17152E703E8CC1FD23F1699D57494CD620D559D ();
// 0x00000419 System.Single Cinemachine.CinemachineCore_AxisInputDelegate::EndInvoke(System.IAsyncResult)
extern void AxisInputDelegate_EndInvoke_m42BA5EAD29B364609461C59796CF1FE308942777 ();
// 0x0000041A System.Void Cinemachine.CinemachineCore_GetBlendOverrideDelegate::.ctor(System.Object,System.IntPtr)
extern void GetBlendOverrideDelegate__ctor_m0D9DFFA11AA07FC85C2903B99641E4CE9BF6DC9B ();
// 0x0000041B Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineCore_GetBlendOverrideDelegate::Invoke(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,Cinemachine.CinemachineBlendDefinition,UnityEngine.MonoBehaviour)
extern void GetBlendOverrideDelegate_Invoke_mAE517451152A2ADCF950A31A7004F52FA64C8EE0 ();
// 0x0000041C System.IAsyncResult Cinemachine.CinemachineCore_GetBlendOverrideDelegate::BeginInvoke(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,Cinemachine.CinemachineBlendDefinition,UnityEngine.MonoBehaviour,System.AsyncCallback,System.Object)
extern void GetBlendOverrideDelegate_BeginInvoke_m4CEF86F10D8C529DD09C94310D0E70668307B360 ();
// 0x0000041D Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineCore_GetBlendOverrideDelegate::EndInvoke(System.IAsyncResult)
extern void GetBlendOverrideDelegate_EndInvoke_m07B62A912EE6066CE03A1D3125A0BEB2ED1AC0E4 ();
// 0x0000041E System.Void Cinemachine.CinemachineCore_UpdateStatus::.ctor()
extern void UpdateStatus__ctor_mAEEB635F3C3AE9D84B9072DA75E14B098312CACD ();
// 0x0000041F System.Void Cinemachine.CinemachinePathBase_Appearance::.ctor()
extern void Appearance__ctor_m975B387EF5A573D25BD3C5C57B0314F3C4446196 ();
// 0x00000420 System.Single Cinemachine.NoiseSettings_NoiseParams::GetValueAt(System.Single,System.Single)
extern void NoiseParams_GetValueAt_mA2C1E6FA7AE9AB3FC9A51024E0D474E5C8596610_AdjustorThunk ();
// 0x00000421 UnityEngine.Vector3 Cinemachine.NoiseSettings_TransformNoiseParams::GetValueAt(System.Single,UnityEngine.Vector3)
extern void TransformNoiseParams_GetValueAt_m89FDF2289D147DC0B617426E76A78402474770CD_AdjustorThunk ();
// 0x00000422 System.Int32 Cinemachine.TargetPositionCache_CacheCurve::get_Count()
extern void CacheCurve_get_Count_m7BE1AE49E310A7185E449EF27D9715404DB58F4D ();
// 0x00000423 System.Void Cinemachine.TargetPositionCache_CacheCurve::.ctor(System.Single,System.Single,System.Single)
extern void CacheCurve__ctor_m9126DDC2FF162438BEF34E60AD524A2BD74E09D8 ();
// 0x00000424 System.Void Cinemachine.TargetPositionCache_CacheCurve::Add(Cinemachine.TargetPositionCache_CacheCurve_Item)
extern void CacheCurve_Add_m325C65AD39FDFBC91F4D5624B8BF7C5560B36DFF ();
// 0x00000425 System.Void Cinemachine.TargetPositionCache_CacheCurve::AddUntil(Cinemachine.TargetPositionCache_CacheCurve_Item,System.Single,System.Boolean)
extern void CacheCurve_AddUntil_m3613245687496AC0DC18F1EB9A6328E3F8AA203F ();
// 0x00000426 Cinemachine.TargetPositionCache_CacheCurve_Item Cinemachine.TargetPositionCache_CacheCurve::Evaluate(System.Single)
extern void CacheCurve_Evaluate_m9D2DF73C6C1AF43179910C16C2249A6205429938 ();
// 0x00000427 System.Void Cinemachine.TargetPositionCache_CacheEntry::AddRawItem(System.Single,System.Boolean,UnityEngine.Transform)
extern void CacheEntry_AddRawItem_m56ADB9D380E62201025B3F4B752CDD4E90970B49 ();
// 0x00000428 System.Void Cinemachine.TargetPositionCache_CacheEntry::CreateCurves()
extern void CacheEntry_CreateCurves_m3C30DAF286804CB56B42102406ACE0BF891292EA ();
// 0x00000429 System.Void Cinemachine.TargetPositionCache_CacheEntry::.ctor()
extern void CacheEntry__ctor_mF5B26181E6FBFC00701BC6A362BEA3416815FD2B ();
// 0x0000042A System.Boolean Cinemachine.TargetPositionCache_TimeRange::get_IsEmpty()
extern void TimeRange_get_IsEmpty_m0EBE2CFDA395E03444770956D336B17D2CC676D0_AdjustorThunk ();
// 0x0000042B System.Boolean Cinemachine.TargetPositionCache_TimeRange::Contains(System.Single)
extern void TimeRange_Contains_m2FE15B3333F2883C0580220A5D3FDE954533A8FA_AdjustorThunk ();
// 0x0000042C Cinemachine.TargetPositionCache_TimeRange Cinemachine.TargetPositionCache_TimeRange::get_Empty()
extern void TimeRange_get_Empty_m273B20F7E14B9A0670F209E17316EC4EBDD7D053 ();
// 0x0000042D System.Void Cinemachine.TargetPositionCache_TimeRange::Include(System.Single)
extern void TimeRange_Include_m98B368672B3FAD811027079C3EA8236914D3729E_AdjustorThunk ();
// 0x0000042E Cinemachine.UpdateTracker_UpdateClock Cinemachine.UpdateTracker_UpdateStatus::get_PreferredUpdate()
extern void UpdateStatus_get_PreferredUpdate_mF6224BC9B52B95B06ECD82F3CCDAC7B0994B9B6F ();
// 0x0000042F System.Void Cinemachine.UpdateTracker_UpdateStatus::set_PreferredUpdate(Cinemachine.UpdateTracker_UpdateClock)
extern void UpdateStatus_set_PreferredUpdate_m0D163727BB4C16214C9A22D74656ED09CEF6C929 ();
// 0x00000430 System.Void Cinemachine.UpdateTracker_UpdateStatus::.ctor(System.Int32,UnityEngine.Matrix4x4)
extern void UpdateStatus__ctor_mDEAE275BFECF3D63AE2A93D74EABACD19FA21724 ();
// 0x00000431 System.Void Cinemachine.UpdateTracker_UpdateStatus::OnUpdate(System.Int32,Cinemachine.UpdateTracker_UpdateClock,UnityEngine.Matrix4x4)
extern void UpdateStatus_OnUpdate_m22DED61941774ECFB0119BAAE3BD2C164D39D521 ();
// 0x00000432 System.Void Cinemachine.CinemachineTriggerAction_ActionSettings::.ctor(Cinemachine.CinemachineTriggerAction_ActionSettings_Mode)
extern void ActionSettings__ctor_mD581917562ECC8295F6278BA5AD001705F8E9035_AdjustorThunk ();
// 0x00000433 System.Void Cinemachine.CinemachineTriggerAction_ActionSettings::Invoke()
extern void ActionSettings_Invoke_mF3E35400963944A72FD025FEF8052413056DC716_AdjustorThunk ();
// 0x00000434 System.Void Cinemachine.CinemachineImpulseDefinition_SignalSource::.ctor(Cinemachine.CinemachineImpulseDefinition,UnityEngine.Vector3)
extern void SignalSource__ctor_mCB153F491DABCD71273BD63B24BF32099AEBEF80 ();
// 0x00000435 System.Single Cinemachine.CinemachineImpulseDefinition_SignalSource::get_SignalDuration()
extern void SignalSource_get_SignalDuration_m361ECAF68816FA8EC16C6EF9644886A11CFAA837 ();
// 0x00000436 System.Void Cinemachine.CinemachineImpulseDefinition_SignalSource::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void SignalSource_GetSignal_m9A46E678A84820D6D5FC33F008DEC2DFCFB94DA1 ();
// 0x00000437 Cinemachine.CinemachineImpulseManager_EnvelopeDefinition Cinemachine.CinemachineImpulseManager_EnvelopeDefinition::Default()
extern void EnvelopeDefinition_Default_m6048BC0ADAE235D4D0F47D57AC6F07F8031E8502 ();
// 0x00000438 System.Single Cinemachine.CinemachineImpulseManager_EnvelopeDefinition::get_Duration()
extern void EnvelopeDefinition_get_Duration_m494621ABECC584E355834D287BEA915BD68A774F_AdjustorThunk ();
// 0x00000439 System.Single Cinemachine.CinemachineImpulseManager_EnvelopeDefinition::GetValueAt(System.Single)
extern void EnvelopeDefinition_GetValueAt_mA27AFC5D351DA50CA935ACCAB79D91F1E924C8CC_AdjustorThunk ();
// 0x0000043A System.Void Cinemachine.CinemachineImpulseManager_EnvelopeDefinition::ChangeStopTime(System.Single,System.Boolean)
extern void EnvelopeDefinition_ChangeStopTime_mA4D7614B6F56A8E279596B52252816EB59843F23_AdjustorThunk ();
// 0x0000043B System.Void Cinemachine.CinemachineImpulseManager_EnvelopeDefinition::Clear()
extern void EnvelopeDefinition_Clear_m2B817953AFB7CDAA6B62AEC4A1E6A588484B554B_AdjustorThunk ();
// 0x0000043C System.Void Cinemachine.CinemachineImpulseManager_EnvelopeDefinition::Validate()
extern void EnvelopeDefinition_Validate_mA0464BC35544052393B17674F751FAA755051B14_AdjustorThunk ();
// 0x0000043D System.Boolean Cinemachine.CinemachineImpulseManager_ImpulseEvent::get_Expired()
extern void ImpulseEvent_get_Expired_m06944921FE1EEA9118BFAEE7F52E73280418DCA7 ();
// 0x0000043E System.Void Cinemachine.CinemachineImpulseManager_ImpulseEvent::Cancel(System.Single,System.Boolean)
extern void ImpulseEvent_Cancel_mA2831A11F90680EE32F4685E6311140D627C877B ();
// 0x0000043F System.Single Cinemachine.CinemachineImpulseManager_ImpulseEvent::DistanceDecay(System.Single)
extern void ImpulseEvent_DistanceDecay_mF8C3C77FF46D6C2B23BE694CCA9714F76ED60036 ();
// 0x00000440 System.Boolean Cinemachine.CinemachineImpulseManager_ImpulseEvent::GetDecayedSignal(UnityEngine.Vector3,System.Boolean,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void ImpulseEvent_GetDecayedSignal_m973C1F0E6D32DC4DD14ECDF280FE58D14F6943EC ();
// 0x00000441 System.Void Cinemachine.CinemachineImpulseManager_ImpulseEvent::Clear()
extern void ImpulseEvent_Clear_m3FBD19A05EAC470ACE87FAC6CF8FCBBB01E278A2 ();
// 0x00000442 System.Void Cinemachine.CinemachineImpulseManager_ImpulseEvent::.ctor()
extern void ImpulseEvent__ctor_mBDBA49A0F06CCB22CAB3ADCFB3B62BB1EF812E53 ();
// 0x00000443 System.Void Cinemachine.Utility.CinemachineDebug_OnGUIDelegate::.ctor(System.Object,System.IntPtr)
extern void OnGUIDelegate__ctor_m368CF0C4912A67D1DBDA8E1F2C2827D0163482FA ();
// 0x00000444 System.Void Cinemachine.Utility.CinemachineDebug_OnGUIDelegate::Invoke()
extern void OnGUIDelegate_Invoke_mA31514C83F7C6B0DC124FB9C3C9AF1AE46EA3BE2 ();
// 0x00000445 System.IAsyncResult Cinemachine.Utility.CinemachineDebug_OnGUIDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern void OnGUIDelegate_BeginInvoke_mB9DDADF15A39323C1F037853E3A73B2AB7697E33 ();
// 0x00000446 System.Void Cinemachine.Utility.CinemachineDebug_OnGUIDelegate::EndInvoke(System.IAsyncResult)
extern void OnGUIDelegate_EndInvoke_mA2E9D5AB93F6750402449BC316CB9F00CD0013F9 ();
// 0x00000447 Cinemachine.TargetPositionCache_CacheCurve_Item Cinemachine.TargetPositionCache_CacheCurve_Item::Lerp(Cinemachine.TargetPositionCache_CacheCurve_Item,Cinemachine.TargetPositionCache_CacheCurve_Item,System.Single)
extern void Item_Lerp_m729C3CBFCA75B42CC2799D491DEF4C17C53602DC ();
// 0x00000448 Cinemachine.TargetPositionCache_CacheCurve_Item Cinemachine.TargetPositionCache_CacheCurve_Item::get_Empty()
extern void Item_get_Empty_m2209C3BE792AABD138C9A597718D01D2FF089CB3 ();
// 0x00000449 System.Void Cinemachine.CinemachineTriggerAction_ActionSettings_TriggerEvent::.ctor()
extern void TriggerEvent__ctor_m1B0E4D0D8DD5D925A7B5F502DECF073FBA41C266 ();
static Il2CppMethodPointer s_methodPointers[1097] = 
{
	CinemachineCameraOffset_PostPipelineStageCallback_m214222457A0BD96712F898260D4D5F9757C1D736,
	CinemachineCameraOffset__ctor_mBA995110079C215F7AB8FF6DF54C37231C3B5728,
	CinemachineRecomposer_Reset_m88525BE6F6B1DF4ABC2E58CCD4E5C95C3ED79A27,
	CinemachineRecomposer_OnValidate_m9BD3BC5317D1374AEC17027D208741B5A8F62678,
	CinemachineRecomposer_PrePipelineMutateCameraStateCallback_mDE48BF5922B0CB07EEC0EDA9E1E77D86FF57C203,
	CinemachineRecomposer_PostPipelineStageCallback_mE0BE4A9CF309A03D03861E086ED513AEDC9C3078,
	CinemachineRecomposer__ctor_mA94BEB1150CFE4D50C588D2F5C166B268D7B1362,
	CinemachineTouchInputMapper_Start_m3AC349B75F081ACCDA532FBFD15F6C4DC5FA7BCC,
	CinemachineTouchInputMapper_GetInputAxis_mC7DB7FBF8CA101DD4F25DC42253932CAFA2F1413,
	CinemachineTouchInputMapper__ctor_mCE60215EA756B6CC9CDE11A6A29355961C35FCFE,
	CinemachineMixer_OnPlayableDestroy_m15D0D97BC182EEA1A886B55A440F3F37FA1B427B,
	CinemachineMixer_PrepareFrame_mEDA03F2B9CB7AB571903D7BE4CAFA9340020B617,
	CinemachineMixer_ProcessFrame_m34F7C76AC1EB8C4027CD23D54C8A0DF74788076C,
	CinemachineMixer_GetDeltaTime_mAFED8F9148B137A18BB77BBA34B10DC79E4EDBAC,
	CinemachineMixer__ctor_m65687FEE5BF1A97442CCA217DC7E688AF110508A,
	CinemachineShot_CreatePlayable_mEEA36A48B4C1B0AE73DD4E6DB5BB67EDD5CC9FBF,
	CinemachineShot_GatherProperties_mD35DE60059D05AA13705B3AA45C1A2D3FD82E2A2,
	CinemachineShot__ctor_m4E0ED8E81339A16B4BBE6833D2891A59F1868F04,
	CinemachineShotPlayable_get_IsValid_m783EFC14C1B6E0C331E8BE1FB97BF73E5C0FB085,
	CinemachineShotPlayable__ctor_m5831073991E80621F1FD0DAE1862F4B47D4FEC58,
	CinemachineTrack_CreateTrackMixer_mC9AD3E7B72FDAF3BF9ECBFE57BDD75880F7A4346,
	CinemachineTrack__ctor_m346DCFF5C3E9A01315B9C4F59625F3FFAC3DDBDA,
	Cinemachine3rdPersonAim_OnValidate_m1DB2920E91BF684D7E934BC0136839D7ABF49C09,
	Cinemachine3rdPersonAim_Reset_m76AF226247A9F0C4CCDDF0200876BC01859A17DA,
	Cinemachine3rdPersonAim_OnTransitionFromCamera_mB60FDBDAEC3D755C4BC8FF8EB9DB5A8226FE5144,
	Cinemachine3rdPersonAim_DrawReticle_m4B256A71AFE3F96910662DEE45FC49FD1BAACD50,
	Cinemachine3rdPersonAim_GetLookAtPoint_m6EFCD1C8BBBA93A85D2C873ABB33F85025D2E859,
	Cinemachine3rdPersonAim_PostPipelineStageCallback_m431D6A5A151FC73D58E2BB5C843C4A9D785AED82,
	Cinemachine3rdPersonAim__ctor_m3FD0201C504BF089A48A2A2054B8CD3F85DB46EF,
	CinemachineBlendListCamera_get_Description_m5C6D715F0F62C76E72B28C22E29B85A99F44FB8A,
	CinemachineBlendListCamera_set_LiveChild_m06CBC3CB11F541FA72E4F5189DA3CDAD2F93A12D,
	CinemachineBlendListCamera_get_LiveChild_mC110B712B11C6D0D8BEE7CF35511A88932FB374B,
	CinemachineBlendListCamera_IsLiveChild_m01E481F15D50EDA15D50F7698A8D4270E9A6DF2D,
	CinemachineBlendListCamera_get_State_m0F2CC117E1188ED5E61F263A3F96C99152603997,
	CinemachineBlendListCamera_get_LookAt_m4987B243A6841944D9CC1DCEEB208D75DD472D8F,
	CinemachineBlendListCamera_set_LookAt_m89A121D81D3A5A9AB901C2490C8582E19D56720B,
	CinemachineBlendListCamera_get_Follow_m4C77B0D9285FF0E0BDE6672AA97CBFEA8F779EAE,
	CinemachineBlendListCamera_set_Follow_m11AC198E828F34AA47C3DEDEE0255BB52155E4F3,
	CinemachineBlendListCamera_OnTargetObjectWarped_m064D8A1708A9EC3A8C3781CDDEAE0DD19F26C226,
	CinemachineBlendListCamera_ForceCameraPosition_m8353DC410D5F9C28E6BD4A6E795E8B02C2AD102F,
	CinemachineBlendListCamera_OnTransitionFromCamera_m0A4B32A2C54128881A91D1AC80C83EA626FF6403,
	CinemachineBlendListCamera_get_TransitioningFrom_mD6696F8110804BEA7C73ECE7815C01349DA80ADD,
	CinemachineBlendListCamera_set_TransitioningFrom_mAD76B896D15BE8EC438A9527249DC62FD696EE0D,
	CinemachineBlendListCamera_InternalUpdateCameraState_m58770001B7B5AC14E824882B59611938B64B289D,
	CinemachineBlendListCamera_OnEnable_m64064AC70DFF2427499FE68274AC45E753D556CA,
	CinemachineBlendListCamera_OnDisable_m46FCC8C90F9233ED5528545F728D23B8AEC439FA,
	CinemachineBlendListCamera_OnTransformChildrenChanged_m08CB2CA52EDFE41199C966A34F478C3D85425EC2,
	CinemachineBlendListCamera_OnGuiHandler_m58B69E2CCF7FA61E5DD1934735E6873DCF379FD0,
	CinemachineBlendListCamera_get_ChildCameras_m85978F41F7E12760B36BE29F70107684A229295D,
	CinemachineBlendListCamera_get_IsBlending_m0BAA4ACB2EBA83796F4E210F8E870329676F4708,
	CinemachineBlendListCamera_InvalidateListOfChildren_m1A851A8A2A3D12271AEBCB7CB52D014AEB6920ED,
	CinemachineBlendListCamera_UpdateListOfChildren_m78195EDC229BA08AB69C876F0574217BFAFCEBB5,
	CinemachineBlendListCamera_ValidateInstructions_m39EE271A6D34B62732B978205EBF6681B6657ECC,
	CinemachineBlendListCamera_AdvanceCurrentInstruction_m6AE0D5A3A44F65265B9C461AAA1C577D80527DDF,
	CinemachineBlendListCamera__ctor_m415640A76DED96AA7D39819787BACBC3220728C5,
	CinemachineBrain_get_OutputCamera_m53C6A01A6715756C5A1B80FB403453B3CB28DF84,
	CinemachineBrain_get_SoloCamera_mEAD650442E6D40F860F2668FD0BFEA14495B1F48,
	CinemachineBrain_set_SoloCamera_mCDFED6D67E47D86163AAB3B63A60BB335586FC58,
	CinemachineBrain_GetSoloGUIColor_m1EDE8585C43B473EDAA59D61D558D83F356E45F8,
	CinemachineBrain_get_DefaultWorldUp_mA052F23DFC679E1E0E15B2466ECB3799B656CBA4,
	CinemachineBrain_OnEnable_m444560E00F8FE814A13A5C18076C4ECFE09A9C12,
	CinemachineBrain_OnDisable_mD0002ADB05DE5396E8782571436DC874A098FC1E,
	CinemachineBrain_OnSceneLoaded_mA0F14A6DD8BC5E68243E6879425E49935DBF7900,
	CinemachineBrain_OnSceneUnloaded_m623A93AF5BB2A7967B0DB47A564EBE856CFC8204,
	CinemachineBrain_Start_m851FA02E684EC0C99687B63CAA12F595C5625BF8,
	CinemachineBrain_OnGuiHandler_m8EBDE5B960F8BD057B3ACEBAB75AC10492B798D8,
	CinemachineBrain_AfterPhysics_mAD691C1010D2426873FE5A5463646DDB307B4410,
	CinemachineBrain_LateUpdate_mE2D66C0664D1B0552A07D508C9D08C6167A0F1CD,
	CinemachineBrain_ManualUpdate_m8D7A7301585B6A15E708BEA2E148B1C7F2F7A487,
	CinemachineBrain_GetEffectiveDeltaTime_m27D6E0AC28FA42C74DD804AB942F0D496D55379B,
	CinemachineBrain_UpdateVirtualCameras_mCA6172FE9872138FF4D2B3867EE7AB5BE6D47F89,
	CinemachineBrain_get_ActiveVirtualCamera_m9111F4A789B4CCE529CDDE345F8B690EFEC2C63B,
	CinemachineBrain_DeepCamBFromBlend_m982D9725A5164F9EBF00366A2D49745179A60A46,
	CinemachineBrain_get_IsBlending_mA7662615642DEFD6893E2D6872A78CEA253474B2,
	CinemachineBrain_get_ActiveBlend_m03CD7DFA8C5D537BEB972918C6F4D2BB2FDB7F15,
	CinemachineBrain_GetBrainFrame_m993AEAFCA2ACA814C76097EFF86FE895258861A5,
	CinemachineBrain_SetCameraOverride_m9B06A2796330BE39B59E4DD8E1A40EDCDA969967,
	CinemachineBrain_ReleaseCameraOverride_m83F54FD0A6837603DDCE2090AC3FDD0A0BAE30DF,
	CinemachineBrain_ProcessActiveCamera_m094A1972B629F11EB580679FEFD78076769180FF,
	CinemachineBrain_UpdateFrame0_m8FD42266AA4C2CCE09B842A5BA7362126585858B,
	CinemachineBrain_ComputeCurrentBlend_m296BA72649974D928612AFC717D7446C028F3858,
	CinemachineBrain_IsLive_mF74210376333DD9865A075E561E6E3DDED510FB2,
	CinemachineBrain_get_CurrentCameraState_mBC8B24EFB25ADD71E4E007CDD351ED790FA76243,
	CinemachineBrain_set_CurrentCameraState_m2624A063E4A16EDCC8E1F8FFB93E96F74E98882B,
	CinemachineBrain_TopCameraFromPriorityQueue_m81361016B63A4BF68BA4D85452BAE8647B90E9EF,
	CinemachineBrain_LookupBlend_mEBAE63022CC081EAF26489C7BBEC2492F32B7FDD,
	CinemachineBrain_PushStateToUnityCamera_mBD15F314BC5F547CEED4C36EEDE279E11DCADB6B,
	CinemachineBrain__ctor_m86D8371115D9B5138648C75C3135396823DD43EE,
	CinemachineBrain__cctor_mECCA7F7ABF8660A2BAB11A39B29D9923D2361DD8,
	CinemachineClearShot_get_Description_m7AF5F30369B2273697549B4E458FD3D7FE7AE694,
	CinemachineClearShot_set_LiveChild_m51685341391760EC4E1053AC1555A39A06185B1E,
	CinemachineClearShot_get_LiveChild_m0E247D53C258CE36DBF28944CD0AD8A47344C4A2,
	CinemachineClearShot_get_State_m5596F81F599D82C8FE6A5383E95D3DF4F803EF7A,
	CinemachineClearShot_IsLiveChild_m27778431D3DC199BD4A07283966ABC71F323942E,
	CinemachineClearShot_get_LookAt_mACAC39B62BB18C014CB0EE0829D37854DEEF1547,
	CinemachineClearShot_set_LookAt_mE444F2137C96A179F9A0DCCACC9D5BEC30C075D4,
	CinemachineClearShot_get_Follow_mCBA54E3955A8DEBD46828F16EAE00AA2B8678C56,
	CinemachineClearShot_set_Follow_mA1A33A5BF458CB7FE8CE965EA59F8F5335128BDE,
	CinemachineClearShot_OnTargetObjectWarped_mFA9A79ADB2FA4A94D6FD73CBF32B38DBA4E34F7D,
	CinemachineClearShot_ForceCameraPosition_m64A96229F7CD5AFC4C163184CABDE5ACED9A027B,
	CinemachineClearShot_InternalUpdateCameraState_m0E642E1D33C0F0BB0628E439A78574B381F08B29,
	CinemachineClearShot_OnEnable_m6FD19FC685EFF8D2432861E8B6FBDDA02A954220,
	CinemachineClearShot_OnDisable_mC02AEC329D9BDB5D6ADFF762B38DD7260C6780F5,
	CinemachineClearShot_OnTransformChildrenChanged_mF8891487D72C8C87FDE3AF59FC308492AFD719EA,
	CinemachineClearShot_OnGuiHandler_m62267DB468A7AB10E6834C1EAC49A795349E59FA,
	CinemachineClearShot_get_IsBlending_mA2F2B1313AB3374D1D1287D67992D756C42587DA,
	CinemachineClearShot_get_ChildCameras_m1F32604733AC3601B4843C072342F408CE19C5B6,
	CinemachineClearShot_InvalidateListOfChildren_mB0CD028BA2D3286D654F260940BBC2234A7038EB,
	CinemachineClearShot_ResetRandomization_m1876DCD195CD2865599F23957CBCCF07F9557109,
	CinemachineClearShot_UpdateListOfChildren_m37DF613332B66C99EF46A5D338356B90A1D0894E,
	CinemachineClearShot_ChooseCurrentCamera_m678A067854D8A908119247136EA38448E98C7F22,
	CinemachineClearShot_Randomize_m8B9933410E1461B3C79A0CE6C332868954306FC7,
	CinemachineClearShot_LookupBlend_mEC42F1C07A25A4D873D61AB6F6CB6C26491E4D83,
	CinemachineClearShot_OnTransitionFromCamera_mEA5216EB1E80B4DC87F35CEE0646FAF2216BFA9B,
	CinemachineClearShot_get_TransitioningFrom_m9C6A21D455B4DF835AB81F4FC5B929AF8E6228C8,
	CinemachineClearShot_set_TransitioningFrom_mBB426F06C8C9E05C7DDBCD76C6001071AB80CA3B,
	CinemachineClearShot__ctor_m5E1633DD8F3F1811A0F4CB5335B4098A691C16BA,
	CinemachineCollider_IsTargetObscured_m728B54117D657C72C3A45B15D097376B916AD081,
	CinemachineCollider_CameraWasDisplaced_mE3C7D73AC6F29D59A945EB4B6E1DFF1A407D7069,
	CinemachineCollider_GetCameraDisplacementDistance_m97DED641EC9ECB65AFAE1E0687AF9DF5A7A073BC,
	CinemachineCollider_OnValidate_mDFCD2F62D4D4C8487A1041106507A47134048FF0,
	CinemachineCollider_OnDestroy_m5CCC19D44E691B93F05BA2CFAF07B48D2EFA9091,
	CinemachineCollider_get_DebugPaths_m10FD1111E853455483AAF675CDBB7ACCF6E967EC,
	CinemachineCollider_GetMaxDampTime_m7D8E44771355BC2FD8C428861A42C21A7B90695A,
	CinemachineCollider_PostPipelineStageCallback_m91F23EE95689CCBCF63C89951CE9A4EE726F59CC,
	CinemachineCollider_PreserveLignOfSight_m91DEF8619148FAD00657A1D5A460495589CDB56C,
	CinemachineCollider_PullCameraInFrontOfNearestObstacle_m831839A6F16DC4AEE8B11341B5752D0E1402BCDE,
	CinemachineCollider_PushCameraBack_mEA413F0258A0E497FF47208E7C38D607A3E95772,
	CinemachineCollider_GetWalkingDirection_mD0BA4C78DA9671058C3E0DF9AC27661882685D1B,
	CinemachineCollider_GetPushBackDistance_m8467D939C839D655437168AE18EBA9469EFE71B8,
	CinemachineCollider_ClampRayToBounds_mDE4466A0D48B3C73C69C92A9BB69ECE3E703FA0E,
	CinemachineCollider_DestroyCollider_m9E697592872A9B4F2C5D5096CBFAA54882CEC800,
	CinemachineCollider_RespectCameraRadius_m06B1B729256E1787E9FAE46241267FA08E299D4A,
	CinemachineCollider_CheckForTargetObstructions_m525473EF0F2669CD7B83EAA3CE790B11B632D63B,
	CinemachineCollider_IsTargetOffscreen_mEBE97ED4E2F75864D24A6E055BE9133E71732E2C,
	CinemachineCollider__ctor_m3543A3A2E03D8A030138D79AAEC58065C03D2994,
	CinemachineConfiner_CameraWasDisplaced_m83D1EF33F9ED6B52144AB0D3218D2126512B408F,
	CinemachineConfiner_GetCameraDisplacementDistance_mAE964ADE185900F3A1963C8F6008C10F6E9E6975,
	CinemachineConfiner_OnValidate_mD463ED5B94F6B858300D99F45438D5F0FBD949DE,
	CinemachineConfiner_ConnectToVcam_m3DF3703EBA5E402116E0B99FA7F7B7FFDB58497C,
	CinemachineConfiner_get_IsValid_m87C7AC9111017572EEACBF7B38926E5A10F81EF5,
	CinemachineConfiner_GetMaxDampTime_m445F5B5483E8A1058DB72F4376C34FA5B66275A7,
	CinemachineConfiner_PostPipelineStageCallback_m042478453BC335A0410635B429516D39992E2BDE,
	CinemachineConfiner_InvalidatePathCache_m1C66E34112C65B4CDACC628AD8D7F8C90F45706B,
	CinemachineConfiner_ValidatePathCache_m249EEFABC4DDAD7D8CBAC54CE0C7F5CF2BF90CBE,
	CinemachineConfiner_ConfinePoint_m7AE2FFDCD682C31954A51D4F0401FCC00642660A,
	CinemachineConfiner_ConfineScreenEdges_m3EF25363525ACDADF5D9A7AFFBD5805A4B9908FA,
	CinemachineConfiner__ctor_m51000A5BAF0EEDF46F862CB2C77BCBDF41035C68,
	CinemachineDollyCart_FixedUpdate_m4D0344645368A13DE5E1902FD2409FD75EF64622,
	CinemachineDollyCart_Update_m7245871A1EF878D2225D3278616830FFDEA94632,
	CinemachineDollyCart_LateUpdate_m31652825AA7DF3A37F1FF45F7987A41FF15EB629,
	CinemachineDollyCart_SetCartPosition_mF463212396484570037D81562ED14A21ECFD746F,
	CinemachineDollyCart__ctor_m10FE44DB9AC13A98B146DF4DAAE74E0B642E5068,
	CinemachineExternalCamera_get_State_mC19729B5B332F8A68ACFF3A3AA3594610B52D7FE,
	CinemachineExternalCamera_get_LookAt_m4BBF19283ED8933F78E0A0947D31E21952029ED4,
	CinemachineExternalCamera_set_LookAt_m6B06EE0A2DF54EBCACFB4AF2FDFA7CE1FBA6956D,
	CinemachineExternalCamera_get_Follow_m8FD9C12520C69C131111698EA1C532595B2F795A,
	CinemachineExternalCamera_set_Follow_mE72DB58A3B9A095A004E9A11F5A13E07DB40DB8E,
	CinemachineExternalCamera_InternalUpdateCameraState_m51FFCDE49F3209EF2A25426838FE54BEA17736C9,
	CinemachineExternalCamera__ctor_m3F3ABDD19589BAA8C55855E465E86F94B7C21DA8,
	CinemachineFollowZoom_OnValidate_mC3D5E5866F335052F48BD2B6AA47859E9AE291DB,
	CinemachineFollowZoom_GetMaxDampTime_m7FCFDC2095BEE662F4AC60386D268C2224984F66,
	CinemachineFollowZoom_PostPipelineStageCallback_m584E4DE4F681FE16D996E5D6FBE4A17F2FF5B4B3,
	CinemachineFollowZoom__ctor_mB268F9C261AF80E1B1B8CBD60F439C7CBA594E43,
	CinemachineFreeLook_OnValidate_mE135CB8F257CA150B766E7490EDB6617686C1FC8,
	CinemachineFreeLook_GetRig_mD0E1903ADCEA69937E23407FC0837F5EED5F7D2B,
	CinemachineFreeLook_get_RigNames_m28ACE9396AC7E90228CF3E5AFB579391AEC91B26,
	CinemachineFreeLook_OnEnable_mF37DBE66B28EFDB12E5EB7E2FECDE8D387E4EA64,
	CinemachineFreeLook_UpdateInputAxisProvider_mD39FCA17EFAEAF3B386FAB2D171614DBE6878BE4,
	CinemachineFreeLook_OnDestroy_mE5A0B7181DD0B540EA62AA950FFB709B6FE37881,
	CinemachineFreeLook_OnTransformChildrenChanged_m736136F5AEFE8FCEE9AE92AC05BC9F99FBD77021,
	CinemachineFreeLook_Reset_mD2D2A20865B0566F643B934832120872678945C4,
	CinemachineFreeLook_get_PreviousStateIsValid_m5401DE3AB054991B6A5FE6234347ECE270585DE1,
	CinemachineFreeLook_set_PreviousStateIsValid_m55D8DBBB19BE26486ED23321D4F636209A4EADD3,
	CinemachineFreeLook_get_State_mC1F5503F677EFDBE8F7C13AB4861A85289B11851,
	CinemachineFreeLook_get_LookAt_mDC4E1C325D8ABCE90EA23927B556A1CEDCE2E466,
	CinemachineFreeLook_set_LookAt_m6469D5D82E61E12547F31B056318A02901320ED9,
	CinemachineFreeLook_get_Follow_mAE291B3D732A26FB2F8303A21E5B02C7B0F71AD5,
	CinemachineFreeLook_set_Follow_m60B250844E32FA860F71485B30FC96E6DFC39C12,
	CinemachineFreeLook_IsLiveChild_mE77CF2865D9484DBC51179C160279DE1A2AB75A0,
	CinemachineFreeLook_OnTargetObjectWarped_m9538B8833BA2618E0DFFB92D2D5E21EBE2F6F378,
	CinemachineFreeLook_ForceCameraPosition_m61E084EAFA63BD5901D9471DBECA196063CD2BCF,
	CinemachineFreeLook_InternalUpdateCameraState_m4BEF8106D7C7379527BED810D348A1AEE7B456E4,
	CinemachineFreeLook_OnTransitionFromCamera_m7A5C9529C4641C09776A3F5B87B9A8D698C3DE6D,
	CinemachineFreeLook_GetYAxisClosestValue_m0305399E0E68EE0A9FA2F56EFAE695517C79F584,
	CinemachineFreeLook_InvalidateRigCache_m55DF47CBD6057175CBC0513574054639D51D6C7E,
	CinemachineFreeLook_DestroyRigs_m46892877143B854CDA899600B23F789F092FFA79,
	CinemachineFreeLook_CreateRigs_m1B4A9DC51DCE61E3B384B49E75E94FEA50B865E6,
	CinemachineFreeLook_UpdateRigCache_m1D9A5655874FB2B2BFF82C8B4CAE75B804A9D458,
	CinemachineFreeLook_LocateExistingRigs_mFA72C01A434055FF70E58504CBE649C3A19A935E,
	CinemachineFreeLook_get_CachedXAxisHeading_m7B1719BF031EED297D56A9DB32C2F63C018CB636,
	CinemachineFreeLook_set_CachedXAxisHeading_m11AEDBEB4865CFECA9235C8D3320B45DE0EC56C1,
	CinemachineFreeLook_UpdateXAxisHeading_mC7FB1633258C9ADCBE6D379B3865D1DFCB696088,
	CinemachineFreeLook_PushSettingsToRigs_mEEA5AE1B6B7E64CD3E52DAD1F020AF52C2D5C030,
	CinemachineFreeLook_GetYAxisValue_m82E8DA8F7257DEA0BFBFCC41FDB2E214907A9C88,
	CinemachineFreeLook_CalculateNewState_mDEC0D03EDD0F2C9521E25A5E6FCFBE66049E3869,
	CinemachineFreeLook_GetLocalPositionForCameraFromInput_m30BECF828556595138D0AE9908D6009E5BB0E7EE,
	CinemachineFreeLook_UpdateCachedSpline_m1275143847991676F4E0F292FC8CFCD0CE89E382,
	CinemachineFreeLook__ctor_m04F403D8675C975D63009E36A843B28BBD0DDE3E,
	CinemachineMixingCamera_GetWeight_mC56767C284E7B6C5441789F5D7022B9EC93342E6,
	CinemachineMixingCamera_SetWeight_mD8CB5271CD81FB934D08D156797DF143BD58DA7A,
	CinemachineMixingCamera_GetWeight_mD30103E9B0B8B54EEAB6A07179BE0688B8A18C6B,
	CinemachineMixingCamera_SetWeight_mB1C14E27249BB10421D396CCFEF41D8E18A7CDB3,
	CinemachineMixingCamera_set_LiveChild_m2CAA747551619F08D9AF611F73E8740655A64296,
	CinemachineMixingCamera_get_LiveChild_m3D4BAA0AB4486CFA6DEF9EAC84CAAD32FA78EA95,
	CinemachineMixingCamera_get_State_m58D60DAFE877B686344651AF345BA29EB84CA8CC,
	CinemachineMixingCamera_get_LookAt_m455A20326F89344D9D2B005BEDED109EB439088B,
	CinemachineMixingCamera_set_LookAt_m93815AF154ABAC9FF37C7EE237BDFDABFC1CAFB3,
	CinemachineMixingCamera_get_Follow_m8CCF58027181B96B84CB8EFD681D072E585FBA8E,
	CinemachineMixingCamera_set_Follow_m1ECE7574D20C273C49204FE5B775EC85B2605210,
	CinemachineMixingCamera_OnTargetObjectWarped_mADD9E1BD4142606182E1E3BC9F9D204A981ED905,
	CinemachineMixingCamera_ForceCameraPosition_mF1729BA8B700A249B80DE3EF66451DD422AEFD98,
	CinemachineMixingCamera_OnEnable_mB327FAC23649E787522822C97B2BAAA8B0B01011,
	CinemachineMixingCamera_OnTransformChildrenChanged_m78AE7E56D39CB09C2A55DB891DCE4C0D405B3A3B,
	CinemachineMixingCamera_OnValidate_m66D4D52438E5171467EDA22E164B64BA590AA6E5,
	CinemachineMixingCamera_IsLiveChild_m4E66C3C7A8A5F20C26E4E8519D3590E86F328613,
	CinemachineMixingCamera_get_ChildCameras_m17AAB894A5692CADB6B886AE1823D0007895FB53,
	CinemachineMixingCamera_InvalidateListOfChildren_m18EC553FC321BD26E1FDEE748A9D6398EC7F6B3D,
	CinemachineMixingCamera_ValidateListOfChildren_m0592C962C4CF7089FE842F109D0CD3476410B5CB,
	CinemachineMixingCamera_OnTransitionFromCamera_mA2504937FEC4E030494B431DB73A8FB2801E40CC,
	CinemachineMixingCamera_InternalUpdateCameraState_m95CC38FD924BF718EF4DC7E94B6259E348129112,
	CinemachineMixingCamera__ctor_m5EDF2B338827BF9600E05C360499BB6C8C06E04F,
	CinemachinePath_get_MinPos_m44196276E27917CFAA83FCB6805385F0F49B68E6,
	CinemachinePath_get_MaxPos_m19CBE9ADEA5F1C8153554117E936EE73430A1B7A,
	CinemachinePath_get_Looped_mDC5688C64BEAD83BB772379AF6A94B3D69724F5E,
	CinemachinePath_Reset_mDBB3432FB87DC834F93DC9FFE56204F059186030,
	CinemachinePath_get_DistanceCacheSampleStepsPerSegment_m040784C32B8D4D2D119AB9C189B7761FEAE717AD,
	CinemachinePath_GetBoundingIndices_m907FB06C7E158858C9828D4228AC5317A500B107,
	CinemachinePath_EvaluatePosition_m748123187AAE027319421C5A040783252BA333EB,
	CinemachinePath_EvaluateTangent_m58EFD2AF91AACB4716EF1142DA729FE99A3C4680,
	CinemachinePath_EvaluateOrientation_mC2FC02F92747630BBBC1CAF8E388A50D9701C610,
	CinemachinePath_OnValidate_mA799B5C87BE67DD6CD5A94ED498AB1313E7247A5,
	CinemachinePath__ctor_m29E35B45E4AF67EC3D12CED0F10D7C9014115765,
	CinemachinePipeline__ctor_mA25F961124A6357A5F945EED40D0FBD495840695,
	CinemachinePixelPerfect_PostPipelineStageCallback_mD4F59744645E787D73375AE345486512EF2C284A,
	CinemachinePixelPerfect__ctor_m3AFA2D3FFAB18B940EE356FD8FE96724CBCFD987,
	CinemachineSmoothPath_get_MinPos_m6E0E2A097F67A6B10D6CAC35922DA832B7192598,
	CinemachineSmoothPath_get_MaxPos_m47FAC15FD184422858C94D12FB59C0DF68196B9A,
	CinemachineSmoothPath_get_Looped_m581212992BAC29DDBA308B93A7E078EA7757BEFB,
	CinemachineSmoothPath_get_DistanceCacheSampleStepsPerSegment_m1B87916ED182DE5DF0033DFD586A9205E087C8EA,
	CinemachineSmoothPath_OnValidate_m0D0A65B796AA7D6014FF0FC2B2171EA5DB0DD422,
	CinemachineSmoothPath_Reset_m667726E5707A48BA067A7A7133857087FDC4058E,
	CinemachineSmoothPath_InvalidateDistanceCache_mC7B4228D400267E0F50D1F8E65696DFE40D28F55,
	CinemachineSmoothPath_UpdateControlPoints_m2F8ADDDCC7E141ED441095D92EA8723A6C2380D6,
	CinemachineSmoothPath_GetBoundingIndices_mE692833D63163F7B69AD841A2EA29D7F4A9BE752,
	CinemachineSmoothPath_EvaluatePosition_mCCAABE1DD14E499B981C439C9F30C68F21A66100,
	CinemachineSmoothPath_EvaluateTangent_m0D0D59143BB5132ABD5433E90817F44B302C6B26,
	CinemachineSmoothPath_EvaluateOrientation_mEC5A8EA90524DE4125735E85D9FCC5080D8B065B,
	CinemachineSmoothPath_RollAroundForward_m6D915BAFDE9ECFAC37C521C4F662D68134417065,
	CinemachineSmoothPath__ctor_m45C209574B2FCAE3239F335EF383D4D513DB7623,
	CinemachineStateDrivenCamera_get_Description_m721AB0951987E2034EA458440177C8EF9528CAD5,
	CinemachineStateDrivenCamera_set_LiveChild_m58CFBD5BCD7718A20DB92DFCB57407A51DB967AE,
	CinemachineStateDrivenCamera_get_LiveChild_m4FE60C58C46FDB216A5B65BE67166D2715711A3A,
	CinemachineStateDrivenCamera_IsLiveChild_mDB2DC4068402D3D55B40D792828EBB8C32A083E3,
	CinemachineStateDrivenCamera_get_State_m5A79A831DF33719426266F8DC14CE7BC74DAD1A7,
	CinemachineStateDrivenCamera_get_LookAt_m8DC447924D0D74AFE9F9EE6528A4A71640720560,
	CinemachineStateDrivenCamera_set_LookAt_m58802064EE2F513FCB7FFCA3FF421BA36CA340ED,
	CinemachineStateDrivenCamera_get_Follow_m7B3B9088B452F0AC4803FEA6C0B21BE0359E6517,
	CinemachineStateDrivenCamera_set_Follow_mDFD75630E23CC129D727B564643EE86C58314284,
	CinemachineStateDrivenCamera_OnTargetObjectWarped_mF70391759212BE63CEB7FB51B0A45B93157A14D8,
	CinemachineStateDrivenCamera_ForceCameraPosition_m29A24C9E4E02555029FD1FC6912BB3D54A35B156,
	CinemachineStateDrivenCamera_OnTransitionFromCamera_mEBE4A9F7099581DD5988F7D06E19056C906DEA19,
	CinemachineStateDrivenCamera_get_TransitioningFrom_m6D611FD16354DACC78A99F2B8E3CC13327CCF104,
	CinemachineStateDrivenCamera_set_TransitioningFrom_mC376F532563E04695BD810AFB8FF63589AD82B5C,
	CinemachineStateDrivenCamera_InternalUpdateCameraState_m15DA964B37A1A8B67ACC8D3429089D1948F3FD92,
	CinemachineStateDrivenCamera_OnEnable_m73592A142BE908F77B0AA271DAB6D3931F0985AB,
	CinemachineStateDrivenCamera_OnDisable_m0A9782361F2D03D44648E382D7CF8C43BB9C30A0,
	CinemachineStateDrivenCamera_OnTransformChildrenChanged_mC0E38B870F9476DB6863BCB16D18C36B9BBFFECD,
	CinemachineStateDrivenCamera_OnGuiHandler_mDB24B0B122B8F3CF847139FDC147B7F3CBFE3F05,
	CinemachineStateDrivenCamera_get_ChildCameras_m4C9CBF7126E384CDBBB2AAFE86108F43A2DF6E52,
	CinemachineStateDrivenCamera_get_IsBlending_mD0DC02C494368EF1946180D261E072CC70A859C5,
	CinemachineStateDrivenCamera_CreateFakeHash_m1B5D689454467E54101D56E7FC1096E4E709B80F,
	CinemachineStateDrivenCamera_LookupFakeHash_m06759C84A0584A1F9F290C5E58DFB0FF0AE4BD5B,
	CinemachineStateDrivenCamera_InvalidateListOfChildren_m09761689924E32C52613DFE05E80CD9D7FC3AA0E,
	CinemachineStateDrivenCamera_UpdateListOfChildren_mBA707781DC4090145A34A24903B7F08FD0875AF8,
	CinemachineStateDrivenCamera_ValidateInstructions_m3283C4B0462AC49AAFDBF8020BFCD8E296E7542B,
	CinemachineStateDrivenCamera_ChooseCurrentCamera_m3D70AE6707397EEE221D01F8B25119B2BC7A370F,
	CinemachineStateDrivenCamera_GetClipHash_mAD02DF3C8A12333C4D93FF1DA54D30B4DF2178CA,
	CinemachineStateDrivenCamera_LookupBlend_mD0B7CD5CF181EDDABF0EFE90C829DC5DF5262C41,
	CinemachineStateDrivenCamera__ctor_mB23005EB5EC0817BDFE10B9A1F0865DA83D3CBFE,
	CinemachineStoryboard_PostPipelineStageCallback_mCABE6FCDDBC249650661E7F9E4879D456950332B,
	CinemachineStoryboard_ConnectToVcam_m8C550061C8C0F5CF8AA3D57DFCDC41C103FDF66D,
	CinemachineStoryboard_get_CanvasName_m7B8D386FB493150485E1D44C62A7096F2F657C5F,
	CinemachineStoryboard_CameraUpdatedCallback_m234F18B313AD4C89E918AC2F4239FFE79E2C47CD,
	CinemachineStoryboard_LocateMyCanvas_mCCD4AE8516711F4F7947F1403DEC3BD31879C6B6,
	CinemachineStoryboard_CreateCanvas_m8646630AFE1182FFF350AE7277070C881913905E,
	CinemachineStoryboard_DestroyCanvas_mDAE4469DDC233DADBC9940C3C50BE2F0AE15E7A7,
	CinemachineStoryboard_PlaceImage_m2B8471FE0B239D371527BB2670785AB6B86108AF,
	CinemachineStoryboard_StaticBlendingHandler_mB063E4C83DB301BC5F947A7E6E7830C40EE663B1,
	CinemachineStoryboard_InitializeModule_m6F699FC72AEB7184BE2AEFF42BB6FC6794D44EB7,
	CinemachineStoryboard__ctor_m5B6932E31A0425FB1C6EFDE4CC048CEC1F0B89ED,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CinemachineTargetGroup_get_Transform_mADEBFE4BA9AF2FDC94C7302B1872D93B40F31586,
	CinemachineTargetGroup_get_BoundingBox_mF6801A2838567BE9DE910D45D9BF05A760646933,
	CinemachineTargetGroup_set_BoundingBox_m4E6C1E1267D257AEDBA80318354B60A655D1097C,
	CinemachineTargetGroup_get_Sphere_m3548B36218DC82389D27BAF6410BD34C1BBE75E8,
	CinemachineTargetGroup_get_IsEmpty_mA2CEE80C159101E17390EAE7A9F1E7F60ECA227C,
	CinemachineTargetGroup_AddMember_mDE00B3D9AB65CBAA2649A911C546D0D00170D67C,
	CinemachineTargetGroup_RemoveMember_mBAB8FD54B83FC8749A6709F8573FFB9B78A17E08,
	CinemachineTargetGroup_FindMember_mD60C186B1844C2FF84E3B10D0F5952A89CCD614D,
	CinemachineTargetGroup_GetWeightedBoundsForMember_m879BB7436547F7658E13FE9D4B1E9831BF6983CE,
	CinemachineTargetGroup_GetViewSpaceBoundingBox_m419CDD33E962D72D728E5351BE524B4887284BA0,
	CinemachineTargetGroup_WeightedMemberBounds_mCBA0F61AABF001E2088F03BC99CF3200FC7C7CCA,
	CinemachineTargetGroup_DoUpdate_m298B1536B6884019681B7DA4E50000ECE3B63D8E,
	CinemachineTargetGroup_CalculateAveragePosition_mF78C3AF8AAD414B79ECA6B7995BD8CEF3B51F88C,
	CinemachineTargetGroup_CalculateAverageOrientation_m4112A1C8E182CA4C8C5642F908A59FD21732E7F8,
	CinemachineTargetGroup_CalculateBoundingBox_m8FC29A766DAA5EA8D9D770A70C3BA3F33BCF9C45,
	CinemachineTargetGroup_OnValidate_m00BCA97645EBF6D84D566D10ADADE897E573D300,
	CinemachineTargetGroup_FixedUpdate_m51E54F0F8EB6C01A45EA6ADC82929B9D63A7D1C6,
	CinemachineTargetGroup_Update_m6CF5BB9923882A14E2EB426056BE160EDCB781D9,
	CinemachineTargetGroup_LateUpdate_m320382F4ADE5662C7F06D81ED7505FF0FDAE41B5,
	CinemachineTargetGroup_GetViewSpaceAngularBounds_mBCCF672D0664D37BA01D432B888F37A7665361BD,
	CinemachineTargetGroup__ctor_m59C958FBF749CEEA369DDF27BAA3E9216CA99399,
	CinemachineVirtualCamera_get_State_mF61B23491D389A88595DD95EB27E44EE09F3D40C,
	CinemachineVirtualCamera_get_LookAt_m7FA8E1F163BBB41806692C120B1A3531872E9173,
	CinemachineVirtualCamera_set_LookAt_m16EAA4A1653EAE5AC3490E2B2653E9C15856B199,
	CinemachineVirtualCamera_get_Follow_m2D4644BF8364F8EC6366E86D0E628AF7FBA8884D,
	CinemachineVirtualCamera_set_Follow_mBC7DE30C2BF4E62258116D9AA8F300A1468D0410,
	CinemachineVirtualCamera_GetMaxDampTime_m401AE8ABB66092E3E93BCADF35D846D5E44DAD16,
	CinemachineVirtualCamera_InternalUpdateCameraState_m0A8D802327119F624F26C694E6341B34D38B1057,
	CinemachineVirtualCamera_OnEnable_m05A075F14A81B8DF7362BADC9B3F5B195F912CE1,
	CinemachineVirtualCamera_OnDestroy_m69759804B4988BF64EF56B3F32DFC63BC4C5D533,
	CinemachineVirtualCamera_OnValidate_m6B4FF3C2AD8B3992E2E6759D1D72388EF013F4C5,
	CinemachineVirtualCamera_OnTransformChildrenChanged_mF04206FB649F578387FF1B5E2690862861730775,
	CinemachineVirtualCamera_Reset_mB1C37515D1DF02DDC6EBECAC6F5E8EC2DAAA0990,
	CinemachineVirtualCamera_DestroyPipeline_mBF0ACCB0E14994F96A0DA4F766E9DC4CD65298E4,
	CinemachineVirtualCamera_CreatePipeline_mFE25AD716DEA1E9468F5963DAA0252E300D1EA8D,
	CinemachineVirtualCamera_InvalidateComponentPipeline_m74BC28C9508EA3673CD8DA028883B069A94F652C,
	CinemachineVirtualCamera_GetComponentOwner_m8901A99D0106ADD7B9DF483D5A899E07C6B55DF4,
	CinemachineVirtualCamera_GetComponentPipeline_mD2C278143444B6D6CC40EE5DC5AA5B7259C67296,
	CinemachineVirtualCamera_GetCinemachineComponent_m9FA6F90B033903CAFFD1149E0A58A06313FDC7F3,
	NULL,
	NULL,
	NULL,
	CinemachineVirtualCamera_get_UserIsDragging_mCC9BCC63272BBC50DD6C1C930A1E162F2E7FB118,
	CinemachineVirtualCamera_set_UserIsDragging_mA66BB2778AD5A2D17230207CC6FE1A5055764E51,
	CinemachineVirtualCamera_UpdateComponentPipeline_m40B9D8AFC178A45C7FEE7A5E151D9232E05201AA,
	CinemachineVirtualCamera_SetFlagsForHiddenChild_m0B6CC9E477DF3FDC4A4C85B397DBC02987B8FFFF,
	CinemachineVirtualCamera_CalculateNewState_mDC69D1DC2332963E4EE05DC6B3278483DDB7E271,
	CinemachineVirtualCamera_OnTargetObjectWarped_m97A56F2EF2CAB7C830FE81D8DAF69D70302F3087,
	CinemachineVirtualCamera_ForceCameraPosition_mA54274F343A60C2D8B5D0918B113F8D52A9C096F,
	CinemachineVirtualCamera_SetStateRawPosition_mC33AAABD638BAF99907C51E241D339706F2A6591,
	CinemachineVirtualCamera_OnTransitionFromCamera_m621F8E4CE89A6CD4C718BAE9127944BBBE8A8C39,
	CinemachineVirtualCamera__ctor_mE54D1FBAC8B30DADC6D1A1FF4E7526BEF47AA9D3,
	Cinemachine3rdPersonFollow_OnValidate_mD52752FC1E0022C921AE0857A427EA108096BA83,
	Cinemachine3rdPersonFollow_Reset_m7B9D8F5575FCA0073A412D0147A5949A72D4D39B,
	Cinemachine3rdPersonFollow_get_IsValid_mA7AB0949602C57690E5DA8A590D80112BAB000DA,
	Cinemachine3rdPersonFollow_get_Stage_m1859D4E263C07EACAD8C3C899D327FC85761FFC2,
	Cinemachine3rdPersonFollow_GetMaxDampTime_m98EDF505AFFC8235F306E91EB8C2B1A867A4B641,
	Cinemachine3rdPersonFollow_MutateCameraState_m8EF4ADD2CE87316458D9B4D365FF587EDEE26C4F,
	Cinemachine3rdPersonFollow_PositionCamera_mD6357591900C0D7F3740BCE6FB061F1287630B21,
	Cinemachine3rdPersonFollow_GetRigPositions_m0B350EE139BBE08CEC35AC25DE11BB0D76B9F8E5,
	Cinemachine3rdPersonFollow_PullTowardsStartOnCollision_m59213AF7DEE90CC29F3FDBB404D283810F824333,
	Cinemachine3rdPersonFollow__ctor_m9FC063AEC945BFF7CB0D77584F0B4A09546BC805,
	CinemachineBasicMultiChannelPerlin_get_IsValid_m89FD92464853D4D80540492E7A94B293D637536E,
	CinemachineBasicMultiChannelPerlin_get_Stage_mFBFFEC86F9A8F773FA9028D684D39194F8DF042D,
	CinemachineBasicMultiChannelPerlin_MutateCameraState_m71D2179E138E53253A53FC2033BBF5DB002CB888,
	CinemachineBasicMultiChannelPerlin_ReSeed_m55B7DB6DDB8B7864790E509C07A73E263072A2C9,
	CinemachineBasicMultiChannelPerlin_Initialize_mBE33134720655F241B32247831C18F3F4AC7E7E5,
	CinemachineBasicMultiChannelPerlin__ctor_m03392D8E786B297606FC3029C2468621D0BD267A,
	CinemachineComposer_get_IsValid_mDD8A6301558F8579A65C82A84A073EF6CC9F7275,
	CinemachineComposer_get_Stage_m20189F84AF9911702526B12CB5B27411538D4663,
	CinemachineComposer_get_TrackedPoint_mBD61C246B60BC598EF2F407F11BF2162139F54B1,
	CinemachineComposer_set_TrackedPoint_m15F609367B526B54845CB4A22D1874E01B84EDFD,
	CinemachineComposer_GetLookAtPointAndSetTrackedPoint_m6191ABF0FD235956D9416A5B96C70504548D7CD0,
	CinemachineComposer_OnTargetObjectWarped_m3E15015DF195EEA065F733FC3A201F22FBBBA7C6,
	CinemachineComposer_ForceCameraPosition_m5B8C9B0D268DEE13C478EAA9F7B7A1DBB3411B90,
	CinemachineComposer_GetMaxDampTime_mF9651558C16FD35EF56B69268E44F114EB21646A,
	CinemachineComposer_PrePipelineMutateCameraState_mBEE9891FE6C2A3EA29A82BDD152C737774D0B462,
	CinemachineComposer_MutateCameraState_m500BDD47385EEE6373A5B5919D4B7B06CC798D57,
	CinemachineComposer_get_SoftGuideRect_m2B2596665A05FF432BE719AE225A570F3C83DF8C,
	CinemachineComposer_set_SoftGuideRect_mC46E102F64D6B1A70F528E2226C0935E485C183D,
	CinemachineComposer_get_HardGuideRect_m552C95A5B89097FD385E6DED3C04B53B2556A2EE,
	CinemachineComposer_set_HardGuideRect_mAB65433485E384647C3B7D5BA9BE55A841E33AB9,
	CinemachineComposer_RotateToScreenBounds_m62769940088AAC4509FEB682F5902D582B1AE6C1,
	CinemachineComposer_ClampVerticalBounds_mAEA1A39D3A98ACAA5AC36B7E3B11376E99E2E68E,
	CinemachineComposer__ctor_mA02E72656795D0813435386C46CEEB144AB29820,
	CinemachineFramingTransposer_get_SoftGuideRect_mEAA618B22D45A8C57B8A5AE984660585B0EE2D87,
	CinemachineFramingTransposer_set_SoftGuideRect_mC3076D642DBCDBC1AC725A4F1E1E090F8F1AC9EF,
	CinemachineFramingTransposer_get_HardGuideRect_mC861BBCE9D49993E237ADA9BBAC17665264A87FA,
	CinemachineFramingTransposer_set_HardGuideRect_m1138240B8F7657519AC0571ECE2E6EFB89CC634E,
	CinemachineFramingTransposer_OnValidate_mC01E2DF60BA5B6B8D678E429D2FD2C1BE20EDA79,
	CinemachineFramingTransposer_get_IsValid_mA6BEC5FF4B2BCA542CACB93FC8817DC0E222CA8B,
	CinemachineFramingTransposer_get_Stage_m46D483051C135C5A2FAA11127927B477E4C3A4B3,
	CinemachineFramingTransposer_get_BodyAppliesAfterAim_mDE58AC6238D9FFF902F3A490BE5ABEF7CCC350F0,
	CinemachineFramingTransposer_get_TrackedPoint_m7AD13AA3ED1185BE57C57925A65A457052F646B7,
	CinemachineFramingTransposer_set_TrackedPoint_m0F66F2FD792A1BC7873FAF52A9975CF2CB30DD82,
	CinemachineFramingTransposer_OnTargetObjectWarped_m363404C45AF56465366357A3C1C6CE455BDD8045,
	CinemachineFramingTransposer_ForceCameraPosition_m359218276D2C475F79427C2BBA9D880F0EF847B0,
	CinemachineFramingTransposer_GetMaxDampTime_m972BD3E7124A8630DC0C905993BBDE6D1AC9A275,
	CinemachineFramingTransposer_OnTransitionFromCamera_mB359F165B80CA2A10C19EA3AF33A9259F0A461BE,
	CinemachineFramingTransposer_get_InheritingPosition_m6FD62CC6C818D58C1BDAD0CFDB0DB17490098FAC,
	CinemachineFramingTransposer_set_InheritingPosition_mE8AC7F16BC034AC01F63BF8871A2380BA533DFEF,
	CinemachineFramingTransposer_ScreenToOrtho_mB36BB70462CD2EE36203D5AD3E4CA83D6CDDB23C,
	CinemachineFramingTransposer_OrthoOffsetToScreenBounds_m537A7A773E2161BCDBA155497EE09CE363319A92,
	CinemachineFramingTransposer_get_LastBounds_mA41F708F5427B0DCABFAD74902AD2FA131B9315A,
	CinemachineFramingTransposer_set_LastBounds_mE7C62D2CDC58E8491783977BB73EAB7C1286B76A,
	CinemachineFramingTransposer_get_LastBoundsMatrix_mE543BEE3801C0D544E132F28F45F0593AABF0BD4,
	CinemachineFramingTransposer_set_LastBoundsMatrix_m82659FE5FB87F1959EAF0BB4F3FC4A53A4FCADDD,
	CinemachineFramingTransposer_MutateCameraState_m738B55893FF0A80A26234C5CBABDF4441EA13111,
	CinemachineFramingTransposer_GetTargetHeight_mC4D0F3C7F1916B41E47FCA12F06B481A83AAF545,
	CinemachineFramingTransposer_ComputeGroupBounds_m266F186335242EE480FA0DA8D2477B9672A9441F,
	CinemachineFramingTransposer_GetScreenSpaceGroupBoundingBox_mF4E5D1B62BA2FA5EB6A3D83A77E0B3E6F2580148,
	CinemachineFramingTransposer__ctor_m43A25F96041552E3943E1A17419C76CD73DD5067,
	CinemachineGroupComposer_OnValidate_m056733D87C52B7481CB62EAC67A97465E94A344D,
	CinemachineGroupComposer_get_LastBounds_mBDD21C72B4902994C351AE2BE99CDE33790374ED,
	CinemachineGroupComposer_set_LastBounds_m65665450515CF77E6E04C5242803C9E2ED4950A6,
	CinemachineGroupComposer_get_LastBoundsMatrix_mAD7553857814F97F5B338B1090953E68487F26F8,
	CinemachineGroupComposer_set_LastBoundsMatrix_m17F3517E0D09514D674A5D2B589E02BA75916BB5,
	CinemachineGroupComposer_GetMaxDampTime_m7EFF6674345C28E480109CE58B36C3553E71BA77,
	CinemachineGroupComposer_MutateCameraState_m3F09674F5DB0D0D30F4E700F40A59EEA4827D961,
	CinemachineGroupComposer_GetTargetHeight_m765D054C90533C449002E5C506D18A980D66E48A,
	CinemachineGroupComposer_GetScreenSpaceGroupBoundingBox_mD21F1915940A7444B239E306204AC359485DA3C8,
	CinemachineGroupComposer__ctor_m7FC019C66BF7BFC724ECBE6614922A341CEAEB9F,
	CinemachineHardLockToTarget_get_IsValid_mB4B8596FAC003DDB676DA62F8791144FF82EC9FF,
	CinemachineHardLockToTarget_get_Stage_m5593A2FD90EE9EBEA068EE1D2316B2A17BB445C7,
	CinemachineHardLockToTarget_GetMaxDampTime_m9AE2387AE059EECF8F26E7F790D64B3051DDE58A,
	CinemachineHardLockToTarget_MutateCameraState_mA26502B42607E6B42316FDB154CCA0F0677D7FB2,
	CinemachineHardLockToTarget__ctor_m80D0530B0306D501FB1279AD9D5FC08C86954F39,
	CinemachineHardLookAt_get_IsValid_m14C472D0B12C8ED2F7CBEDE1463485F546FB8856,
	CinemachineHardLookAt_get_Stage_mF5E12651C246600173A452EB64701A6D385CF832,
	CinemachineHardLookAt_MutateCameraState_mC529F56FDA06226E4280449F649102B7392C4D17,
	CinemachineHardLookAt__ctor_mC6209571CD75BACFB0D27C6A4F23294C575CD139,
	CinemachineOrbitalTransposer_OnValidate_m16936FC098624F28C992EF3A43A2A30E01F24478,
	CinemachineOrbitalTransposer_UpdateHeading_m51697AD5EA097970B5E4A2257741553B45B8E8E5,
	CinemachineOrbitalTransposer_UpdateHeading_mB62BE9B437A813916796102106A15EC88B7D6D38,
	CinemachineOrbitalTransposer_OnEnable_m1009CB168A884E6799875A253AB33B9BA429FE21,
	CinemachineOrbitalTransposer_UpdateInputAxisProvider_m577FF1105D78BEA23D538257216CCA6AA3939C1D,
	CinemachineOrbitalTransposer_get_PreviousTarget_mCD7F8B212E3CF07C2B28269DBD9AEED8FFBCC36B,
	CinemachineOrbitalTransposer_set_PreviousTarget_m8C785BA96B2C5495772AB2CE5B8AC7A11B5E9B18,
	CinemachineOrbitalTransposer_OnTargetObjectWarped_m9D46C90267A97EB8DCA88B03C0ACEFFC29B1B424,
	CinemachineOrbitalTransposer_ForceCameraPosition_m2152590E3A98A5FDAAF49699DE9EF9311B00BCC4,
	CinemachineOrbitalTransposer_OnTransitionFromCamera_m28AA80DA45100E312174A830FD1AE9676548B391,
	CinemachineOrbitalTransposer_GetAxisClosestValue_m49678E8EEBDB7B18ABA126F1A53ED3DC412DF606,
	CinemachineOrbitalTransposer_get_LastHeading_m2E84E64E45CCFA5EDF4281474B39D2C2D4E77E65,
	CinemachineOrbitalTransposer_set_LastHeading_m1081AD7C55D275B8A6CD15E356C6E0896967FCF7,
	CinemachineOrbitalTransposer_MutateCameraState_m3D0B7E27178F330F093CEEE6AE93326CBDFF57AF,
	CinemachineOrbitalTransposer_GetTargetCameraPosition_mEF6CEF0A22C999B4B3C29860138A88B629EDA7EC,
	CinemachineOrbitalTransposer_GetFullName_m772DD042360A89E3FB812EEA5B8137AF4431DE9C,
	CinemachineOrbitalTransposer_GetTargetHeading_m474077AD308ACEAFFCFFE43ED36B0A645B4FA786,
	CinemachineOrbitalTransposer__ctor_m00999B24FD592B5C32C79C99C6C68B30CB456206,
	CinemachinePOV_get_IsValid_m56F4CD3C9FE5795343397325D6128B34F7282DF3,
	CinemachinePOV_get_Stage_m87C432BCA78705401251C2E0E474704E22CE6D7C,
	CinemachinePOV_OnValidate_m7AC95AEC250D1606DDE3ACDA968E7F6312BA60F7,
	CinemachinePOV_OnEnable_mD7B0A5051C115961BD8D43641B70BD2512E19B72,
	CinemachinePOV_UpdateInputAxisProvider_m47A7388954C01FFE0948F4601D4CE198BEFC221B,
	CinemachinePOV_PrePipelineMutateCameraState_m9BB2531A4EF28FD3221EB302288BACC4DE852F4A,
	CinemachinePOV_MutateCameraState_mBBA8EDDE3AD2CD0AA9AF831D81D0A14FAC4BF0E7,
	CinemachinePOV_GetRecenterTarget_mC5206D2FC5D9809E62E8A536B59700C9F4F38876,
	CinemachinePOV_ForceCameraPosition_mF4DB8EC103BCAB1AB82FF19EC542E4F6E54D041A,
	CinemachinePOV_OnTransitionFromCamera_m6BC39D7F60175A61C402C262EDC067793F0F789C,
	CinemachinePOV_SetAxesForRotation_m2FAD19EC947F4B355DED9537C8622F028F01A507,
	CinemachinePOV__ctor_m697E2E56E6B944C9E7334DCFC8AC0BF06DA6BCD0,
	CinemachineSameAsFollowTarget_get_IsValid_m1809C5E540F7537CC4286F0958FD1539EECA1125,
	CinemachineSameAsFollowTarget_get_Stage_m2113E69CBB5E0167E4A5D5B431C70DC7705B6707,
	CinemachineSameAsFollowTarget_GetMaxDampTime_m77DFBB864C5C83A91406C04F746665E4CABC45E4,
	CinemachineSameAsFollowTarget_MutateCameraState_m85AEA567E9CC87451D0024879F38BCD53C506B00,
	CinemachineSameAsFollowTarget__ctor_m81457B118206C0E0D833F0015A799194E9774814,
	CinemachineTrackedDolly_get_IsValid_m8EDE6D1E0B40C6F90871E4B95DB5E1F4DD49BB4E,
	CinemachineTrackedDolly_get_Stage_mFB4BDBA8C38A47C2E380E031DA81B0D1C3F22433,
	CinemachineTrackedDolly_GetMaxDampTime_m16C0CFB0875FEB726F78C571B4316AC7ADAC5D9C,
	CinemachineTrackedDolly_MutateCameraState_mC2D7BE38E781EDAC4B28B381BBA53F27429CB812,
	CinemachineTrackedDolly_GetCameraOrientationAtPathPoint_mEDA3B0646C44F84366FA86CD999E75DAE106CB30,
	CinemachineTrackedDolly_get_AngularDamping_mC3701A9FAAE10CE9FC4F82FC6D3593866C03B6D4,
	CinemachineTrackedDolly__ctor_mC643FD4B96CA4A08FA2BC2E3800FA9B448A65CEE,
	CinemachineTransposer_OnValidate_mBD6D72D809B998114DE4FDE462D39D9596E4EED9,
	CinemachineTransposer_get_HideOffsetInInspector_m937352B22116BAB61B21EBBF6D3417EE52F0158D,
	CinemachineTransposer_set_HideOffsetInInspector_m8C4560481CC4C6864C5F49A32C3495659E18521E,
	CinemachineTransposer_get_EffectiveOffset_m66C67B1F9882DF5B424E58F4B904ED0A3A519183,
	CinemachineTransposer_get_IsValid_m60005E62926B8E9927396938C4C980F873F91232,
	CinemachineTransposer_get_Stage_mD4AE770AE7489A2D32E847C2370E0881BB1E81FB,
	CinemachineTransposer_GetMaxDampTime_m4E1F2298C32E2EE3FE5D3ACCEE6F1C990D68F9F9,
	CinemachineTransposer_MutateCameraState_m52392553F3D657BD1825ACC8EDFE79AA520DF52C,
	CinemachineTransposer_OnTargetObjectWarped_m898C8AABB73BBF79CA0825BB3F1F1C0FA19EA9A0,
	CinemachineTransposer_ForceCameraPosition_m839D8ADF7D8EABD7D108B71DD028C85C119D56E4,
	CinemachineTransposer_InitPrevFrameStateInfo_m392AB50EFACB254C9CE86F0270ED4A9103AA753C,
	CinemachineTransposer_TrackTarget_m6681DA4BA5675F68E5EB9BB179AEF1E8A01D64D9,
	CinemachineTransposer_GetOffsetForMinimumTargetDistance_mC844A89B44991A156705B0169529FF39BE30ECC8,
	CinemachineTransposer_get_Damping_m54AE51D0991EF38C1D58A464FBE0B71E8EAA53E9,
	CinemachineTransposer_get_AngularDamping_mBBC748334418408B75EC350A2E92833FEDD11276,
	CinemachineTransposer_GetTargetCameraPosition_m1BB4ED7FA1B3BB3EABE41E73C6B46E6E39C671F7,
	CinemachineTransposer_GetReferenceOrientation_m6052EF55BF3528A668CEBE505F8E33708360F0F5,
	CinemachineTransposer__ctor_m3FA3755910D644CBE2EF94268677DCDE7C24D584,
	AxisState__ctor_mE1E3449CB695DD0B97602DA2309969235F2AE8A0_AdjustorThunk,
	AxisState_Validate_mD31D13D5FBDA48541D62D25EBA58C6615141115C_AdjustorThunk,
	AxisState_Reset_m467FB333DF4E419185F468B80CD82F75C773A3FE_AdjustorThunk,
	AxisState_SetInputAxisProvider_m7396F12E659493FD37D66F79B04CF93D4BBDA527_AdjustorThunk,
	AxisState_get_HasInputProvider_m38460D72EBD97A207B33485CA157D6D4D3193226_AdjustorThunk,
	AxisState_Update_mEA3BADC4B491D705D61357CD1ECE295FC243670A_AdjustorThunk,
	AxisState_ClampValue_m44330844584E13D1E1921B6174DD5257CDFFA960_AdjustorThunk,
	AxisState_MaxSpeedUpdate_mC53D3EABA41652F2D991263538542FA23B8FB517_AdjustorThunk,
	AxisState_GetMaxSpeed_mE2AB97681281AA228333FC67BD9AB5F8CEA640AA_AdjustorThunk,
	AxisState_get_ValueRangeLocked_mAA8A098676C624D20443DC6207F7CE4268824369_AdjustorThunk,
	AxisState_set_ValueRangeLocked_m556066F839F1D835CFB65398E5D2776E74510F2A_AdjustorThunk,
	AxisState_get_HasRecentering_m02782E465AF3A314B2586C24230C03FBD609EB12_AdjustorThunk,
	AxisState_set_HasRecentering_m30D6476F657160F87D850632F36DA226C04FCDE6_AdjustorThunk,
	CameraState_get_Lens_m8DD7FD2B8954A56E2CBD83D1EF7A77958F685893_AdjustorThunk,
	CameraState_set_Lens_mAABE6FFC1E5F9A33EE16A7B009B927ECB2F29523_AdjustorThunk,
	CameraState_get_ReferenceUp_m9A1F4A533328BABA7C81C4AD2F1E830375495B5A_AdjustorThunk,
	CameraState_set_ReferenceUp_mE156A37CA4B6BF3E8BA65A391730873572F24358_AdjustorThunk,
	CameraState_get_ReferenceLookAt_m32BCDF0492BA9AAECC597DF02676D66BF0566548_AdjustorThunk,
	CameraState_set_ReferenceLookAt_mF7CF3F3DD4D8DA16C08C4706E6C1128B48A3CEA2_AdjustorThunk,
	CameraState_get_HasLookAt_mE3BC5114383606752FDDED488732126B5644E81D_AdjustorThunk,
	CameraState_get_RawPosition_mA01BC7F842C837D49F0542A0475AE0EA9C88539D_AdjustorThunk,
	CameraState_set_RawPosition_m0E1142A79939C7AD7156986F91CD0F1D60499A31_AdjustorThunk,
	CameraState_get_RawOrientation_m61C0AC1D87FB6C869DA02458732BF6023130F163_AdjustorThunk,
	CameraState_set_RawOrientation_mF473C9D14F4C653E31B9D17B29198A0A26FB710E_AdjustorThunk,
	CameraState_get_PositionDampingBypass_m4F3CAC6077C7D9CE366DE64FDC0F76B8E4309965_AdjustorThunk,
	CameraState_set_PositionDampingBypass_m6ED6EE6829EAD07FB68F3281F682360F9E0B5707_AdjustorThunk,
	CameraState_get_ShotQuality_m3FE037E90A92A214DAEEA694D75ECF717520E285_AdjustorThunk,
	CameraState_set_ShotQuality_m02E14BA3BB2628501258190348C309AF56836E3B_AdjustorThunk,
	CameraState_get_PositionCorrection_m19DFDEC5E34379495FE563689462063CF01CC87B_AdjustorThunk,
	CameraState_set_PositionCorrection_m5A6BC8785013D7DA1B8B814BEA2FB2893C8D681B_AdjustorThunk,
	CameraState_get_OrientationCorrection_m50B2841F1C1C41B276CE76048DBE68CC355EBE9E_AdjustorThunk,
	CameraState_set_OrientationCorrection_m78B62F6D9C90041D16F969BF5C5DF5775380F4E3_AdjustorThunk,
	CameraState_get_CorrectedPosition_mFEB78C718574311BE01F52353220D8E3EC062344_AdjustorThunk,
	CameraState_get_CorrectedOrientation_mB74864040A12CF81360C263385AE1CFFFA73E9BB_AdjustorThunk,
	CameraState_get_FinalPosition_mABA119F4F7BDAB3C56B5A9D50A0A4E9F0EC5BFBA_AdjustorThunk,
	CameraState_get_FinalOrientation_m44213894D5B3665846C120EA54FD5F116FBBBC40_AdjustorThunk,
	CameraState_get_BlendHint_m787612D5DE9717F032149B538F603DA69B26FC75_AdjustorThunk,
	CameraState_set_BlendHint_mFEAA3F666F38C388C5CCF863FF3711CEEE3A0A52_AdjustorThunk,
	CameraState_get_Default_m12D560DD60BC9AC6B1A0287EF92D21BFF1C1C8A7,
	CameraState_get_NumCustomBlendables_m45122BC6F6592ACC07FD85C38B3A756FEC60A7CF_AdjustorThunk,
	CameraState_set_NumCustomBlendables_mF90E1B32FE572F25B187D449C5AEE2499AAE564F_AdjustorThunk,
	CameraState_GetCustomBlendable_mD4E4CD7E5D2F4ABF74B78B4997BEA73C65C704BF_AdjustorThunk,
	CameraState_FindCustomBlendable_mADB6FC113F422BEEA9B9DE3CCEAA69C505BEEDAC_AdjustorThunk,
	CameraState_AddCustomBlendable_mD2B67C82217C56D550713328D287282A0548CD97_AdjustorThunk,
	CameraState_Lerp_m29CBA400AE3DAD80F7B1F9B81B9758244530CB9B,
	CameraState_InterpolateFOV_m2C5E3CCFCAE4D654A2BD7F07A50F5E52EEBB8E02,
	CameraState_ApplyPosBlendHint_m9A27867615504FB4A36D503396BA10DE7603986C,
	CameraState_ApplyRotBlendHint_mECDD8502F1EB7BC1B728A7DC3247AEC7B618DDE5,
	CameraState_InterpolatePosition_m731CF3321931B836BFF7D6025001E0DBDBBF8341_AdjustorThunk,
	CameraState__cctor_m9FC1441CCCB6B5F891327B1F238C4B26FEC06760,
	CinemachineBlend_get_CamA_m84EE61BF64BEBAA6DD45591F1D6E727B894DAC91,
	CinemachineBlend_set_CamA_m5E656E137DE95F70ADF349416BDF9845358143BF,
	CinemachineBlend_get_CamB_m81ADE44158093EBCB50F04D90A1DD775FC02C4A7,
	CinemachineBlend_set_CamB_m502F49F7663036661B7C21945F58ED2C584308EA,
	CinemachineBlend_get_BlendCurve_m6A1FF79078DEA51B8343A4135E7A5E002D5D13C6,
	CinemachineBlend_set_BlendCurve_m1C92DE13808FD00C1AE25E8D2AA898B82E77129C,
	CinemachineBlend_get_TimeInBlend_mFA561FA319D53F2A245E6D14A67F10356FDE9502,
	CinemachineBlend_set_TimeInBlend_mCB11D4F786D1D2201521E1C5E43FBAA7CF77202E,
	CinemachineBlend_get_BlendWeight_mCCA9907E0F251FB96CCC75DE16EB76359E69D392,
	CinemachineBlend_get_IsValid_m55FFFA5BC32710DA0EF7CA8DBD7B0303D562D0D2,
	CinemachineBlend_get_Duration_mB9E2A918F60A7F8BFFADB38BE2D51455FECDF7E4,
	CinemachineBlend_set_Duration_m6624099445533093B65C3E92C25060E2C5B2692B,
	CinemachineBlend_get_IsComplete_m3FF0BF1A998D7E09ED0FCBEA109C9BEE7721CA50,
	CinemachineBlend_get_Description_m4096D0C82956E1009FA82A07FA6BB184FD5EBC59,
	CinemachineBlend_Uses_mE5C14AEF4BE8C61F17564F4F5DA84831449B6F4B,
	CinemachineBlend__ctor_mB06EF56D92F3900609669689E8820647EE84B5A3,
	CinemachineBlend_UpdateCameraState_m4B58F6808D5B9494A583E9C0CBDC4841CBEB99E1,
	CinemachineBlend_get_State_m353325CD92B13EF46EAF00985769217EA4F98FA1,
	CinemachineBlendDefinition_get_BlendTime_m2185E8662569BE0201996EAA3AC55C1A095CA5E3_AdjustorThunk,
	CinemachineBlendDefinition__ctor_m51379366ABFBFF4642735E6C843F54CF45D642CF_AdjustorThunk,
	CinemachineBlendDefinition_CreateStandardCurves_m4877FF63D3A4E8933F6817ECAEB9B500B9A3D56B_AdjustorThunk,
	CinemachineBlendDefinition_get_BlendCurve_m547D15706E83EACB4DE888750C0728BDE5974873_AdjustorThunk,
	StaticPointVirtualCamera__ctor_mAC0BFA55F9A05C87AFAFC15C1282DCF7A88F7330,
	StaticPointVirtualCamera_SetState_m0111F6AAC091400D8554DFCD60258C958D241933,
	StaticPointVirtualCamera_get_Name_m88CDC311CAE2371482E697C343C5D364D3921FBA,
	StaticPointVirtualCamera_set_Name_mC42E291C5240205CAE873C773EA2B4D1AEBCBA38,
	StaticPointVirtualCamera_get_Description_mD42A5CEF974DE56D2F2ADEE0D041A51FAA24FDA8,
	StaticPointVirtualCamera_get_Priority_mD186335682BAEEA3BDBB50BA6667DC287FAFAF55,
	StaticPointVirtualCamera_set_Priority_m1200B4DCA10859C74244CBA6D6619222450613A4,
	StaticPointVirtualCamera_get_LookAt_m81DE46064CF375735C542138F35390F99692F864,
	StaticPointVirtualCamera_set_LookAt_m0AB6CA2B5FCE282A9D34CF1F90D6B53E538921D3,
	StaticPointVirtualCamera_get_Follow_m5C80C9614891CEA38FD1C386B5EA6A0A5D2D856C,
	StaticPointVirtualCamera_set_Follow_m607FEDDF53E09CD16CA022F1E55783558FA71746,
	StaticPointVirtualCamera_get_State_m4864EB89CDE70665713ADCF80A4612B5BDE43980,
	StaticPointVirtualCamera_set_State_mC75EE398CBB9A6BE8054F5CD5C4AF90982EEF670,
	StaticPointVirtualCamera_get_VirtualCameraGameObject_mE9318C1A3D5D4779A2D20ECC5FE32C2872E8059E,
	StaticPointVirtualCamera_get_IsValid_m207DE6EDCE733D57C032075ED3FEE27A0DA5EDA4,
	StaticPointVirtualCamera_get_ParentCamera_m939FE729B7EEC40DA987EA842094EF2D2D660B0E,
	StaticPointVirtualCamera_IsLiveChild_mE99E5559C21364521C4DF662E25EC8CA3300AD45,
	StaticPointVirtualCamera_UpdateCameraState_m032CCA1E862B142F48323104B4785597D6F1BE50,
	StaticPointVirtualCamera_InternalUpdateCameraState_m1B0FEA4EB03147B15FDA4D1B8BC57F1259BB4008,
	StaticPointVirtualCamera_OnTransitionFromCamera_m9B762A7A6E09D9F4B670045857761C91EFC28823,
	StaticPointVirtualCamera_OnTargetObjectWarped_m41F5BB8D4A13B4B4D72A8B764E61A077F8CD167F,
	BlendSourceVirtualCamera__ctor_m762CFEB65D584FC854F9653CF1A97444FF86E08B,
	BlendSourceVirtualCamera_get_Blend_mB5C0C8918EA30ABEE4F85F1BB493075EFF0F1B60,
	BlendSourceVirtualCamera_set_Blend_m2EBC2E6A8F75FF3F416F0FE2583DA24E6320FEFA,
	BlendSourceVirtualCamera_get_Name_m4F4C48F79D68A9E15606415175DD1067B950677C,
	BlendSourceVirtualCamera_get_Description_m3B5EA1CECACCF4EA3B337E1DEA134DE4F87234C5,
	BlendSourceVirtualCamera_get_Priority_m043ABE54F59106B010EEBC2F48AEF70E82AFBF92,
	BlendSourceVirtualCamera_set_Priority_mC7108E9EAC45C4F8492791A250F72100A044508C,
	BlendSourceVirtualCamera_get_LookAt_m923B7FD1549B3E1090A3ACBB9E51A28A195D7813,
	BlendSourceVirtualCamera_set_LookAt_m4D4DB97225E4779DBE60447EF5E89A8EA91CEDFC,
	BlendSourceVirtualCamera_get_Follow_m2AFD8A2446B3DD4C713C4BE180974AEA67F27B7C,
	BlendSourceVirtualCamera_set_Follow_m24D9B623C684CD670659A4E36371C78007DEE55A,
	BlendSourceVirtualCamera_get_State_mA0FD90B6B6D4FF668604E9B199E4DBB6299D28D8,
	BlendSourceVirtualCamera_set_State_m1939F89FAA80BDCB54AA3983EA6DDCB582E1C6BB,
	BlendSourceVirtualCamera_get_VirtualCameraGameObject_mFA88FE034A5AD685D2E797CD21050EEF5FE3E2AB,
	BlendSourceVirtualCamera_get_IsValid_m4D11A4E0F85913145D907D6DF092E653D3BCB272,
	BlendSourceVirtualCamera_get_ParentCamera_mAAB7D1922FEB01F0D76E175DFF5F588B3557B46D,
	BlendSourceVirtualCamera_IsLiveChild_m5D3C8B7EA632D8E40D2D5B75F43B762524A3D8BB,
	BlendSourceVirtualCamera_CalculateNewState_mA5EA36A4D37412F1B2B14CFA7E7C1478CACEEF5D,
	BlendSourceVirtualCamera_UpdateCameraState_m7B24A298453FCB56F8B840E7DA846270F621AE55,
	BlendSourceVirtualCamera_InternalUpdateCameraState_m4E07980798FF47304F5A3A420EDDFD99E8F7B62F,
	BlendSourceVirtualCamera_OnTransitionFromCamera_mEACC986DA2FD0B5ECA68773558FC33504FB32947,
	BlendSourceVirtualCamera_OnTargetObjectWarped_mBA61A40425AE0741B93ABEC054F616B6E7C39A4C,
	CinemachineBlenderSettings_GetBlendForVirtualCameras_m83B852A5B14C8ED39E2FC581D3BB11528FD3B565,
	CinemachineBlenderSettings__ctor_m8548E0C3CD5CBF25ADEE8574A5258A021D1E1A07,
	CinemachineComponentBase_get_VirtualCamera_mDDC4BEDF77A93F4C25C2E62CBF96542ABB6FE3BA,
	CinemachineComponentBase_get_FollowTarget_m6A52B9EAC2F1B1DD8D8F901A48F52A296B4715AC,
	CinemachineComponentBase_get_LookAtTarget_m0B8D7462A7C631E082634733954374BD9C030F70,
	CinemachineComponentBase_UpdateFollowTargetCache_m8047A77301A9616719C733A8D394D881FB78BA0B,
	CinemachineComponentBase_get_AbstractFollowTargetGroup_m3A97181333E7E463488F030F83D72D4D671946D1,
	CinemachineComponentBase_get_FollowTargetGroup_m7AFAB2E9C70EC126379938A1FCFC90B14EC20472,
	CinemachineComponentBase_get_FollowTargetPosition_mF3A92D2EE8A07BC0E1FC820AFAA5F4CC24CD1C94,
	CinemachineComponentBase_get_FollowTargetRotation_m63FA12EC6372FC0D1D4C0224C86AD054EA31387F,
	CinemachineComponentBase_UpdateLookAtTargetCache_m0E7E8C9C13122A00F3506B5094A71A22DD001DE6,
	CinemachineComponentBase_get_AbstractLookAtTargetGroup_m09E391BC22E9B714A1A18DC19BEF1E445A39AAA8,
	CinemachineComponentBase_get_LookAtTargetGroup_mF5DE59F602311812B2A1B3EC112ECB26DB0585BA,
	CinemachineComponentBase_get_LookAtTargetPosition_m276755F157FCDC7F0933FF7E965826B6B782031B,
	CinemachineComponentBase_get_LookAtTargetRotation_mCCBCCE7A00B6FECC898C11A787FB18432EF38A86,
	CinemachineComponentBase_get_VcamState_m0F36DA00A9FF33209646471FDF6F7EC6F7DF6B80,
	NULL,
	CinemachineComponentBase_PrePipelineMutateCameraState_mAFE097E8C3220CE39BEFFFB48BDF31779A6C68D0,
	NULL,
	CinemachineComponentBase_get_BodyAppliesAfterAim_mE51BED341B65934E6CA3D8AE31A4F84B2525F52A,
	NULL,
	CinemachineComponentBase_OnTransitionFromCamera_m9DD4DF577144AF4CEA69C855EAA324D1168EBBE4,
	CinemachineComponentBase_OnTargetObjectWarped_m68C3CCD5A93FF2DD4013F33DDC1204A97B54A701,
	CinemachineComponentBase_ForceCameraPosition_mFDFA0AE6EA6C4E03EAB878E392AD312AAD454EF4,
	CinemachineComponentBase_GetMaxDampTime_m630233212BCB908E0F9EF150C2FDF5559808691F,
	CinemachineComponentBase__ctor_mF80CD1194482BC499205396A8622FAE20F5B75D4,
	CinemachineCore_get_Instance_mCD8E65EBCBB58BEDC6FD0C503AB9E866B76AFA83,
	CinemachineCore_get_DeltaTime_m8AC61BA9F0163DFE1A3D0FC5C40937B7722EB883,
	CinemachineCore_get_CurrentTime_mBD3A55B23004CB425D9297086BC20D7C55797625,
	CinemachineCore_get_BrainCount_mA544A424A3E3FC613955E2D60CA93484BC97616C,
	CinemachineCore_GetActiveBrain_m99FB4BE86B83C680EB414B5D1770908EA7ADF558,
	CinemachineCore_AddActiveBrain_m0BD0B7F334ABB98A322EACBA8285BD164D6E69AB,
	CinemachineCore_RemoveActiveBrain_m1FF228AA890EFDF236F0E434A1C88701A66BAE15,
	CinemachineCore_get_VirtualCameraCount_m09675B5895A728AC31A0892F5343264CB34FE708,
	CinemachineCore_GetVirtualCamera_m648982BBF286DB719899EB96C4E7FF17B1B5C86C,
	CinemachineCore_AddActiveCamera_m15B0C7AD4C1A0F46FC24A1121B399D80F7026DB7,
	CinemachineCore_RemoveActiveCamera_mD28005289E4D2F4000E8121243A97DCE8922B4C1,
	CinemachineCore_CameraDestroyed_m9A825D47C357F36DABCC51C466E0704BD49E13EB,
	CinemachineCore_CameraEnabled_m5DC7D833542C8CEA753704CE9026C4CE9A00EAC6,
	CinemachineCore_CameraDisabled_m9B1E9D658D5C6090F2C85A82C013908DC99A380E,
	CinemachineCore_get_FixedFrameCount_m119017A9C55B62668AFD1AE6D209A1E9B21210C8,
	CinemachineCore_set_FixedFrameCount_m814A0AC94BD3C5FEC3CEB31390AFC79D7F664F6D,
	CinemachineCore_UpdateAllActiveVirtualCameras_mCEAF2622091B0DC36A26A844C7C6022BF3C40A51,
	CinemachineCore_UpdateVirtualCamera_m937B1B00C50FDEFC1C9AE346DF37A0694D04F9EF,
	CinemachineCore_InitializeModule_m9605C793013867D1CCFA4CE04C6673E6665B6F82,
	CinemachineCore_get_CurrentUpdateFilter_m6FC774F24C226A7BACD909FB796DC1406A5EDCD0,
	CinemachineCore_set_CurrentUpdateFilter_m3E96AD239CF49A028CF514AE0631AA05DE5E3313,
	CinemachineCore_GetUpdateTarget_m4BCCFF232B14DEDDAF22E5E526638833FA065094,
	CinemachineCore_GetVcamUpdateStatus_m2C7C238F785E1F474B1707520007D3AA42129D04,
	CinemachineCore_IsLive_m61EC3BE5D22564DD740379A88639BF368EBC1E43,
	CinemachineCore_GenerateCameraActivationEvent_m851F3990838CAAD976391EECAC4D57B1C61E938A,
	CinemachineCore_GenerateCameraCutEvent_m38E839FFCA8034AC081D9F99FBEEC15B872F14C6,
	CinemachineCore_FindPotentialTargetBrain_m5DE059E6EDDE3EF8BD7258655A61A70BD7DA6F77,
	CinemachineCore__ctor_mC1794CB6B097D4CB15080ECDB82E4F2267C1D712,
	CinemachineCore__cctor_m5F6647805E2D5EC0C7F1B86D109D21F5D66FEEA7,
	CinemachineExtension_get_VirtualCamera_m48F40B632C12E90C690465B01A667A3748761AF8,
	CinemachineExtension_Awake_m090793C691718BB30B2C702DC41A2EE51F47BE2E,
	CinemachineExtension_OnEnable_m41D46718D51487D5FD1F8C9DF9AB05831CA243A9,
	CinemachineExtension_OnDestroy_m63D31EE81830209F4127D04ED9C7021C14A13C0C,
	CinemachineExtension_EnsureStarted_m3F2553CBD100D1FC3E126F2966A6673AEE82771D,
	CinemachineExtension_ConnectToVcam_mB763D1DF3E860D7CF8392A28D47D109E261381B2,
	CinemachineExtension_PrePipelineMutateCameraStateCallback_mA26EFBE159BE7F5A906A1E7229885E49CD4D8D75,
	CinemachineExtension_InvokePostPipelineStageCallback_m54C975D864B6A6818DE9658ADC23439E45B35F9C,
	NULL,
	CinemachineExtension_OnTargetObjectWarped_m20FB23984C9395B8BF67744C1ED7832FCAAFDAAF,
	CinemachineExtension_ForceCameraPosition_m1FD206CC4FBF213FA344D8F059BDE6100FE779FF,
	CinemachineExtension_OnTransitionFromCamera_mBE45BD7A872FF8AC13C1E1EA4B59985FE9A7CD6A,
	CinemachineExtension_GetMaxDampTime_mD88B3216AEF6C76B58EBEF1ABAAC8B9018C47DE8,
	NULL,
	NULL,
	CinemachineExtension__ctor_m7331AF4105FCAFF48E3CC9A412B1953647E0BEBA,
	AxisBase_Validate_mEEA2E671C4CE0548BEA394B5598EA51929E7D33A_AdjustorThunk,
	CinemachineInputAxisDriver_Validate_m144628F55B154073CD729EE89A3F87217FC01173_AdjustorThunk,
	CinemachineInputAxisDriver_Update_mCF849BA78D16DF068F7723E78D6BC171890AB4CA_AdjustorThunk,
	CinemachineInputAxisDriver_ClampValue_m1C0996D4C9242ACB7615CDE6C7C4BE9D39B341AF_AdjustorThunk,
	CinemachineInputAxisDriver_Update_mB3570630DFFA0617C1E132A764E902F2848DF810_AdjustorThunk,
	NULL,
	NULL,
	NULL,
	CinemachinePathBase_StandardizePos_m7B0DB6BC2287BFF4EDD7B5C1351FC1570FD1C00D,
	NULL,
	NULL,
	NULL,
	CinemachinePathBase_FindClosestPoint_mB3F074A56F3054EA9D9F8B87209D5A12A305BE8E,
	CinemachinePathBase_MinUnit_mBF5FEF3F3768DD5BEF8790BDBAFD800F42E170FE,
	CinemachinePathBase_MaxUnit_m205374FE01FC307D7D7ABDC7432FED2C94561A67,
	CinemachinePathBase_StandardizeUnit_m4771C500193C929F3F7719A44D5FF8D7E7406B7B,
	CinemachinePathBase_EvaluatePositionAtUnit_mCC69EFCF35ED5B1210214A96C100E8B809FD5B85,
	CinemachinePathBase_EvaluateTangentAtUnit_mFF4C4E5806694670B0281C62E1E598350D574FE7,
	CinemachinePathBase_EvaluateOrientationAtUnit_m78B5F5388A3DD41392F335CA7DB59CA1D8B978F5,
	NULL,
	CinemachinePathBase_InvalidateDistanceCache_m630E60D7B6535CD35356161A2C4FE94CBA726C63,
	CinemachinePathBase_DistanceCacheIsValid_m5B4999C83A60EA0834AB8ACBFBFE298EE5AA6FA9,
	CinemachinePathBase_get_PathLength_m46723487D97919331857A8975C397CB25DAB319D,
	CinemachinePathBase_StandardizePathDistance_mB0DABA55052793902DC03DF700AE54A9A560A3E0,
	CinemachinePathBase_ToNativePathUnits_mDB615D10D6E1F61AF70B41A508AC8986AE59D683,
	CinemachinePathBase_FromPathNativeUnits_m7817218D78BFF77C9F0D52C41B9538E6C6DCF2EB,
	CinemachinePathBase_ResamplePath_m87F9A39480F5A2EFBC1ACB5361BD8F1F3316FD01,
	CinemachinePathBase__ctor_mA1D4CC9C83F490A407AF3B7EB143BEA58C879EEE,
	AxisStatePropertyAttribute__ctor_mE6EC085C305D367A9C13C5A8F9C71CF740CF31D4,
	OrbitalTransposerHeadingPropertyAttribute__ctor_mE270F93BA1EA61B3B8D08EEB564E23317ADC7DBA,
	LensSettingsPropertyAttribute__ctor_mD29DB77CB5CB59D292D9524BE6909CFAA0554780,
	VcamTargetPropertyAttribute__ctor_m997379231EB2F108F80DC83B01246F4E35D71570,
	CinemachineBlendDefinitionPropertyAttribute__ctor_mA08F1AA4EB4CEB0759F1C838F8E7D923A12439D7,
	SaveDuringPlayAttribute__ctor_m7E6683931B2115F1902B29FCC2B4ED8A166AE4FE,
	NoSaveDuringPlayAttribute__ctor_m999A1E82E9072D6B63A1EE6080F68AFDB15A847B,
	TagFieldAttribute__ctor_m30326F8DBA12F4CB1BE7710455DCFAE79EE3994C,
	NoiseSettingsPropertyAttribute__ctor_m5C02E6DFB9B65AA11259F8EDF2DA72DFB08DB09F,
	CinemachineEmbeddedAssetPropertyAttribute__ctor_mD6C290E553336787289444791FE7FD0E7B57126E,
	DocumentationSortingAttribute_get_Category_mFBDC5B03E1DC7E69766579396C0DE6A5B794B8C1,
	DocumentationSortingAttribute_set_Category_mEF229C6814354009B21F2401F708D041751876D8,
	DocumentationSortingAttribute__ctor_mC444D8C194E049D0E1A8A4E6F83D7D69938B4CEF,
	CinemachineVirtualCameraBase_get_ValidatingStreamVersion_mAB15E72A5D80AED2EFD0DA0BD8AB00E98030CA73,
	CinemachineVirtualCameraBase_set_ValidatingStreamVersion_m5AB3A39B6875CC5C403E49D9FFF6318CD77E6E6D,
	CinemachineVirtualCameraBase_get_FollowTargetAttachment_mC63610049FFE9F70B89E7F310C47253C90363352,
	CinemachineVirtualCameraBase_set_FollowTargetAttachment_m35C90295A253C3071DCF473D134700F3A8F6757C,
	CinemachineVirtualCameraBase_get_LookAtTargetAttachment_m54302207ED2A1A7E96A1F9DB52EC0C223754D532,
	CinemachineVirtualCameraBase_set_LookAtTargetAttachment_m344BCE5B2905887C117E70412FBE6DF6C704A995,
	CinemachineVirtualCameraBase_GetMaxDampTime_m534FD1A5F0E5B1A3F4418266045FEB5CC734C4F3,
	CinemachineVirtualCameraBase_DetachedFollowTargetDamp_mA248235BC7D1A8F9199DFEC135D8770629214BDA,
	CinemachineVirtualCameraBase_DetachedFollowTargetDamp_mFA07AB4CA8E758190A3AD4D83392619A10E19BEB,
	CinemachineVirtualCameraBase_DetachedFollowTargetDamp_m4CE171B4B2D093A57D4DA99688A0BFD8788BDA68,
	CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_m644A94A63215474706B7D1357D810F4CDF309F0A,
	CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_mD2B62A9293DA4E8913ADF89C61A98FE4F966888E,
	CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_m4F4C54F140B29348D732A4155AB228C5C9CB9DBD,
	CinemachineVirtualCameraBase_AddExtension_m687616F9DD87E599D98CA6595C522C726BE25C91,
	CinemachineVirtualCameraBase_RemoveExtension_m4F693698B2195006C3B65D6634106BC5743298BC,
	CinemachineVirtualCameraBase_InvokePostPipelineStageCallback_mD4F5668E9AB96E8C11F16EC0D3CA769D663F5F51,
	CinemachineVirtualCameraBase_InvokePrePipelineMutateCameraStateCallback_m1C96DE73EEBCA5BB20BF67FAE3201CD2FC528D8C,
	CinemachineVirtualCameraBase_InvokeOnTransitionInExtensions_mB3E9947AB53FC729921300DAA1ACEEE493894846,
	CinemachineVirtualCameraBase_get_Name_m15C2DEF15C6C85BDEB8AEE64AB915DBE173F0BA0,
	CinemachineVirtualCameraBase_get_Description_m198BF619FE868398029A2631C8D11C68F553AF63,
	CinemachineVirtualCameraBase_get_Priority_m56656A6C1F3F6EDABE61AC85E1BA8C638B470310,
	CinemachineVirtualCameraBase_set_Priority_m6C180B742F19E669D648B6D1BE4D9D9C5824962B,
	CinemachineVirtualCameraBase_ApplyPositionBlendMethod_m4CA02DB42D981721D75169ACDD7900477819EEC0,
	CinemachineVirtualCameraBase_get_VirtualCameraGameObject_mDE6EBE29EC5093FDCE5E40963BFB8E39F6C7B518,
	CinemachineVirtualCameraBase_get_IsValid_m4A8B615DDFE153258564AE9D4ED8F257E9C7E5C5,
	NULL,
	CinemachineVirtualCameraBase_get_ParentCamera_mF5286EB2177F8957BC48A0BD3A5815EB408FD60C,
	CinemachineVirtualCameraBase_IsLiveChild_m1BA561E87306CCFFA9300C53CF38C5940AD1B247,
	NULL,
	NULL,
	NULL,
	NULL,
	CinemachineVirtualCameraBase_get_PreviousStateIsValid_m9AC6D8672852D072384B03B9433FAA24B6021F35,
	CinemachineVirtualCameraBase_set_PreviousStateIsValid_m6B3E5DD2C1EA71B2BA04072A0E3505AAFB2AF008,
	CinemachineVirtualCameraBase_UpdateCameraState_mBCA1562C197A11110116B3909711D0D0EE5F1733,
	NULL,
	CinemachineVirtualCameraBase_OnTransitionFromCamera_mF18AFCD175FF50DBA6851279E6C93D0A3625618E,
	CinemachineVirtualCameraBase_OnDestroy_mFF393A0D56A6468E4A055DC86B52654763CF5C01,
	CinemachineVirtualCameraBase_OnTransformParentChanged_m30B1976A8C859FADD7DBF6508018A382A921A41D,
	CinemachineVirtualCameraBase_Start_mAC4E3C7862E1898426BD04C03F97D2CB65B3E463,
	CinemachineVirtualCameraBase_EnsureStarted_m849F12F97E34D0BB2CFAB2178B5933CB3C07155F,
	CinemachineVirtualCameraBase_GetInputAxisProvider_m7691338DE9A7FEBB16AE3BC6AD15AC61D2E4D046,
	CinemachineVirtualCameraBase_OnValidate_mE1DC3F4318A152EE8B1821DE638615477645EF55,
	CinemachineVirtualCameraBase_OnEnable_m0D02925B2AB25A5F7FB3B032332B70685FCEC035,
	CinemachineVirtualCameraBase_OnDisable_m385039B02BB5EF010B8F7CD5C8D5FED7BBE7C2D1,
	CinemachineVirtualCameraBase_Update_m947321B86273A2372CF670BF61DD8763993B63E3,
	CinemachineVirtualCameraBase_UpdateSlaveStatus_m78E02F6B18B2C3FAF666F744FEA33D2357541557,
	CinemachineVirtualCameraBase_ResolveLookAt_mB4648E8AB85834A25B30DA49D5A200B74F1CC7A5,
	CinemachineVirtualCameraBase_ResolveFollow_mC991CC084D6046862E0E0D3172CF7C12FE8EC4F0,
	CinemachineVirtualCameraBase_UpdateVcamPoolStatus_m00D7E5F25FC9CC434AD143635F630984354301C9,
	CinemachineVirtualCameraBase_MoveToTopOfPrioritySubqueue_m1C3187B5E5F52FA2D2924CD3443435BCA449B631,
	CinemachineVirtualCameraBase_OnTargetObjectWarped_m7FFE5632C56D724943F8663E2A4A4B0E3B958946,
	CinemachineVirtualCameraBase_ForceCameraPosition_mBF134754EAD8C7F6DA33A8A52FFD75BEF7C8A31F,
	CinemachineVirtualCameraBase_CreateBlend_m95B3B2E83C066360A8A238BB5613E979E6369541,
	CinemachineVirtualCameraBase_PullStateFromVirtualCamera_m3F65D0956F682ED45F836E6D7950E40EB6C7D84E,
	CinemachineVirtualCameraBase__ctor_m5B13AF0337DBE27A89CAF6E30FA97CBE38823F84,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	LensSettings_get_Orthographic_mD89E6548BD05054F1ADFF7CB767ADCBA147970A0_AdjustorThunk,
	LensSettings_set_Orthographic_m17D40EA48E03E6E1D1FCBC23FCC01599BD7DEC0F_AdjustorThunk,
	LensSettings_get_SensorSize_mED4695A443BA5CD05E9BF20A8B435B9CEAF56F56_AdjustorThunk,
	LensSettings_set_SensorSize_mCF61646CF243535A7A0FE1C18D187D68F76AA849_AdjustorThunk,
	LensSettings_get_Aspect_m9CC9D04C1503CE0708B7E8D7918D51E6D105CBA6_AdjustorThunk,
	LensSettings_get_IsPhysicalCamera_m51B84703CAE764F7D3F7E581D6374080F3065891_AdjustorThunk,
	LensSettings_set_IsPhysicalCamera_mAD4EF6D6C68EC05EC70CF69FBD4B186BAEEAEE8D_AdjustorThunk,
	LensSettings_FromCamera_mB70878A0FEE612591846D38DEB0C519E62D26062,
	LensSettings_SnapshotCameraReadOnlyProperties_mBE8E0F11CA4B7B16A6FB8C6C0EAD3215BD18F952_AdjustorThunk,
	LensSettings_SnapshotCameraReadOnlyProperties_m1AF99FBBE30EEDEAAFB4F7C6EBC63C4F7BFE0E5D_AdjustorThunk,
	LensSettings__ctor_m33701EC0CE3BE15F0CC8BC926D4BB090D59FD206_AdjustorThunk,
	LensSettings_Lerp_m388C5EBB582A55DC6F8BA3E748270E68752E9582,
	LensSettings_Validate_mB36D902613DCFA1D4F31A16CDB87FE2AB23570AF_AdjustorThunk,
	LensSettings__cctor_m83C48E930BB642670AF6DCF8B5600901D03F49F5,
	NoiseSettings_GetCombinedFilterResults_m2D89EDF921D81B5476532B768C2099BDCBA047AF,
	NoiseSettings_get_SignalDuration_mA7535F6F59953F1931926872B12D6FEC56976AAF,
	NoiseSettings_GetSignal_m2E1DEBB169108D53CB89571DB973B6AE997B2B96,
	NoiseSettings__ctor_mFC841D4CF7C2F2B0B0666F32FAF561E8BE089A47,
	RuntimeUtility_DestroyObject_m6D1DDFE4299B3873067DC7E57851288F8F78F252,
	RuntimeUtility_IsPrefab_m073F89A3A5B106FD66AB93D1BE52B27612126F5F,
	RuntimeUtility_RaycastIgnoreTag_m028B24F950C8BC320919E184362FEF37DBE54D90,
	RuntimeUtility_SphereCastIgnoreTag_mF63BBA794BD68DF691D1EC863B2CA138CECA6D64,
	NULL,
	NULL,
	NULL,
	NULL,
	SignalSourceAsset__ctor_m6BD0FCB4BC617B1339DD54AF64C68D73217F15C4,
	TargetPositionCache_get_UseCache_m2A4E7042538DD9DB3384B1F655C2F5F241287ED3,
	TargetPositionCache_set_UseCache_mE9841EC91604F0D0249732E8AD668C59D46BE7E9,
	TargetPositionCache_get_CacheMode_mC4847BC1073AF20F9206798A04F0AAEB7675EF2D,
	TargetPositionCache_set_CacheMode_mA409087DB626DAE734E50B8F32E458AF8586A819,
	TargetPositionCache_get_IsRecording_m0E103654E5042F7C81BF3E8F6683767490885F63,
	TargetPositionCache_get_CurrentPlaybackTimeValid_m52161DB6E5E14903123C1C92B14D48228165B646,
	TargetPositionCache_get_IsEmpty_m05036B2EE99C645BC889DF7A34BB38CD9F701F17,
	TargetPositionCache_get_CurrentTime_m3F5821119AECD4EC85404EAD43A2165DBC2637C5,
	TargetPositionCache_set_CurrentTime_mA19CF3213984B76FA56B4E05C67CFA4C38665383,
	TargetPositionCache_get_CurrentFrame_m2319ECEB0B10124D15B040B2990DB4ACA50BB07C,
	TargetPositionCache_set_CurrentFrame_m989E6580A4D827FE06BCB7F5819794C116E4D584,
	TargetPositionCache_get_IsCameraCut_mD135E2C327DC1F9AB5D41DD29F50C60020788DA2,
	TargetPositionCache_set_IsCameraCut_m129E28E786C665E5DE495E5D1BC511A46CB30ABF,
	TargetPositionCache_get_CacheTimeRange_m26A353A12C7452C99C2FEF71809C25914C78529E,
	TargetPositionCache_get_HasHurrentTime_mD38DDBFB10FC5D0FB648E927AA8B3F2434DC547E,
	TargetPositionCache_ClearCache_mEAEE54E7ACFE79BB323DFA679789206770BE11ED,
	TargetPositionCache_CreatePlaybackCurves_m335FD074A23437FF0DDE3C70BED8EDAC5FFD8BA7,
	TargetPositionCache_GetTargetPosition_m683592ADC5C5B6597CE3A781E1BBE89A1AC9CBB1,
	TargetPositionCache_GetTargetRotation_mBAA85634FCB43634065191EB1F2217462334679D,
	TargetPositionCache__ctor_m0173991EBB133E2CDEF09D3C495FC3CE14ECE9C1,
	TargetPositionCache__cctor_mF31DF1BD5AFDB4275E7FC81F08D3A03B1EDF3FC1,
	UpdateTracker_InitializeModule_m5370F8DEE455815F90E3D955CE59DB9913D08E8F,
	UpdateTracker_UpdateTargets_mD0D8D76B9072DEA87E45FE9A440CF8324C93DEE0,
	UpdateTracker_GetPreferredUpdate_m9C3AD495B5ABFE52C7FF420870F93315B9E85219,
	UpdateTracker_OnUpdate_m5F262770C3B9222F8503D50DFE21FF7C9A902C41,
	UpdateTracker__ctor_m96110261C2684D9D4FF348FDC8C2C9ADA9107C56,
	UpdateTracker__cctor_mED7C5FD366A149F1208622A2F59654F6713B1E65,
	CinemachineInputProvider__ctor_m8777E62CF2666361F27D23EBB1C9DCEFA089DC4D,
	CinemachineTriggerAction_Filter_m24E0C2EA06B01EDE65C5ABCF0FF7412C15FBA2C9,
	CinemachineTriggerAction_InternalDoTriggerEnter_mB3988F520BC8AA59D9234D2ADF740F0B042CF468,
	CinemachineTriggerAction_InternalDoTriggerExit_mCD95F85A77DEA5ADA44117BB83D060759735B673,
	CinemachineTriggerAction_OnTriggerEnter_m96928EE1C51134E6F263AF38DF3F935B6AE9B437,
	CinemachineTriggerAction_OnTriggerExit_m064EAE63E912234D6C9FEBD36C93B365E7C254A7,
	CinemachineTriggerAction_OnCollisionEnter_m30F4858ADE6F9AE24968B6C4B53003A64C649EFB,
	CinemachineTriggerAction_OnCollisionExit_m14FC07565358A5C444DC58DEDF873F9EAB166B68,
	CinemachineTriggerAction_OnTriggerEnter2D_m761334328569C317AF12D5DC97F15FB754433A75,
	CinemachineTriggerAction_OnTriggerExit2D_mC612B5BBC49A435C39F90DA58E87C48996A21087,
	CinemachineTriggerAction_OnCollisionEnter2D_m1102D331D5FCC51055E4AC4CC6B36BE4966ADB52,
	CinemachineTriggerAction_OnCollisionExit2D_m0BF8AFA822490D1DC0E3720DA83D12AC8A34FE90,
	CinemachineTriggerAction_OnEnable_m79D396A5F205F320779F5A574F809E5CCA823EA0,
	CinemachineTriggerAction__ctor_m51FC885E516BEAA36487E1C69FC60915A4499FB8,
	GroupWeightManipulator_Start_m75C9527F322AAB1342866F0E3C9A95A47CD3ADD8,
	GroupWeightManipulator_OnValidate_m03475E611BFE066FB8D68DF536E590D7A898986D,
	GroupWeightManipulator_Update_mF97C2AA28515F222056573441CA7323BCA2A4263,
	GroupWeightManipulator_UpdateWeights_m7AD8CE24D796B0B7DBEC5B8CE80EF22791216939,
	GroupWeightManipulator__ctor_mB7E3E90299CFB064DFC0735B0D3A95F756B520DB,
	CinemachineCollisionImpulseSource_Start_m5E5E851F56BBEB52056D04A8BAA9A09628D648E9,
	CinemachineCollisionImpulseSource_OnEnable_m96262CAFC11EEA2C8E93D1C5C43550EBBBD5F5F5,
	CinemachineCollisionImpulseSource_OnCollisionEnter_m83A9DF31C999E8DADB0ECC1785811FE9E13DF31F,
	CinemachineCollisionImpulseSource_OnTriggerEnter_mF2DE5CAE0F47A55DBD93891E8BE3878CD2EC13C6,
	CinemachineCollisionImpulseSource_GetMassAndVelocity_mB95B2A247A38FC23502BFCE4ACBECBB8E6D5478B,
	CinemachineCollisionImpulseSource_GenerateImpactEvent_m02923185427CABBF74C0E310B6631551881B084D,
	CinemachineCollisionImpulseSource_OnCollisionEnter2D_m3EA8BBA135D81259C8F0C98CB504F61E86A1FCED,
	CinemachineCollisionImpulseSource_OnTriggerEnter2D_m128B0315FD9184DC00A136E4C24A19C6D3305FE3,
	CinemachineCollisionImpulseSource_GetMassAndVelocity2D_mD290AA11EAE21CDD0B3743B070AD3B1C630DC2C7,
	CinemachineCollisionImpulseSource_GenerateImpactEvent2D_m7054A182B1B724BFD0BBB6F3867466449495A5A0,
	CinemachineCollisionImpulseSource__ctor_m52C884476834730DD21BA513FFE95FAF03A1EE72,
	CinemachineFixedSignal_get_SignalDuration_m45BF3B9C17DCD224D52644987797EF5AD3F2B335,
	CinemachineFixedSignal_AxisDuration_m722605DBBFEB163DC9787AD18CD8F7920121B0DC,
	CinemachineFixedSignal_GetSignal_m92E661706E11B9D9C231CE543903182387B01FA2,
	CinemachineFixedSignal_AxisValue_mADA40BCB50D24AFA3B306B3C21759DB00CB4116C,
	CinemachineFixedSignal__ctor_mBF0542616A9718A1756FDCC01BB94235B9DEE404,
	CinemachineImpulseDefinitionPropertyAttribute__ctor_mF66F03AD5A4EB4ECA78856EEAEE26142F522E1D1,
	CinemachineImpulseDefinition_OnValidate_mFA3F1DA4B88CBB26F7529483BAB1AFB7D1ACA39E,
	CinemachineImpulseDefinition_CreateEvent_m4321107CAE385B5FB027FBFF5DD5B7D5B034C783,
	CinemachineImpulseDefinition_CreateAndReturnEvent_mA242BCF220FF29B7BD481ECFD63485A8AE5F8220,
	CinemachineImpulseDefinition__ctor_mD30405D1F3CE7A681B0907945FB88F845C2FED85,
	CinemachineImpulseListener_PostPipelineStageCallback_m5DB0EB79B863014AEA4AD493E8989EB789B83119,
	CinemachineImpulseListener__ctor_m4D00191CF14DEA2304345E89ABF693D06026AF33,
	CinemachineImpulseEnvelopePropertyAttribute__ctor_m102C22E2CEE8BF51F3C95D3C751035320B1C8574,
	CinemachineImpulseChannelPropertyAttribute__ctor_mB2115A1DF97474375A0EF9E96301CF5273149443,
	CinemachineImpulseManager__ctor_m00612FBC540CE6AACDFECE7943168B27C2A3848F,
	CinemachineImpulseManager_get_Instance_m2610081DC5D98082D240CE3FD7C6C6CEAE571DE4,
	CinemachineImpulseManager_GetImpulseAt_mD63748BEEF92691CD8962594BC86D8AACC6908D6,
	CinemachineImpulseManager_get_IgnoreTimeScale_m7286B8E9A54BE18D4D002F7824057EF9B4A6F581,
	CinemachineImpulseManager_set_IgnoreTimeScale_m734F8037EA5DDBAFEFE2AE02FE1AC87AD5FD333F,
	CinemachineImpulseManager_get_CurrentTime_mE6D6E38260F7F6CA352A44825C905F3CABC331ED,
	CinemachineImpulseManager_NewImpulseEvent_mF579A9519CE81229E765EFF552B4556FE8625198,
	CinemachineImpulseManager_AddImpulseEvent_m3C54AC87600E365FB98F0A8D43B6A1A0F96EA3C7,
	CinemachineImpulseManager_Clear_mA812D41CE685AADD048C6257BBC2EF82F0022F13,
	CinemachineImpulseManager__cctor_mA7E7C7140C2AF2C42811EC72E2B137314E583114,
	CinemachineImpulseSource_OnValidate_m83C3BD911B9348F88DC2AE85D1DB974A8E10979D,
	CinemachineImpulseSource_GenerateImpulseAt_m0A99A6E18F64EB89296877D1A6816D72CB58CA3B,
	CinemachineImpulseSource_GenerateImpulse_mA0BA98729D31DAA4489F8A795460312C6AC987A0,
	CinemachineImpulseSource_GenerateImpulse_m2F8A5B9B2CB9F5A1F7E76D2034B8F6BBED59C083,
	CinemachineImpulseSource_GenerateImpulse_mED2BDD40C547E077E1DF815B796F382D4354F7FC,
	CinemachineImpulseSource__ctor_m9E80ACB84814DB64C13AD8DA4FEDAF89664D081D,
	CinemachineIndependentImpulseListener_Reset_mBCDD4E8A955637C2F86F03E77FD60522366EEF47,
	CinemachineIndependentImpulseListener_OnEnable_mB2F604C65010D97C7B9B49DE3EEEC2B2DD20595B,
	CinemachineIndependentImpulseListener_Update_mD29D193527AEFA832942DED9837FB503532A698F,
	CinemachineIndependentImpulseListener_LateUpdate_m1F8FA46BB2ABFD4EE0502A5D1A30B70E31B16971,
	CinemachineIndependentImpulseListener__ctor_m58D3A75F484AEBA326E4631720198ED751049A38,
	CinemachinePostProcessing_PostPipelineStageCallback_mBB56E45B7D4BBEAE04A420C99A3341E0EF7D1C24,
	CinemachinePostProcessing__ctor_m036C1F22C14AB44191F6715C831A6A10C39C64BF,
	CinemachineVolumeSettings__ctor_m62731AF7317EE4CE5CB2E4E624DCDE9D69EF7B06,
	CinemachineDebug_ReleaseScreenPos_mB86CBB15358DB61F1EE1FB14B1A75C22DF973EC1,
	CinemachineDebug_GetScreenPos_mDB9E3E780C465A8773B43312A6316F11789F31DB,
	CinemachineDebug_SBFromPool_mB6C8A1699C089516D0C30DB54FACEA9DE7BEBEE1,
	CinemachineDebug_ReturnToPool_mC5B15ABF0A1EAA33217EA6B204901D2817442704,
	CinemachineDebug__ctor_m34EA5A3E30773372406A3EFEFEAC4D512FBC53D1,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	GaussianWindow1D_Vector3__ctor_m9F9F4D1099F38C2011F89481C3942BCF837A8C8F,
	GaussianWindow1D_Vector3_Compute_mC47257358568DEC6D1F06A2736F9FFE72840155A,
	GaussianWindow1D_Quaternion__ctor_m42734F192A050DB0229809115A08EB5B2ACFE2B8,
	GaussianWindow1D_Quaternion_Compute_m0E7848F46F6D124039571EC9E16E07F969B5A98D,
	GaussianWindow1D_CameraRotation__ctor_m4834B72F86867A703ECCA581EA7B7D1636BAA6ED,
	GaussianWindow1D_CameraRotation_Compute_mB07D3BAA51B60DCF8DCF738916D4A8F25D2851C4,
	PositionPredictor_get_Smoothing_mB2305254F86ADC44F77B967664A836A1E523903E,
	PositionPredictor_set_Smoothing_m4882C9C588E241A637B9E16A372B03DFD486EBB1,
	PositionPredictor_IsEmpty_mA2B45EC05F649C5F9720C228BFED71E8AD5F62B5,
	PositionPredictor_ApplyTransformDelta_m77976FB10046478DA8110E153218CB9AE00132A1,
	PositionPredictor_Reset_mB44898FC7B8E9B0A7F683840935E9BA00E699ADC,
	PositionPredictor_AddPosition_m1E539B2DB83AD523581841BF1D302643CE9275B3,
	PositionPredictor_PredictPositionDelta_m19C414F8AFAFC691F2FA995D77B0C694E8EDADDD,
	PositionPredictor_PredictPosition_mCD92F4061A05A405E45399C22D8E68E9DCA739B8,
	PositionPredictor__ctor_m4D6A0B4370D8836CEF0C54F233EE351EE2A8AEFA,
	Damper_DecayConstant_m90B73FBD9EFDFDADD53456DFBA5DC3FBD2A250B4,
	Damper_DecayedRemainder_mA1A4A25180833287B1EB3305763101321F042E46,
	Damper_Damp_mA12020431103076AB69C0FC03C4C07B388AD9E27,
	Damper_Damp_m62C13BEDD585C7DE73B4BDFBC28DDA00C4F89EEE,
	Damper_Damp_m5F27E39708AA38EF9CC7D888B6F3681813C0E6F0,
	HeadingTracker__ctor_mF6B909E191467A5BD7D4B982E751ADA11C4608D3,
	HeadingTracker_get_FilterSize_mC9A740BF0831E766A9425F01A72681EF912D08E8,
	HeadingTracker_ClearHistory_mDE5209EB31B87840F52B0407996951E343711389,
	HeadingTracker_Decay_mFC85AA39B403F52067DDECD6C488EFCBB7F38BE9,
	HeadingTracker_Add_m1895E709261177B40C99111534D777A3E484D517,
	HeadingTracker_PopBottom_m22630D7ACBCF2197BD86E73F987CF15812A1D2B5,
	HeadingTracker_DecayHistory_m192F30AA8475481505746C3ACE672088F9D76DBB,
	HeadingTracker_GetReliableHeading_m14DC7D8BBE3912362DF154EC669D9406A8597EF8,
	SplineHelpers_Bezier3_m671B7D546F16979F687B01A82D9239C0FF9A6C6F,
	SplineHelpers_BezierTangent3_m59375A4F9C985BC314131BC4286A02967A2A99B6,
	SplineHelpers_Bezier1_m01DF69C839E93F6D90E4CDE0E048DC8E5CEC2AE9,
	SplineHelpers_BezierTangent1_m6F265CBD431F2BDA6DBBFB16AD818D6EFA3D7690,
	SplineHelpers_ComputeSmoothControlPoints_mCBC6D06822574DCF0525832339422BCBA6AD899B,
	SplineHelpers_ComputeSmoothControlPointsLooped_mBD24C3CF63EA1ED0D83053C14DE95515C276DD5F,
	UnityVectorExtensions_ClosestPointOnSegment_m1BC07881406AD228FC3BD25F04DEEFCD844D0F03,
	UnityVectorExtensions_ClosestPointOnSegment_m2743E36D603D1321F3BF3F0FA76618D30CF48144,
	UnityVectorExtensions_ProjectOntoPlane_m8A4C6658A16D9A9E2415D787D52AF418133790D9,
	UnityVectorExtensions_Abs_mF5BB01E967809EAD9B96646DB47CA4457CECB544,
	UnityVectorExtensions_AlmostZero_m9F538E467290B6199EA350E4639400BF9984915B,
	UnityVectorExtensions_Angle_m04A32FB43E3D540CD85EF2A061C485A0EA1848F7,
	UnityVectorExtensions_SignedAngle_mD9BC7BAFD53B8BEE637C33AF52EAB09DFA45F939,
	UnityVectorExtensions_SafeFromToRotation_mF94D5E648352AB7EAF0B22D751DED6B1E4E54BD9,
	UnityVectorExtensions_SlerpWithReferenceUp_m141B1B05C8FD1F4D0C4349E9A80BCC72604F0A58,
	UnityQuaternionExtensions_SlerpWithReferenceUp_mB984001DA18FC2FF5035301F813B132AC999F1B6,
	UnityQuaternionExtensions_Normalized_m36AE449C35F60018BD511131B87E1A63D1B7DCA2,
	UnityQuaternionExtensions_GetCameraRotationToTarget_m744FC3EC6D163C8E4E5FD27AA9B83ADF321ED70F,
	UnityQuaternionExtensions_ApplyCameraRotation_m950CF054F6A2F4868E5D333046204FB7F016D2DF,
	UnityRectExtensions_Inflated_m07D1A88B141BFE8C3DB3D24ED9045D0D5AF21EB8,
	MasterDirectorDelegate__ctor_mFC5DB393BD8432B57F3EA9E183CD4D224AD4E5B3,
	MasterDirectorDelegate_Invoke_mE703899DFD92246C6411D29992C32024398EB999,
	MasterDirectorDelegate_BeginInvoke_m67EDBDBF4F3B3BDA4AF8FDF03D0C43F6DB657E9E,
	MasterDirectorDelegate_EndInvoke_m0DEA9513CDDF240BD9616179C047000F1C5552C3,
	BrainEvent__ctor_m648F7E949F40D8EAB7019FAED3ECE88D8CAF05D7,
	VcamActivatedEvent__ctor_mA99C1BA22F69EE75141BFFBB810E1230DCFA15E6,
	BrainFrame_get_Active_mD8AA67B2ACCA6591C9DA9A495850D2145C5B0712,
	BrainFrame__ctor_mA060413F10EA79721B2D2A33D99DC1D3282831A6,
	U3CAfterPhysicsU3Ed__32__ctor_mA6C5A5508C88D026B3A525C6CD8B02F1C43CDA4C,
	U3CAfterPhysicsU3Ed__32_System_IDisposable_Dispose_m051EBB18282335A0C579BDB3DAFF72BFAABB1B2A,
	U3CAfterPhysicsU3Ed__32_MoveNext_m7E724EAB70997756F9914B75FDD882B41179D4C9,
	U3CAfterPhysicsU3Ed__32_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m44FC9408A4C7D43320E5F71D756BF14526DB5119,
	U3CAfterPhysicsU3Ed__32_System_Collections_IEnumerator_Reset_m1C4AC9CF256FD26354DCD648E11DD88D3651CED6,
	U3CAfterPhysicsU3Ed__32_System_Collections_IEnumerator_get_Current_mC062E14211D5DBC08B65BB1AB2DA18E08C8E21DB,
	U3CU3Ec__cctor_m9685B944F64D38F8A51929E1DCF7714D96EE5C6E,
	U3CU3Ec__ctor_m02E5C011A18650E911D7DE28902B36407425A1DA,
	U3CU3Ec_U3CRandomizeU3Eb__47_0_m11EDFFF61087041AA23E34C5AE7D01B6976118F9,
	VcamExtraState_AddPointToDebugPath_mFF718D5B8D9DACD1A94BAFB458A028241E0FC95B,
	VcamExtraState_ApplyDistanceSmoothing_mB2490C4B28326713F8FAECEEBC239B46BDBB853C,
	VcamExtraState_UpdateDistanceSmoothing_m75C77A914C361D02C7C0F9B73A874D309EC124B8,
	VcamExtraState_ResetDistanceSmoothing_m9DA2E009ED1BBFD18F811B5A1E0DF1BE9D91342C,
	VcamExtraState__ctor_mAD425FDD74968E2F744178F85B1C9F5FA2FA875F,
	VcamExtraState__ctor_m0EE1BF4E53FB8E8DFF70446D1A47286397ED89FD,
	VcamExtraState__ctor_m765B777C8201B5A5D21FB547AA0215538E7CD976,
	Orbit__ctor_mBDC642CE7F3E574E43895420FD0343C3199FC85A_AdjustorThunk,
	CreateRigDelegate__ctor_m4DD0C7DBDBDA591D52EA8F0328BAB450BFCF51C2,
	CreateRigDelegate_Invoke_mAD1425DD908EFF6A0D37E425A6A2503EB0C0D6F9,
	CreateRigDelegate_BeginInvoke_m3026592E9652091C21A95142D9C9840AAE61EBAD,
	CreateRigDelegate_EndInvoke_mDDDCBA482E40537F256E8B0F686EA019C7FC42F7,
	DestroyRigDelegate__ctor_m6B51E8D805DD7A663BE724FC16D490F5D0D05D69,
	DestroyRigDelegate_Invoke_mE9C9FD19BE4FD0204687FA43F0C771C3C77E11C6,
	DestroyRigDelegate_BeginInvoke_mC12BBE33DEEA306A7AE1FFD1E961069DCC252BE5,
	DestroyRigDelegate_EndInvoke_mE037D325234815525A86DF33050DE927EFCD8F22,
	Waypoint_get_AsVector4_m9CB420052E5FB5EA1681133222C5EB982BEA6BAC_AdjustorThunk,
	Waypoint_FromVector4_m1F859E37CBC871BC98DC89550A1C6B264E46FB2A,
	ParentHash__ctor_mFD2F0C557399C8A6C3798E3CDC0EB58B5E82A094_AdjustorThunk,
	CanvasInfo__ctor_mD8E59D1746FD1DC9B497D9668DE2FACB016738DE,
	CreatePipelineDelegate__ctor_mF51B89DEB4EAE7A714B49CA9BF703B8541D419A0,
	CreatePipelineDelegate_Invoke_mF25FE1D09EC7FB09C0E0EDF766B2A19BF31080E5,
	CreatePipelineDelegate_BeginInvoke_m354E9436E905807B4CCD0ACB6528D067E014E638,
	CreatePipelineDelegate_EndInvoke_m038BA53E61623D2190CBCCD6649F230C29CE89F0,
	DestroyPipelineDelegate__ctor_m3D90BC04CC0ADE49A4EE6503D20E7AB776F7A6AA,
	DestroyPipelineDelegate_Invoke_m900F828AF1A5259B1D8606DB45BD14D4CB3274E1,
	DestroyPipelineDelegate_BeginInvoke_m5E9E8B1CCB62A8EA334567CE88741B5356DE062B,
	DestroyPipelineDelegate_EndInvoke_mD018624F272E6D61432DF250DFCDAD7DC2B53BBB,
	U3CU3Ec__cctor_m575A5E831C9D536CC3AF82E75EBEE29E76D43C89,
	U3CU3Ec__ctor_mFB7EABDE6BB8BDE667A9786AC0176017ADEC9AF3,
	U3CU3Ec_U3CUpdateComponentPipelineU3Eb__41_0_mCE45F92D28AB75075C2C97D20DBDAF56CB6D1FA3,
	FovCache_UpdateCache_m2EFDABF6DAFD0ACF434A8A83F5CAB0AA4B4F3519_AdjustorThunk,
	FovCache_ScreenToFOV_m813E0A11A9BEBC417751E33DA5E18A5A0DADFF2B_AdjustorThunk,
	Heading__ctor_m27AC6DA9204C9B4856DEA05AAAD89E2400FF639A_AdjustorThunk,
	UpdateHeadingDelegate__ctor_mB9BA33C54488BC8DD418BEEF3A51DB6AF40E361B,
	UpdateHeadingDelegate_Invoke_m3A58C1E3FAF4FE5B175648FF19F95BAD57CC6330,
	UpdateHeadingDelegate_BeginInvoke_mBDCD4A90CE6D3E50F8A7A7FF3A12039EE580E4A4,
	UpdateHeadingDelegate_EndInvoke_m75EB1823E9A52B6FD0216E863677C5A357A13672,
	U3CU3Ec__cctor_m040BE18F4CF76FD237A199F900F8B2D09794FBBD,
	U3CU3Ec__ctor_m2CC55D7CF3C4815383423BEA372FB9753A747D29,
	U3CU3Ec_U3C_ctorU3Eb__35_0_m15844BD8ED7CDBED9326054C7B7C6DFAD6B2C52C,
	AutoDolly__ctor_mB22E90A64C6D9D0F6C0F6FE794446F2867E76793_AdjustorThunk,
	NULL,
	Recentering__ctor_mDFE3D3BB932AF426369B033D18AD3FDAAF26384F_AdjustorThunk,
	Recentering_Validate_mFB967BB954EFD0DD6E2315F53A3241FDC146B18A_AdjustorThunk,
	Recentering_CopyStateFrom_mE18BDABB9C0A8D71903C3173B9783435DDE64918_AdjustorThunk,
	Recentering_CancelRecentering_m49877C0EBC7D9873C40CABD8EEF245954703CEC2_AdjustorThunk,
	Recentering_RecenterNow_mB95BFD6D292191AB019A574F835AE4FB2A5ECD54_AdjustorThunk,
	Recentering_DoRecentering_mA1AB5ACE77B56D9357CBB46FB4BEAF42AED5CD6C_AdjustorThunk,
	Recentering_LegacyUpgrade_mE331A7312B51DE3F31805A89EC3E4EB9DF71567E_AdjustorThunk,
	CustomBlendable__ctor_mA7DEF75ACB9FDE678221EF6176FBD4DC4441FB07_AdjustorThunk,
	AxisInputDelegate__ctor_m55631A6E688731D441A5822CE96218E7E9CC5B01,
	AxisInputDelegate_Invoke_m860AF1CED1A9DF40081361395A2E99E5913DE2D4,
	AxisInputDelegate_BeginInvoke_mE17152E703E8CC1FD23F1699D57494CD620D559D,
	AxisInputDelegate_EndInvoke_m42BA5EAD29B364609461C59796CF1FE308942777,
	GetBlendOverrideDelegate__ctor_m0D9DFFA11AA07FC85C2903B99641E4CE9BF6DC9B,
	GetBlendOverrideDelegate_Invoke_mAE517451152A2ADCF950A31A7004F52FA64C8EE0,
	GetBlendOverrideDelegate_BeginInvoke_m4CEF86F10D8C529DD09C94310D0E70668307B360,
	GetBlendOverrideDelegate_EndInvoke_m07B62A912EE6066CE03A1D3125A0BEB2ED1AC0E4,
	UpdateStatus__ctor_mAEEB635F3C3AE9D84B9072DA75E14B098312CACD,
	Appearance__ctor_m975B387EF5A573D25BD3C5C57B0314F3C4446196,
	NoiseParams_GetValueAt_mA2C1E6FA7AE9AB3FC9A51024E0D474E5C8596610_AdjustorThunk,
	TransformNoiseParams_GetValueAt_m89FDF2289D147DC0B617426E76A78402474770CD_AdjustorThunk,
	CacheCurve_get_Count_m7BE1AE49E310A7185E449EF27D9715404DB58F4D,
	CacheCurve__ctor_m9126DDC2FF162438BEF34E60AD524A2BD74E09D8,
	CacheCurve_Add_m325C65AD39FDFBC91F4D5624B8BF7C5560B36DFF,
	CacheCurve_AddUntil_m3613245687496AC0DC18F1EB9A6328E3F8AA203F,
	CacheCurve_Evaluate_m9D2DF73C6C1AF43179910C16C2249A6205429938,
	CacheEntry_AddRawItem_m56ADB9D380E62201025B3F4B752CDD4E90970B49,
	CacheEntry_CreateCurves_m3C30DAF286804CB56B42102406ACE0BF891292EA,
	CacheEntry__ctor_mF5B26181E6FBFC00701BC6A362BEA3416815FD2B,
	TimeRange_get_IsEmpty_m0EBE2CFDA395E03444770956D336B17D2CC676D0_AdjustorThunk,
	TimeRange_Contains_m2FE15B3333F2883C0580220A5D3FDE954533A8FA_AdjustorThunk,
	TimeRange_get_Empty_m273B20F7E14B9A0670F209E17316EC4EBDD7D053,
	TimeRange_Include_m98B368672B3FAD811027079C3EA8236914D3729E_AdjustorThunk,
	UpdateStatus_get_PreferredUpdate_mF6224BC9B52B95B06ECD82F3CCDAC7B0994B9B6F,
	UpdateStatus_set_PreferredUpdate_m0D163727BB4C16214C9A22D74656ED09CEF6C929,
	UpdateStatus__ctor_mDEAE275BFECF3D63AE2A93D74EABACD19FA21724,
	UpdateStatus_OnUpdate_m22DED61941774ECFB0119BAAE3BD2C164D39D521,
	ActionSettings__ctor_mD581917562ECC8295F6278BA5AD001705F8E9035_AdjustorThunk,
	ActionSettings_Invoke_mF3E35400963944A72FD025FEF8052413056DC716_AdjustorThunk,
	SignalSource__ctor_mCB153F491DABCD71273BD63B24BF32099AEBEF80,
	SignalSource_get_SignalDuration_m361ECAF68816FA8EC16C6EF9644886A11CFAA837,
	SignalSource_GetSignal_m9A46E678A84820D6D5FC33F008DEC2DFCFB94DA1,
	EnvelopeDefinition_Default_m6048BC0ADAE235D4D0F47D57AC6F07F8031E8502,
	EnvelopeDefinition_get_Duration_m494621ABECC584E355834D287BEA915BD68A774F_AdjustorThunk,
	EnvelopeDefinition_GetValueAt_mA27AFC5D351DA50CA935ACCAB79D91F1E924C8CC_AdjustorThunk,
	EnvelopeDefinition_ChangeStopTime_mA4D7614B6F56A8E279596B52252816EB59843F23_AdjustorThunk,
	EnvelopeDefinition_Clear_m2B817953AFB7CDAA6B62AEC4A1E6A588484B554B_AdjustorThunk,
	EnvelopeDefinition_Validate_mA0464BC35544052393B17674F751FAA755051B14_AdjustorThunk,
	ImpulseEvent_get_Expired_m06944921FE1EEA9118BFAEE7F52E73280418DCA7,
	ImpulseEvent_Cancel_mA2831A11F90680EE32F4685E6311140D627C877B,
	ImpulseEvent_DistanceDecay_mF8C3C77FF46D6C2B23BE694CCA9714F76ED60036,
	ImpulseEvent_GetDecayedSignal_m973C1F0E6D32DC4DD14ECDF280FE58D14F6943EC,
	ImpulseEvent_Clear_m3FBD19A05EAC470ACE87FAC6CF8FCBBB01E278A2,
	ImpulseEvent__ctor_mBDBA49A0F06CCB22CAB3ADCFB3B62BB1EF812E53,
	OnGUIDelegate__ctor_m368CF0C4912A67D1DBDA8E1F2C2827D0163482FA,
	OnGUIDelegate_Invoke_mA31514C83F7C6B0DC124FB9C3C9AF1AE46EA3BE2,
	OnGUIDelegate_BeginInvoke_mB9DDADF15A39323C1F037853E3A73B2AB7697E33,
	OnGUIDelegate_EndInvoke_mA2E9D5AB93F6750402449BC316CB9F00CD0013F9,
	Item_Lerp_m729C3CBFCA75B42CC2799D491DEF4C17C53602DC,
	Item_get_Empty_m2209C3BE792AABD138C9A597718D01D2FF089CB3,
	TriggerEvent__ctor_m1B0E4D0D8DD5D925A7B5F502DECF073FBA41C266,
};
static const int32_t s_InvokerIndices[1097] = 
{
	1750,
	23,
	23,
	23,
	1751,
	1750,
	23,
	23,
	192,
	23,
	1327,
	1328,
	1329,
	1093,
	23,
	1335,
	27,
	23,
	114,
	23,
	1593,
	23,
	23,
	23,
	1752,
	26,
	1753,
	1750,
	23,
	14,
	26,
	14,
	425,
	1754,
	14,
	26,
	14,
	26,
	1755,
	1756,
	1757,
	14,
	26,
	1108,
	23,
	23,
	23,
	23,
	14,
	114,
	23,
	23,
	23,
	290,
	23,
	14,
	4,
	122,
	1192,
	1119,
	23,
	23,
	1758,
	1759,
	23,
	23,
	14,
	23,
	23,
	1760,
	929,
	14,
	0,
	114,
	14,
	37,
	1761,
	32,
	290,
	290,
	64,
	425,
	1754,
	1762,
	14,
	1763,
	1762,
	23,
	3,
	14,
	26,
	14,
	1754,
	425,
	14,
	26,
	14,
	26,
	1755,
	1756,
	1108,
	23,
	23,
	23,
	23,
	114,
	14,
	23,
	23,
	23,
	1701,
	28,
	1763,
	1757,
	14,
	26,
	23,
	9,
	9,
	192,
	23,
	23,
	14,
	681,
	1750,
	1765,
	1766,
	1767,
	1768,
	1769,
	1770,
	3,
	1771,
	1772,
	1772,
	23,
	9,
	192,
	23,
	31,
	114,
	681,
	1750,
	23,
	114,
	1103,
	1774,
	23,
	23,
	23,
	23,
	290,
	23,
	1754,
	14,
	26,
	14,
	26,
	1108,
	23,
	23,
	681,
	1750,
	23,
	23,
	34,
	4,
	23,
	23,
	23,
	23,
	23,
	114,
	31,
	1754,
	14,
	26,
	14,
	26,
	425,
	1755,
	1756,
	1108,
	1757,
	1775,
	23,
	23,
	28,
	23,
	1601,
	681,
	290,
	1776,
	23,
	681,
	1777,
	1124,
	23,
	23,
	1147,
	929,
	192,
	859,
	26,
	14,
	1754,
	14,
	26,
	14,
	26,
	1755,
	1756,
	23,
	23,
	23,
	425,
	14,
	23,
	23,
	1757,
	1108,
	23,
	681,
	681,
	114,
	23,
	10,
	1779,
	1124,
	1124,
	1780,
	23,
	23,
	23,
	1750,
	23,
	681,
	681,
	114,
	10,
	23,
	23,
	23,
	23,
	1779,
	1124,
	1124,
	1780,
	1780,
	23,
	14,
	26,
	14,
	425,
	1754,
	14,
	26,
	14,
	26,
	1755,
	1756,
	1757,
	14,
	26,
	1108,
	23,
	23,
	23,
	23,
	14,
	114,
	962,
	1006,
	23,
	23,
	23,
	14,
	1006,
	1763,
	23,
	1750,
	31,
	14,
	26,
	112,
	26,
	23,
	859,
	122,
	3,
	23,
	14,
	1157,
	1782,
	114,
	1783,
	1784,
	14,
	1157,
	1122,
	1782,
	114,
	1273,
	26,
	116,
	1785,
	1783,
	1786,
	23,
	1753,
	1233,
	1787,
	23,
	23,
	23,
	23,
	1784,
	23,
	1754,
	14,
	26,
	14,
	26,
	681,
	1108,
	23,
	23,
	23,
	23,
	23,
	23,
	28,
	23,
	14,
	14,
	34,
	-1,
	-1,
	-1,
	114,
	31,
	23,
	122,
	1777,
	1755,
	1756,
	1120,
	1757,
	23,
	23,
	23,
	114,
	10,
	681,
	1788,
	1788,
	676,
	1789,
	23,
	114,
	10,
	1788,
	23,
	23,
	23,
	114,
	10,
	1119,
	1120,
	1790,
	1755,
	1756,
	681,
	1788,
	1788,
	1100,
	1099,
	1100,
	1099,
	1791,
	1792,
	23,
	1100,
	1099,
	1100,
	1099,
	23,
	114,
	10,
	114,
	1119,
	1120,
	1755,
	1756,
	681,
	1795,
	114,
	31,
	1796,
	1797,
	1157,
	1122,
	1199,
	1101,
	1788,
	1798,
	1774,
	1799,
	23,
	23,
	1157,
	1122,
	1199,
	1101,
	681,
	1788,
	1798,
	1800,
	23,
	114,
	10,
	681,
	1788,
	23,
	114,
	10,
	1788,
	23,
	23,
	1801,
	1802,
	23,
	23,
	14,
	26,
	1755,
	1756,
	1795,
	1775,
	681,
	290,
	1788,
	1103,
	0,
	1803,
	23,
	114,
	10,
	23,
	23,
	23,
	1788,
	1788,
	1097,
	1756,
	1795,
	1282,
	23,
	114,
	10,
	681,
	1788,
	23,
	114,
	10,
	681,
	1788,
	1806,
	1119,
	23,
	23,
	114,
	31,
	1119,
	114,
	10,
	681,
	1788,
	1755,
	1756,
	1788,
	1808,
	1809,
	1119,
	1119,
	1103,
	1810,
	23,
	1811,
	23,
	23,
	62,
	114,
	435,
	1093,
	1812,
	681,
	114,
	31,
	114,
	31,
	1815,
	1816,
	1119,
	1120,
	1119,
	1120,
	114,
	1119,
	1120,
	1233,
	1282,
	1119,
	1120,
	681,
	290,
	1119,
	1120,
	1233,
	1282,
	1119,
	1233,
	1119,
	1233,
	10,
	32,
	1817,
	10,
	32,
	1818,
	116,
	1819,
	1820,
	1821,
	1822,
	1823,
	1824,
	3,
	14,
	26,
	14,
	26,
	14,
	26,
	681,
	290,
	681,
	114,
	681,
	290,
	114,
	14,
	9,
	1825,
	1108,
	1754,
	681,
	929,
	23,
	14,
	1826,
	1762,
	14,
	26,
	14,
	10,
	32,
	14,
	26,
	14,
	26,
	1754,
	1762,
	14,
	114,
	14,
	425,
	1108,
	1108,
	1757,
	1755,
	26,
	14,
	26,
	14,
	14,
	10,
	32,
	14,
	26,
	14,
	26,
	1754,
	1762,
	14,
	114,
	14,
	425,
	1827,
	1108,
	1108,
	1757,
	1755,
	1828,
	23,
	14,
	14,
	14,
	23,
	14,
	14,
	1119,
	1233,
	23,
	14,
	14,
	1119,
	1233,
	1754,
	114,
	1788,
	10,
	114,
	1788,
	1795,
	1755,
	1756,
	681,
	23,
	4,
	1137,
	1137,
	10,
	34,
	26,
	26,
	10,
	34,
	26,
	26,
	26,
	26,
	26,
	131,
	133,
	1829,
	1757,
	3,
	10,
	32,
	0,
	116,
	9,
	27,
	26,
	28,
	23,
	3,
	14,
	23,
	23,
	23,
	23,
	31,
	1751,
	1750,
	1750,
	1755,
	1756,
	1752,
	681,
	-1,
	-1,
	23,
	23,
	23,
	1833,
	1834,
	1833,
	681,
	681,
	114,
	1093,
	1124,
	1124,
	1780,
	1835,
	1147,
	1147,
	1675,
	1836,
	1836,
	1837,
	10,
	23,
	114,
	681,
	1093,
	1675,
	1675,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	31,
	10,
	32,
	32,
	10,
	32,
	681,
	290,
	681,
	290,
	681,
	1838,
	1790,
	1839,
	1838,
	1790,
	1839,
	26,
	26,
	1750,
	1751,
	1752,
	14,
	14,
	10,
	32,
	64,
	14,
	114,
	1754,
	14,
	425,
	14,
	26,
	14,
	26,
	114,
	31,
	1108,
	1108,
	1757,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	28,
	28,
	23,
	23,
	1755,
	1756,
	1840,
	1841,
	23,
	14,
	14,
	10,
	32,
	14,
	26,
	14,
	26,
	1754,
	14,
	114,
	14,
	425,
	1108,
	1108,
	1757,
	1755,
	114,
	31,
	1097,
	1098,
	681,
	114,
	31,
	1842,
	26,
	6,
	1843,
	1844,
	23,
	3,
	1845,
	681,
	1846,
	23,
	122,
	94,
	1848,
	1849,
	681,
	1846,
	681,
	1846,
	23,
	49,
	796,
	131,
	133,
	49,
	49,
	49,
	1137,
	1276,
	131,
	133,
	49,
	796,
	1850,
	49,
	3,
	3,
	1851,
	1852,
	23,
	3,
	3,
	133,
	95,
	133,
	23,
	3,
	23,
	9,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	1860,
	1755,
	26,
	26,
	1860,
	1755,
	23,
	681,
	192,
	1846,
	1861,
	23,
	23,
	23,
	1117,
	1862,
	23,
	1750,
	23,
	23,
	23,
	23,
	4,
	1863,
	114,
	31,
	681,
	14,
	26,
	23,
	3,
	23,
	1117,
	1120,
	290,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	1750,
	23,
	23,
	122,
	1866,
	4,
	122,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	1688,
	1867,
	1688,
	1868,
	1688,
	1869,
	681,
	290,
	114,
	1120,
	23,
	1870,
	1124,
	1124,
	23,
	389,
	1237,
	1237,
	1210,
	1871,
	32,
	10,
	23,
	387,
	1120,
	23,
	23,
	1119,
	1872,
	1872,
	1821,
	1821,
	1235,
	1235,
	1214,
	1873,
	1212,
	1134,
	1874,
	1213,
	1214,
	1875,
	1876,
	1877,
	1222,
	1878,
	1879,
	1880,
	102,
	14,
	113,
	28,
	23,
	23,
	114,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	3,
	23,
	1764,
	1120,
	1773,
	1090,
	290,
	23,
	23,
	23,
	1090,
	102,
	177,
	1778,
	28,
	102,
	26,
	177,
	26,
	1257,
	1781,
	169,
	23,
	102,
	177,
	1778,
	28,
	102,
	26,
	177,
	26,
	3,
	23,
	41,
	1793,
	1794,
	1804,
	102,
	1776,
	1805,
	192,
	3,
	23,
	1776,
	1807,
	1147,
	1813,
	23,
	6,
	23,
	23,
	1814,
	789,
	859,
	102,
	192,
	177,
	192,
	102,
	1830,
	1831,
	1832,
	23,
	23,
	1773,
	1847,
	10,
	1185,
	1853,
	1854,
	1855,
	1858,
	23,
	23,
	114,
	435,
	1850,
	290,
	10,
	32,
	1146,
	1859,
	32,
	23,
	1755,
	681,
	1846,
	1864,
	681,
	1093,
	1692,
	23,
	23,
	114,
	1692,
	1093,
	1865,
	23,
	23,
	102,
	23,
	113,
	26,
	1856,
	1857,
	23,
};
static const Il2CppTokenRangePair s_rgctxIndices[6] = 
{
	{ 0x0200005B, { 10, 7 } },
	{ 0x06000151, { 0, 1 } },
	{ 0x06000152, { 1, 2 } },
	{ 0x06000153, { 3, 1 } },
	{ 0x060002A0, { 4, 2 } },
	{ 0x060002A1, { 6, 4 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[17] = 
{
	{ (Il2CppRGCTXDataType)2, 9308 },
	{ (Il2CppRGCTXDataType)3, 15128 },
	{ (Il2CppRGCTXDataType)2, 9309 },
	{ (Il2CppRGCTXDataType)2, 11029 },
	{ (Il2CppRGCTXDataType)3, 15129 },
	{ (Il2CppRGCTXDataType)2, 9466 },
	{ (Il2CppRGCTXDataType)2, 9467 },
	{ (Il2CppRGCTXDataType)3, 15130 },
	{ (Il2CppRGCTXDataType)2, 9468 },
	{ (Il2CppRGCTXDataType)3, 15131 },
	{ (Il2CppRGCTXDataType)3, 15132 },
	{ (Il2CppRGCTXDataType)3, 15133 },
	{ (Il2CppRGCTXDataType)3, 15134 },
	{ (Il2CppRGCTXDataType)2, 11030 },
	{ (Il2CppRGCTXDataType)3, 15135 },
	{ (Il2CppRGCTXDataType)3, 15136 },
	{ (Il2CppRGCTXDataType)3, 15137 },
};
extern const Il2CppCodeGenModule g_CinemachineCodeGenModule;
const Il2CppCodeGenModule g_CinemachineCodeGenModule = 
{
	"Cinemachine.dll",
	1097,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	6,
	s_rgctxIndices,
	17,
	s_rgctxValues,
	NULL,
};
