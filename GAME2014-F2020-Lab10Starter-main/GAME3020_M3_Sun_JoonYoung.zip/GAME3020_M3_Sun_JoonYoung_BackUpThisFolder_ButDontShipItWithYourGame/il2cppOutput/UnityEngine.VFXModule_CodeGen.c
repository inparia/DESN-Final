﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.VFX.VFXExpressionValues::.ctor()
extern void VFXExpressionValues__ctor_m4B8043CAE5D33D062707D851DD4E62D9F7BB1320 ();
// 0x00000002 UnityEngine.VFX.VFXExpressionValues UnityEngine.VFX.VFXExpressionValues::CreateExpressionValuesWrapper(System.IntPtr)
extern void VFXExpressionValues_CreateExpressionValuesWrapper_mA085560E2E04D2CD8C76664FB169F227AA0A6537 ();
// 0x00000003 System.Void UnityEngine.VFX.VFXSpawnerCallbacks::OnPlay(UnityEngine.VFX.VFXSpawnerState,UnityEngine.VFX.VFXExpressionValues,UnityEngine.VFX.VisualEffect)
// 0x00000004 System.Void UnityEngine.VFX.VFXSpawnerCallbacks::OnUpdate(UnityEngine.VFX.VFXSpawnerState,UnityEngine.VFX.VFXExpressionValues,UnityEngine.VFX.VisualEffect)
// 0x00000005 System.Void UnityEngine.VFX.VFXSpawnerCallbacks::OnStop(UnityEngine.VFX.VFXSpawnerState,UnityEngine.VFX.VFXExpressionValues,UnityEngine.VFX.VisualEffect)
// 0x00000006 System.Void UnityEngine.VFX.VFXSpawnerCallbacks::.ctor()
extern void VFXSpawnerCallbacks__ctor_m4F7269BAF4E8085E8628FF6C0EF0BD42BF43B072 ();
// 0x00000007 System.Void UnityEngine.VFX.VFXSpawnerState::.ctor(System.IntPtr,System.Boolean)
extern void VFXSpawnerState__ctor_m2A95971A7A6D3701F39FD7A656451CD619C3010E ();
// 0x00000008 UnityEngine.VFX.VFXSpawnerState UnityEngine.VFX.VFXSpawnerState::CreateSpawnerStateWrapper()
extern void VFXSpawnerState_CreateSpawnerStateWrapper_m079EC8731BA4C6A57A5138A16BB9DA147BCE6E17 ();
// 0x00000009 System.Void UnityEngine.VFX.VFXSpawnerState::SetWrapValue(System.IntPtr)
extern void VFXSpawnerState_SetWrapValue_mA673646567D2B54072EEC275FB79BEBF82C7EE31 ();
// 0x0000000A System.Void UnityEngine.VFX.VFXSpawnerState::Release()
extern void VFXSpawnerState_Release_m9D420CAC0353FCBCBF0F2D59AA286ED3D0BC4649 ();
// 0x0000000B System.Void UnityEngine.VFX.VFXSpawnerState::Finalize()
extern void VFXSpawnerState_Finalize_mDD2AA40919A974E7CE616FE003162A762B806CA5 ();
// 0x0000000C System.Void UnityEngine.VFX.VFXSpawnerState::Dispose()
extern void VFXSpawnerState_Dispose_mE45940AB83108F8F02D81BE4CEDE8C738F1C47F5 ();
// 0x0000000D System.Void UnityEngine.VFX.VFXSpawnerState::Internal_Destroy(System.IntPtr)
extern void VFXSpawnerState_Internal_Destroy_mED5E41CC22939E5F21A53FC44CA6FA7022F87273 ();
// 0x0000000E System.Void UnityEngine.VFX.VisualEffectAsset::.cctor()
extern void VisualEffectAsset__cctor_mD1DB26F94C7046E351AB856DE9666BEB465E759E ();
static Il2CppMethodPointer s_methodPointers[14] = 
{
	VFXExpressionValues__ctor_m4B8043CAE5D33D062707D851DD4E62D9F7BB1320,
	VFXExpressionValues_CreateExpressionValuesWrapper_mA085560E2E04D2CD8C76664FB169F227AA0A6537,
	NULL,
	NULL,
	NULL,
	VFXSpawnerCallbacks__ctor_m4F7269BAF4E8085E8628FF6C0EF0BD42BF43B072,
	VFXSpawnerState__ctor_m2A95971A7A6D3701F39FD7A656451CD619C3010E,
	VFXSpawnerState_CreateSpawnerStateWrapper_m079EC8731BA4C6A57A5138A16BB9DA147BCE6E17,
	VFXSpawnerState_SetWrapValue_mA673646567D2B54072EEC275FB79BEBF82C7EE31,
	VFXSpawnerState_Release_m9D420CAC0353FCBCBF0F2D59AA286ED3D0BC4649,
	VFXSpawnerState_Finalize_mDD2AA40919A974E7CE616FE003162A762B806CA5,
	VFXSpawnerState_Dispose_mE45940AB83108F8F02D81BE4CEDE8C738F1C47F5,
	VFXSpawnerState_Internal_Destroy_mED5E41CC22939E5F21A53FC44CA6FA7022F87273,
	VisualEffectAsset__cctor_mD1DB26F94C7046E351AB856DE9666BEB465E759E,
};
static const int32_t s_InvokerIndices[14] = 
{
	23,
	18,
	168,
	168,
	168,
	23,
	132,
	4,
	7,
	23,
	23,
	23,
	25,
	3,
};
extern const Il2CppCodeGenModule g_UnityEngine_VFXModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_VFXModuleCodeGenModule = 
{
	"UnityEngine.VFXModule.dll",
	14,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
